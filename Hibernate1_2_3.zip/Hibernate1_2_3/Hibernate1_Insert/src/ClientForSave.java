import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientForSave {
	public static void main(String[] args)
	{

		//Step 1: To load hibernate.cfg.xml, we need to create object of Configuration class, which is given in org.hibernate.cfg.*;
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml"); 
		
		//Step 2: By using this Configuration object we can create this SessionFactory. This SessionFactory is an interface.
		//Internally creating object of SessionFactoryImpl which is the implemented class for SessionFactory.
		//so this SessionFactory object contains all the data regarding the Configuration file so we can call as heavy weight object.
		SessionFactory factory = cfg.buildSessionFactory();
		
		//Step 3: Session is an interface and SessionImpl is implemented class, both are given in org.hibernate.*
		//When ever session is opened then internally a database connection will be opened.
		//in order to get a session or open a session we need to call openSession() method in SessionFactory,
		//it means SessionFactory produces sessions.
		Session session = factory.openSession();
		
		Product p=new Product();

		p.setProductId(102);
		p.setProName("samsung");
		p.setPrice(25000);
		
		//Step 4: Get the transaction object using session.
		// insert, update, delete, operations needs a Transaction. For fetching not required.
		Transaction tx = session.beginTransaction();
		
		session.save(p);
		System.out.println("Object saved successfully.....!!");
		
		// Step 5: commit the Transaction and close the session and SessionFactory
		tx.commit();
		session.close();
		factory.close();
		
		
		// Finally flow will be
		// 1. Configuration
		// 2. SessionFactory
		// 3. Session
		// 4. Transaction
		// 5. Close Statements
	}

}
