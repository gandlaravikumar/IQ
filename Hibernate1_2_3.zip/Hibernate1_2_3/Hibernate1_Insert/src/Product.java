import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // @Entity represents, this class belongs to the database table.
@Table(name = "product_table")
public class Product {
	
	@Id
	@Column(name="proid1")
	private int productId;
	
	@Column(name="proName2", length=10)
	private String proName;
	
	// @Transient --> If i make any property as @Transient. that property will not going to be store in Database.
	@Column(name="price3")
	private double price;

	public void setProductId(int productId)
	{
	    this.productId = productId;
	}
	public int getProductId()
	{
	    return productId;
	}

	public void setProName(String proName)
	{
	    this.proName = proName;
	}
	public String getProName()
	{
	    return proName;
	}

	public void setPrice(double price)
	{
	    this.price = price;
	}
	public double getPrice()
	{
	    return price;
	}
}
