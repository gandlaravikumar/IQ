import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

// First go to LogicForFetch.java and PassRunTimeValues.java then come to this class.
// Here HQL Insert,Update,Delete Queries
public class InsertUpdateDelete {
	public static void main(String[] args) {
		//Insert
		//HQL supports only INSERT INTO��� SELECT��� ;
		// there is no chance to write INSERT INTO���..VALUES
		//i mean while writing the insert query, we need to select values from other table. see the example below.
		//we can�t insert our own values manually.
		//Example:
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		//Insert
		/*
		 * Query qry = session.
		 * createQuery("insert into Product(productId,proName,price) select i.itemId,i.itemName,i.itemPrice from Items i where i.itemId= ?"
		 * ); qry.setParameter(0,600); int res = qry.executeUpdate();
		 */
		 
		
		
		
		//Update
		/*
		 * Query qry =
		 * session.createQuery("update Product p set p.proName=? where p.productId=111");
		 * qry.setParameter(0,"updated value");
		 * int res = qry.executeUpdate();
		 */
		
		// Delete
		/*
		 * Query qry = session.createQuery("delete from Product p where p.productId=?");
		 * qry.setParameter(0,110); 
		 * int res = qry.executeUpdate();
		 */
		
		
	}
}
