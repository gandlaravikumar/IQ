import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

//In this class we will see how to pass the values at run time while using the HQL select query
public class PassRunTimeValues {

	public static void main(String[] args) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		// There are two ways to pass the values in run time
		// 1. using question mark ?
		// 2. using label :variable
		
		// using question mark
		Query query = session.createQuery("select p.proName, p.price from Product p where p.productId=?");
		query.setParameter(0, 101);
		List list = query.list();
		Iterator itr = list.iterator();
		while (itr.hasNext()) {
			Object[] object = (Object[]) itr.next();
			System.out.println(object[0]+" "+object[1]);
		}
		
		// using label (Here ":" represents label). we are passing 101 value in java4s 
		Query query2 = session.createQuery("select p.proName from Product p where p.productId= :java4s");
		query2.setParameter("java4s", 101);
		List list2 = query2.list();
		Iterator itr2 = list2.iterator();
		while (itr2.hasNext()) {
			String object = (String) itr2.next();
			System.out.println(object);
		}
	}

}
