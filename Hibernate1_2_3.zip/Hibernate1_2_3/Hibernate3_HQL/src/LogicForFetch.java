import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class LogicForFetch {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		// Steps to create HQL query and execute on DB
		//1. If we want to execute an HQL query on a database, we need to create a query object first.
			 // � Query � is an interface given in org.hibernate package
		//2. In order to get query object, we need to call createQuery() method in the session Interface
		//3. we need to call list() in the query Interface, for executing an HQL command on database, it returns java.util.List
		//4. we need to use java.util.Iterator for iterating the List collection.
		
		// we can fetch the object in 3 ways
		// 1. full object
		// 2. partial object (multiple columns)
		// 3. partial object (single column)
		
		//1. fetch full object
		Query query = session.createQuery("Select p from Product p");
		List l = query.list();
		Iterator itrIterator = l.iterator();
		while (itrIterator.hasNext()) {
			Object object = (Object) itrIterator.next();
			Product p = (Product) object;
			System.out.println(p.getProductId()+" "+p.getProName()+" "+p.getPrice());
		}
		
		//2. partial object (multiple columns)
		// In this case hibernate internally stores the multiple column values of each row into an object array.
		//At the time of iterating the collection, we need to typecast the result into an object arrays.
		Query query2 = session.createQuery("Select p.proName, p.productId from Product p");
		List l2 = query2.list();
		Iterator itrIterator2 = l2.iterator();
		while (itrIterator2.hasNext()) {
			Object[] object = (Object[]) itrIterator2.next();
			System.out.println(object[0]+" "+object[1]);
		}
		
		// 3. partial object (single column)
		// In this case hibernate internally stores the value in the type of the column.
		Query query3 = session.createQuery("Select p.productId from Product p");
		List l3 = query3.list();
		Iterator itrIterator3 = l3.iterator();
		while (itrIterator3.hasNext()) {
			Integer i = (Integer) itrIterator3.next();
			System.out.println(i);
		}
		
		// How to fire a query in hibernates using SQL query?
		SQLQuery sqlQuery = session.createSQLQuery("select * from product");
		sqlQuery.addEntity(Product.class); // This addEntity will say which type of object the sqlQuery will return.
		List<Product> products = sqlQuery.list();
		for (Product product : products) {
			System.out.println(product);
		}
		
		session.close();
		sessionFactory.close();
		
		
		
		
//What is Criteria?
//Ans: Criteria is only for selecting the data from the database, that to we can select complete objects only not partial objects.
		// To fetch the complete object.
		/*
		 * Criteria crit = session.createCriteria(Employee.class); 
		 * List l = crit.list();
		 * Iterator it = l.iterator(); 
		 * while(it.hasNext()) { 
		 * Object o = it.next();
		 * Product p = (Product)o; 
		 * }
		 */
		
// If i want to put any condition like greater than.
//i need to add the criterion object to criteria class object
		/*
		 * Criteria crit = session.createCriteria(Products.class); 
		 * Criterion c1=Restrictions.gt("price", new Integer(12000)); //price is our pojo class variable. gt means greater than >12000 
		 * crit.add(c1); // adding criterion object to criteria class object
		 * List l = crit.list(); // executing criteria query
		 */
		
		}
}
