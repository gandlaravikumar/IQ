import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientForLogic {
	public static void main(String[] args)
	{
		//Fetch
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Object obj = session.load(Product.class, new Integer(102));
		Product p = (Product) obj;
		System.out.println(p.getProductId()+" "+p.getProName()+" "+p.getPrice());
		
		session.close();
		sessionFactory.close();
		
		//Update (If you want to update, first load the object and change the values and commit it)
		// Approach1: load the object from DB and set the new values. commit the transaction. no need to call update(). This is Recommended way.
		// Approach2: create new object with same id (primary key should be present in DB) and call update() by the session.
		Configuration configuration2 = new Configuration();
		configuration2.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory2 = configuration.buildSessionFactory();
		Session session2 = sessionFactory2.openSession();
		
		Transaction tx = session2.beginTransaction();
		Object obj2 = session2.load(Product.class, new Integer(102)); 
		Product p2 = (Product) obj2;
		p2.setProName("ipad");
		p2.setPrice(30000);
		
		tx.commit();
		System.out.println("object updated");
		session2.close();
		sessionFactory2.close();
		
		//Delete (If you want to delete, first load the object and delete the object)
		Configuration configuration3 = new Configuration();
		configuration3.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory3 = configuration.buildSessionFactory();
		Session session3 = sessionFactory3.openSession();
		
		Transaction txn = session3.beginTransaction();
		Object obj3 = session3.load(Product.class, new Integer(102)); 
		Product p3 = (Product) obj3;
		session3.delete(p3);
		
		txn.commit();
		System.out.println("object deleted");
		session3.close();
		sessionFactory3.close();
		
	}

}
