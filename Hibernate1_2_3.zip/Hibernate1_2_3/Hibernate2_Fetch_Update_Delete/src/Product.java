
public class Product {
	// Always try to use wrapper types(Integer). Don't use primitive types (int). But time being here i used primitive types.
	// Because in primitive types(int) if i forget to set the price, in DB price will set as zero. [free of cost hah].
	// But in wrapper types(Integer) if i forget to set the price, in DB price will set as null. [no misunderstanding].
	private int productId;
	private String proName;
	private double price;

	public void setProductId(int productId)
	{
	    this.productId = productId;
	}
	public int getProductId()
	{
	    return productId;
	}

	public void setProName(String proName)
	{
	    this.proName = proName;
	}
	public String getProName()
	{
	    return proName;
	}

	public void setPrice(double price)
	{
	    this.price = price;
	}
	public double getPrice()
	{
	    return price;
	}
}
