package com.ravi.SpringCoreFullyAnnotationBasedConfiguration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration // This class is a configuration class.
@ComponentScan(basePackages = "com.ravi.SpringCoreFullyAnnotationBasedConfiguration")
public class AppConfig {
	
}
