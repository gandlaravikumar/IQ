package com.ravi.SpringCoreFullyAnnotationBasedConfiguration;

import org.springframework.stereotype.Component;
// By default internally the @Component will take the class name with de capitilized only. like @Component("mediaTek")
@Component
// @Primary  -->If i don't mention @Qualifier annotation in Samsung.java. Then i can use @primary annotation in this class. So, this class will consider as a MobileProcessor.
public class MediaTek implements MobileProcessor {

	public void process() {
		System.out.println("2nd best CPU");
		
	}

}
