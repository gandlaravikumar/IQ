package com.ravi.SpringCoreFullyAnnotationBasedConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
//Spring Core Annotations
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        Samsung samsung = applicationContext.getBean(Samsung.class);
        samsung.config();
    }
}
