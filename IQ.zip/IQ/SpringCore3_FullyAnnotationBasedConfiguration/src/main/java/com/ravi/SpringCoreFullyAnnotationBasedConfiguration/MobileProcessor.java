package com.ravi.SpringCoreFullyAnnotationBasedConfiguration;

public interface MobileProcessor {

	void process();
}
