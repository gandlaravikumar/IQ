In SpringCore1_XMLBasedConfiguration, SpringCore2_PartiallyAnnotationBasedConfiguration projects spring.xml is there.
But in this SpringCore3_FullyAnnotationBasedConfiguration project we are not using spring.xml file.
Every thing is configured by annotations only.
That's y we are doing @ComponentScan(basePackages = "packageName") in AppConfig.java file.

