How can we implement REST?
Ans: We have 2 choice.
1. Through Jersey librarey,
2. Through Spring implementation of Restful API.

In this application RESTful web services using jersey jar and JDBC connections.

REST: (representational state transfer)
converting an object into state (data of the object) that is called as representational state transfer.
what ever you are sending response to client is not an object but it is state of the object. 
that state of an object can be send using json/XML.

Types of HTTP methods?
THere are 4 types:
C -> Create -> POST -> Create a new resources on the server.
R -> Read -> GET -> fetching resources from the server
U -> Update -> PUT -> If the resource is available it will update, else it will insert.
D -> Delete -> DELETE -> delete the resource.

PATCH: This is used for only update the resource.

idempotent and non idempotent?
Ans: Idempotent means if an operation doesn't cause any change in state. (GET, PUT, DELETE)
	 non-Idempotent means if an operation always causes a change in state. (POST)

POJO -> plain old java object

@path("alien") -> @path is used to define the request end point.

@pathparam("id") -> @pathparam is used to receive the parameter from request.

By default jersy will work with only XML. to work with Json we need to add one dependency called jersey-media-moxy

Content Negotiation:
as a server you have options of providing data in different format. like example xml, json, pdf

@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
// it will produce both xml and json format

@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
// it will consumes (accept) both xml and json format