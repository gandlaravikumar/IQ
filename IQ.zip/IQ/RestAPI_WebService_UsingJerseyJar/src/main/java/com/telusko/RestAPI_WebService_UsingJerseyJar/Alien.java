package com.telusko.RestAPI_WebService_UsingJerseyJar;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement // This @XmlRootElement helps to Maps this class to an XML element. i.e, this Alien class is a root element of XML. Inside that root element we have sub elements like id, name points. Like that it will arrange the XML format.
public class Alien {

	private int id;
	private String name;
	private int points;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	
	
}
