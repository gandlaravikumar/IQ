package com.telusko.RestAPI_WebService_UsingJerseyJar;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("aliens")
public class AlienResource {

	AlienRepository repo = new AlienRepository();
	
	
	@GET
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public List<Alien> getAliens() {
		return repo.getAliens();
	}
	
	@GET
	@Path("alien/{id}") //@path is used to define the request end point.
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})   // add jersey-media-moxy in pom.xml to get JSON support
	// @Produces means it will produce witch type of data
	// @pathparam is used to receive the parameter from request.
	public Alien getAlien(@PathParam("id") int id) {
		return repo.getAlien(id);
	}
	
	@POST
	@Path("alien")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	// Consumes means it will accept witch type of data
	public Alien createAlien(Alien a1) {
		repo.create(a1);
		return a1;
	}
	
	@PUT
	@Path("alien")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	// Consumes means it will accept witch type of data
	public Alien updateAlien(Alien a1) {
		if(repo.getAlien(a1.getId()).getId()==0) {
			repo.create(a1);
		} else {
		repo.update(a1);
		}
		return a1;
	}
	
	@DELETE
	@Path("alien/{id}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	// @Produces means it will produce witch type of data.
	public Alien delete(@PathParam("id") int id) {
		Alien a = repo.getAlien(id);
		if(a.getId()!=0) {
			repo.delete(id);
		}
		return a;
	}
}
