package com.telusko.RestAPI_WebService_UsingJerseyJar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AlienRepository {

	Connection con = null;
	
	public AlienRepository() {
		String url = "jdbc:mysql://localhost:3306/rest_api";
		String userName = "root";
		String password = "root";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(url,userName,password);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public List<Alien> getAliens() {
		List<Alien> aliens = new ArrayList<Alien>();
		String sql = "select * from alien";
		try {
			Statement statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {
				Alien alien = new Alien();
				alien.setId(resultSet.getInt(1));
				alien.setName(resultSet.getString(2));
				alien.setPoints(resultSet.getInt(3));
				aliens.add(alien);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return aliens;
	}
	
	public Alien getAlien(int id) {
		Alien alien = new Alien();
		String sql = "select * from alien where id="+id;
		try {
			Statement statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			if (resultSet.next()) {
				alien.setId(resultSet.getInt(1));
				alien.setName(resultSet.getString(2));
				alien.setPoints(resultSet.getInt(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return alien;
	}

	public void create(Alien a1) {
		String sql = "insert into alien values (?,?,?)";
		try {
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setInt(1, a1.getId());
			statement.setString(2, a1.getName());
			statement.setInt(3, a1.getPoints());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void update(Alien a1) {
		String sql = "update alien set name=?, points=? where id=?";
		try {
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setInt(3, a1.getId());
			statement.setString(1, a1.getName());
			statement.setInt(2, a1.getPoints());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void delete(int id) {
		String sql = "delete from alien where id=?";
		try {
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setInt(1, id);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
