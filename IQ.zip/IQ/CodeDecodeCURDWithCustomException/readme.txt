In this project CRUD operations are there, SpringBoot + Hibernates + REST API. Along with Custom Exception Handling in Spring Boot.

checked exceptions are compile exception use throws key word.
unchecked exceptions are run time exceptions.

