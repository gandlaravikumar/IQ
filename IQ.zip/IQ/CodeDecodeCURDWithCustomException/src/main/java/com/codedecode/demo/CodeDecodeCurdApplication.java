package com.codedecode.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeDecodeCurdApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeDecodeCurdApplication.class, args);
	}

}
