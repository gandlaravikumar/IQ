package com.codedecode.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity // @Entity represents this class is a type of bean class.
@Table(name = "emp") // @Table represents the name of the table in database. else it will take class name as table name.
@Getter // @Getter is a annotation from lombok jar. no need to create getter methods
@Setter // @Setter is a annotation from lombok jar. no need to create setter methods
public class Employee {
	
	@Id
	@GeneratedValue
	private long id;
	
	private String name;

}
