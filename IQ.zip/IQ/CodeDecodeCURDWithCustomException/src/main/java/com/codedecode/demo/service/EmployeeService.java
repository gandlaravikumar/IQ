package com.codedecode.demo.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codedecode.demo.custom.exception.BusinessException;
import com.codedecode.demo.entity.Employee;
import com.codedecode.demo.repo.EmployeeCrudRepo;

@Service
public class EmployeeService implements EmployeeServiceInterface {


	@Autowired
	EmployeeCrudRepo empCrud;

	@Override
	public Employee addEmployee(Employee employee) {
		if(employee.getName().isEmpty() || employee.getName().length() == 0) {
			throw new BusinessException("601", "please send proper name, it is blank");
		}
		try {
		Employee savedEmployee = empCrud.save(employee);
		return savedEmployee;
		} catch (IllegalArgumentException e) {
			throw new BusinessException("602", "given employee object is empty" +e.getMessage());
		} catch (Exception e) {
			throw new BusinessException("603", "something went worng in service layer" +e.getMessage());
		}
		
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> empList = null;
		try {
			empList = empCrud.findAll();
		} catch (Exception e) {
			throw new BusinessException("605", "something went worng in service layer while fetching the all employees "+e.getMessage());
		}
		if (empList.isEmpty()) {
			throw new BusinessException("604", "employee list is empty. nothing to return");
		}
		return empList;
	} 
	

	@Override
	public Employee getEmployeeById(Long id) {
		try {
		return empCrud.findById(id).get();
		} 
		// If id is null then throw IllegalArgumentException
		catch(IllegalArgumentException e) {
			throw new BusinessException("606", "given employee id is null, please send some id to be fetch "+e.getMessage());
		} 
		//  if there is no value present then throw NoSuchElementException
		catch(NoSuchElementException e) {
			throw new BusinessException("607", "given employee id doesn't exist in DB "+e.getMessage());
		} 
		// Main Exception
		catch(Exception e) {
			throw new BusinessException("608", "something went worng in service layer while fetching the employee details "+e.getMessage());
		}
	}

	@Override
	public void deleteEmpById(Long id) {
		try {
			empCrud.deleteById(id);
		} // If id is null then throw IllegalArgumentException
		catch (IllegalArgumentException e) {
			throw new BusinessException("609",
					"given employee id is null, please send some id to be delete " + e.getMessage());
		}
		// Main Exception
		catch (Exception e) {
			throw new BusinessException("610",
					"something went worng in service layer while deleting the employee details " + e.getMessage());
		}
	}
	
}
