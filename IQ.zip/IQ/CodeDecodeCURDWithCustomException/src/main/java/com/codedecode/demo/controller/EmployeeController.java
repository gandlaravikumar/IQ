package com.codedecode.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codedecode.demo.custom.exception.BusinessException;
import com.codedecode.demo.custom.exception.ControllerException;
import com.codedecode.demo.entity.Employee;
import com.codedecode.demo.repo.EmployeeCrudRepo;
import com.codedecode.demo.service.EmployeeServiceInterface;

@RestController
public class EmployeeController {

	
	@Autowired
	EmployeeServiceInterface employeeServiceInterface;
	
	@PostMapping("/save")
	//@RequestBody it is used to handle the request parameter should be bound in the body if the web request
	public ResponseEntity<?> addEmployee(@RequestBody Employee employee) {
		try {
		Employee employeeSaved = employeeServiceInterface.addEmployee(employee);
		return new ResponseEntity<Employee>(employeeSaved, HttpStatus.CREATED);
		} catch(BusinessException b) {
			ControllerException ce = new ControllerException(b.getErrorCode(), b.getErrorMessage());
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException ce = new ControllerException("611", "Something went worng in controller ");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Employee>> getAllEmployee() {
		return new ResponseEntity<List<Employee>>(employeeServiceInterface.getAllEmployees(), HttpStatus.OK);
	}
	
	@GetMapping("/emp/{id}")
	public ResponseEntity<?> getEmployeeById(@PathVariable Long id) {
		try {
		return new ResponseEntity<Employee>(employeeServiceInterface.getEmployeeById(id), HttpStatus.OK);
		} catch(BusinessException b) {
			ControllerException ce = new ControllerException(b.getErrorCode(), b.getErrorMessage());
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException ce = new ControllerException("612", "Something went worng in controller ");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping("/emp/{id}")
	public ResponseEntity<?> deleteEmpById(@PathVariable Long id) {
		try {
		employeeServiceInterface.deleteEmpById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
		} catch(BusinessException b) {
			ControllerException ce = new ControllerException(b.getErrorCode(), b.getErrorMessage());
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException ce = new ControllerException("613", "Something went worng in controller ");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/update")
	//@RequestBody it is used to handle the request parameter should be bound in the body if the web request
	public ResponseEntity<?> updateEmployee(@RequestBody Employee employee) {
		try {
		Employee employeeSaved = employeeServiceInterface.addEmployee(employee);
		return new ResponseEntity<Employee>(employeeSaved, HttpStatus.CREATED);
		} catch(BusinessException b) {
			ControllerException ce = new ControllerException(b.getErrorCode(), b.getErrorMessage());
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException ce = new ControllerException("614", "Something went worng in controller ");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
	}
}
