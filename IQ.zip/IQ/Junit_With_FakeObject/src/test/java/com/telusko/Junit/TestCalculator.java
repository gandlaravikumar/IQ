package com.telusko.Junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestCalculator {
	
	Calculator calc = null;
	
	// Our Calculator class is dependent on CloudService class where it is connected to Google cloud to add the numbers.
	// So we need to mock the CloudService class.
	// This is not the actual service. This is the duplicate copy of the actual service.
	/*
	 * when ever you tried to create mock object you need to implement
	 * the methods inside the object like Anonymous Inner Type
	 */
	
	CloudService service = new CloudService() {
		
		public int add(int i, int j) {
			System.out.println("moke service invoked");
			return i+j;
		}
	};
	
	/*
	 * this setup method is used to create the objects with out create objects
	 * in open source. And this method will call before the testing of the units
	 */
	@Before
	public void setUp() {
		calc = new Calculator(service);
	}
	
	@After
	// @After is used to release some object resources after the testing of the units.
	
	@Test
	public void testAdd() {
		assertEquals(8, calc.add(5, 3));
	}

}
