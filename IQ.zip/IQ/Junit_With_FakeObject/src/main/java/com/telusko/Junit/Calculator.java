package com.telusko.Junit;

public class Calculator {
	
	CloudService service;
	
	public Calculator(CloudService service) {
		this.service = service;
	}
	
	// Assume here the CloudService class where it is connected to database or cloud services will provide the addition of 2 numbers.
	// we will not do addition.
	// In that time will not do the unit test for CloudService. 
	// because this CloudService is connected to Database or google cloud services to add the numbers. It will take long time to test.
	// so we need to mock those CloudService in TestCalculator class..
	public int add(int i, int j) {
		return service.add(i, j);
	}

}
