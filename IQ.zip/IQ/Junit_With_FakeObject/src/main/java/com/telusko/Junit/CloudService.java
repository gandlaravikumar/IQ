package com.telusko.Junit;

public class CloudService {
	
	public int add(int i, int j) {
		
		return i+j;
	}

}
