What is Junit?
As a developer we need to test the entire application. But entire application testing at a time, if something brokes, we don't know
what is broken. That's y we need to test in unit wise. unit means a small piece of application. There are n no of classes and methods
are there. we need to test each and every class and method by using junit jar. Means i can achieve unit testing in java using junit.
