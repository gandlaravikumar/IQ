What is maven?
maven is a build tool and also It will give all the required libraries.

Explain Spring-MVC flow?
-> Through XML based configuration: (web.xml and telusko-servlet.xml)
1.  When client send a request, that request will go to web.xml. 
	from web.xml all the requests are go to spring dispatcher servlet (org.springframework.web.servlet.DispatcherServlet).
2.  Here dispatcher servlet is nothing but front controller.
3.  That dispatcher servlet sent that request to configuration file (telusko-servlet.xml). where component scan (package of controllers) is configured.
4.  Then the request will go to the particular controller package and search for the requestmapping method.
5.  That method will process some services and provide the data.
6.  we have to set that data and view page to the ModelAndView object and return it.
7.  Again the ModelAndView object will go to the front controller (Dispatcher servlet). From front controller it will go to the particular
  	view page and display the data which is present in the ModelandView object.
  	
 Note: How DispatcherServlet will know which request to call which controller?
 Ans: DispatcherServlet needs some configuration file (telusko-servlet.xml), like for which request to call which controller.
 All the controller classes should be annotated with the help of @Controller. Every controller class having some mapping configuration
 like @RequestMapping("login"). I have to mention only in that configuration file (telusko-servlet.xml), which package do i have all the controllers (package of controllers).
 DispatcherServlet will go to the mentioned package in telusko-servlet.xml. And load all the controllers class, and find the respective @RequestMapping.

-> Through Java based configuration: (MyFrontController.java and TeluskoConfig.java)
1. 	when client send a request, that request will go to MyFrontController.java.
	from MyFrontController.java all the requests are go to configuration file TeluskoConfig.java,
	where @componentscan (package of controllers) is annotated.
2.	Then the request will go to the particular controller package and search for the requestmapping method.
3.  That method will process some services and provide the data.
4.  we set that data and view page to the ModelAndView object and return it.


If i don't want to use xml, i want to use annotations configuration, then remove the telusko-servlet.xml file and
create the configuration class like TeluskoConfig.java. same like how we created in SpringCore3_FullyAnnotationBasedConfiguration project.
Means, I can replace telusko-servlet.xml file with java annotation configuration file. (TeluskoConfig.java)
I also can replace web.xml file with MyFrontController.java.
For better understanding please go through the Spring-MVC flow in XML and java based configurations.

what is the difference between normal MVC and Spring MVC?
Ans: In normal MVC there is only one controller which handles all the requests. (requestAction.xml)
But in spring MVC there can be a multiple controllers which handles multiple requests. (telusko-servlet.xml). 
This telusko-servlet.xml contains multiple packages also.

Note: telusko-servlet.xml name comes from {something}-servlet.xml
{something} is nothing but <servlet-name> in web.xml


