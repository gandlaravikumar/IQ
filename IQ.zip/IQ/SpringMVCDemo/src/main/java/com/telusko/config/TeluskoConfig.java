package com.telusko.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
//Note: this file is replacement by telusko-servlet.xml

@Configuration
@EnableWebMvc // If i want to work with annotations i need to enable web mvc
@ComponentScan({"com.telusko.controller"})
public class TeluskoConfig extends WebMvcConfigurerAdapter{

	@Bean
	public InternalResourceViewResolver setViewExtension() {
		InternalResourceViewResolver vr = new InternalResourceViewResolver();
		vr.setPrefix("/WEB-INF/");
		vr.setSuffix(".jsp"); // I can change the suffix in feature from .jsp to .html
		
		return vr;
	}
}
