package com.telusko.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.telusko.service.AddService;

@Controller
public class AddController {

	@RequestMapping("add")
	public ModelAndView add(@RequestParam("t1") int num1, @RequestParam("t2") int num2) {
		
		AddService as = new AddService();
		int num3 = as.addNumbers(num1, num2);
		ModelAndView mv = new ModelAndView();
		mv.addObject("result", num3);
		mv.setViewName("display"); 
		/*
		 * Here actally the view page name is display.jsp. But in feature if i want to
		 * change to display.html. no need to change in all the places where and all
		 * setViewName. i can change only in one place in TeluskoConfig.java
		 */
		
		
		return mv;
	}
}
