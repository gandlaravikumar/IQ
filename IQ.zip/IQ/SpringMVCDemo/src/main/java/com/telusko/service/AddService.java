package com.telusko.service;

public class AddService {
	
	public int addNumbers(int i, int j) {
		return i+j;
	}

}
