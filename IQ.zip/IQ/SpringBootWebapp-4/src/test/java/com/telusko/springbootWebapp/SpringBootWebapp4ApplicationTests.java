package com.telusko.springbootWebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebapp4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
