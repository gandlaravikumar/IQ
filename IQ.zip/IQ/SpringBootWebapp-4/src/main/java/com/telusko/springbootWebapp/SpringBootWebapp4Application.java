package com.telusko.springbootWebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebapp4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebapp4Application.class, args);
	}

}
