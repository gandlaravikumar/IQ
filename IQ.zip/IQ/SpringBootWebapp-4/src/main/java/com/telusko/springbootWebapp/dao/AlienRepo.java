package com.telusko.springbootWebapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.telusko.springbootWebapp.model.Alien;

@RepositoryRestResource(collectionResourceRel = "aliens",path = "aliens")
public interface AlienRepo extends JpaRepository<Alien, Integer> {
	// all the CRUD methods are inbuilt in jpaRepository. so it will work without controller class.
	// This is spring data rest application. In this type of applications there will be no controller classes.
}
