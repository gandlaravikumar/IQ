package com.ravi.SpringCoreAnnotationBasedConfiguration;

import org.springframework.stereotype.Component;

@Component // @Component annotation, which makes this class as a dependent and It will instantiate the object.
public class Tyre {
	
	private String brand;
	private String type;
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Tyre is working";
	}

}
