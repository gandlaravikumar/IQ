package com.ravi.SpringCoreAnnotationBasedConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");

		// we should give the bean name as class name(Bike). But it should be decapitalize (bike) and without package name.
		Vehicle bike = (Vehicle) context.getBean("bike");
		bike.drive();
		
		// we are getting car Object. Car object depends on Tyre object
		Vehicle car = (Vehicle) context.getBean("car");
		car.drive();
	}
}
