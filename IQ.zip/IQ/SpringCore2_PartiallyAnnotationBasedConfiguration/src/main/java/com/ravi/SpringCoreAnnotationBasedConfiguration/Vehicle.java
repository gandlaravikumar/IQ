package com.ravi.SpringCoreAnnotationBasedConfiguration;

public interface Vehicle {

	void drive();
}
