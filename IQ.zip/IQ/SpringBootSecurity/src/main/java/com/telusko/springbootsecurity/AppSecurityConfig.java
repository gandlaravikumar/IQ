package com.telusko.springbootsecurity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.util.AntPathMatcher;
@Configuration
@EnableWebSecurity  // It will enable the web security for our application.
// i need to extend WebSecurityConfigurerAdapter so that i will get all the configuration features. SO that y i make this class as @Configuration
public class AppSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	private UserDetailsService userDetailsService;

	//This authProvider() is used to Authentication.
	// Or If you want to override default method then you can go for configure(AuthenticationManagerBuilder auth)
	@Bean
	public AuthenticationProvider authProvider() {
		//DaoAuthenticationProvider will provide the implementation for AuthenticationProvider.
		// DaoAuthenticationProvider will talk to Database and verify the authentication.
		// Generally Configuration file or Controller file will talk to service layer, and service file will talk to DB layer. 
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		provider.setUserDetailsService(userDetailsService);
		provider.setPasswordEncoder(new BCryptPasswordEncoder());
		
		return provider;
		
	}
	
	// Actually spring having it's own login page. we can override that login page and customize our own login page by override this configure(HttpSecurity) method. 
	//This configure(HttpSecurity http) method is used to Authorization.
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.csrf().disable()
		.authorizeRequests().antMatchers("/login").permitAll()
		.anyRequest().authenticated().and()
		.formLogin()
		.loginPage("/login").permitAll()
		.and()
		.logout().invalidateHttpSession(true)
		.clearAuthentication(true)
		.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
		.logoutSuccessUrl("/logout-success").permitAll();
	}
	
	

}
