SHA-256 having some disadvantages.
They can able to create 2 hashes of the same message.

Now we have Bcrypt. for encrypt the password.
 
Spring security will provide you Authentication and Authorization.
Authentication means who are you like your username and password.
Authorization means access. Means you have access to create users are not like that.

How did you implement spring security in your spring boot application?
Ans: If i give the username and password, it will check with DB, If it is correct and it will provide the Authentication, along with Authorization.

Types Of Authentication: (3 types)
1. Knowledge Based Authentication : Password + MPin + Answer to security questions that u set to app during a/c creation.
2. Possession Based Authentication: Text message in your phone + Key card or badges + Access tokens.
3. Knowledge + Possession Based Authentication: Multifactor auth + Login to VDI or AWS system.

 What are the core concepts of spring security?
 Ans: Authentication: Who are you?, Process of identity the person trying to access the application.
 	  Authorization: Process of identity if the person is allowed to do this application.
 	  Principal: Is the person that you have identified through authentication process. It's also called currently logged in user that we store in session.
 	  Granted Authority: Are bunch or group of permissions which are allowed for a user.
 	  Roles: Group of authorities that are assigned together. E.g: Role_USER_Login and search. Role_Admin_Login, search create, update employees.

If given a simple spring boot application, how will you implement the spring security?
Ans: First step is by adding dependency in pom.xml.
	 <dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-security</artifactId>
	 </dependency>

How is spring security intercepting your request?
Ans: Because of Filter of servlets.
	 So, filter is your receptionist validating all guests.

How to configure Authentication in spring security?
Ans: Add the dependency spring-boot-starter-security in pom.xml
	 Extend WebSecurityConfigurerAdapter in custom class and use @EnableWebSecurity annotation.
	 Override configure(AuthenticationManagerBuilder) method.
	 configure type of auth, user, pass and role.
	 This will create and configure a new AuthenticationManager and now SpringSecurity will use this Authentication instead of default one.

How to configure Authorization in spring security?
Ans: Add the dependency spring-boot-starter-security in pom.xml
	 Extend WebSecurityConfigurerAdapter in custom class and use @EnableWebSecurity annotation.
	 Override configure(HttpSecurity http) method.
	 configure http.authorizeRequests()


