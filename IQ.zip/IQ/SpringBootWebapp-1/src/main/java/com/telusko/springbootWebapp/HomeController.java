package com.telusko.springbootWebapp;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@RequestMapping("home")
	//@RequestMapping is used to handle the requests
	
	// @ResponseBody
	// @ResponseBody is used to what ever you are returning, that is actually a data. not a page.
	public String home() {
		
		System.out.println("welcome to spring boot app");
		return "home";
	}
	
	// request url should be http://localhost:8080/name?name=ravi
	@RequestMapping("name")
	public ModelAndView printName(@RequestParam("name") String myName) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("name", myName);
		mv.setViewName("home");
		System.out.println("name method calling");
		return mv; 
		/*
		 * what ever here we are returning this will go to dispacher servlet. That
		 * dispacher servlet required 2 things. data and view name. That's y we are
		 * setting object and viewname to modelObject.
		 */	
		}
	
	// request url should be http://localhost:8080/values?aid=3&aname=ravi&lang=java
	@RequestMapping("values")
	public ModelAndView printAlienValues(Alien alien) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("alienObj", alien);
		mv.setViewName("home");
		
		return mv;
	}
}
