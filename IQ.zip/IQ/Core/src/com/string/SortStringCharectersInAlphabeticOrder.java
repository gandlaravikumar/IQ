package com.string;

import java.util.Arrays;

public class SortStringCharectersInAlphabeticOrder {
	
	// input : rock
	// output : 
	
	public static void main(String[] args) {
		
		//Approach 1
		String input = "gbcjdiafeh";
		WithoutUsingSortMethod(input);
		
		//Approach 2
		usingSortMethod(input);
	}

	private static void WithoutUsingSortMethod(String input) {
		char temp;
		char[] charArray = input.toCharArray();
		for(int i=0; i<charArray.length; i++) {
			for(int j=i+1; j<charArray.length; j++) {
				if(charArray[i] > charArray[j]) {
					temp = charArray[i];
					charArray[i] = charArray[j];
					charArray[j] = temp;
				}
			}
		}
		System.out.println(charArray);
	}
	
	private static void usingSortMethod(String input) {
		char[] ch = input.toCharArray();
		Arrays.sort(ch);
		System.out.println("After sort "+String.valueOf(ch));
	}

}
