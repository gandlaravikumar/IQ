package com.string;

import java.util.ArrayList;
import java.util.List;

public class StringContainsNumberValuesOrNot {

	public static void main(String[] args) {
		// Check weather the string contains numbers or not
		String name = "fdsfsdsd";
		
		Boolean value = name.matches("[a-z]+");
		System.out.println(value);
		
		
		// print only string values from the list of Objects?
		List<Object> list = new ArrayList<Object>();
		
		list.add(45);
		list.add("ravi");
		list.add(true);
		
		for(Object obj : list) {
			if(obj instanceof String) {
				System.out.println("String value is "+ obj);
			} else if(obj instanceof Integer) {
				System.out.println("Integer value is "+ obj);
			} else if(obj instanceof Boolean) {
				System.out.println("Boolean value is "+ obj);
			}
		}

	}

}
