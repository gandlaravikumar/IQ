package com.string;

public class ReverseAString {
	
	/*
	 * input : hello 
	 * output : olleh
	 */

	public static void main(String[] args) {
		String s = "hello";
		
		// 1. By using toCharArray() method
		char[] charArray = s.toCharArray();
		for(int i=charArray.length-1; i>=0; i--) {
			System.out.print(charArray[i]);
		}
		
		System.out.println(); // new line
		
		// 2. using charAt(int index) method
		for(int i=s.length()-1; i >= 0; i--) {
			System.out.print(s.charAt(i));
		}
		
		System.out.println(); // new line
		
		// 3. reverse method in StringBuffer class
		StringBuffer sbuff = new StringBuffer(s);
		System.out.println(sbuff.reverse());
		
		
		// 4. reverse method in StringBuilder class
		StringBuilder sbuilder = new StringBuilder(s);
		System.out.println(sbuilder.reverse());
		
	}
	
}
