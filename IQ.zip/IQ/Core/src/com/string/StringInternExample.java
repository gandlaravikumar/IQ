package com.string;

/*What is String intern()?
Ans:  The Java String class intern() method returns the interned string.
	  It is used to return the string from pool memory if it is created by a new keyword.
 	  If i create a string using new keyword. It creates an exact copy of the heap string object in the String Constant Pool.
 	  The reference will pointing to heap memory only.
	  If i want to get the string from pool memory i can use String.intern() method.*/

public class StringInternExample {
	public static void main(String[] args) {
		String s1 = new String("hello");
		String s2 = "hello";
		String s3 = s1.intern();// returns string from pool, now it will be same as s2
		System.out.println(s1 == s2);// false because reference variables are pointing to different instance
		System.out.println(s2 == s3);// true because reference variables are pointing to same instance
	}
}
