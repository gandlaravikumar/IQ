package com.string;

public class ReverseEachWordInString {
	/*
	 * input : java code 
	 * output : avaj edoc
	 */
	public static void main(String[] args) {
		String sentence = "java code";
		String[] wordArray = sentence.split(" ");
		for(int i=0; i<wordArray.length; i++) {
			for(int j=wordArray[i].length()-1; j>=0; j--) {
				System.out.print(wordArray[i].charAt(j));
			}
			System.out.print(" ");
		}
		
		// Another way
		for(String s : wordArray) {
			for(int i=s.length()-1; i>=0; i--) {
				System.out.print(s.charAt(i));
			}
			System.out.print(" ");
		}
	}
	

}
