package com.string;

import java.util.HashMap;
import java.util.Map;

public class OccurrenceOfEachCharacter {
	/*
	 * input : hello 
	 * output : h-1 e-1 l-2 o-1
	 */
	
	public static void main(String[] args) {
		String s = "hello";
		method1(s);
		method2(s);
		
	}
	
	public static void method1(String s) {
		
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		int count = 0;
		for(int i=0 ; i<s.length(); i++) {
			for(int j=0; j<s.length(); j++) {
				if(s.charAt(i)==s.charAt(j)) {
					count ++;
				}
			}
			map.put(s.charAt(i), count);
			count =0;
		}
		
		for(Map.Entry<Character, Integer> entry : map.entrySet()) {
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
	}
	
	private static void method2(String s) {
		char[] charArray = s.toCharArray();
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		for(char c : charArray) {
			if(!map.containsKey(c)) {
				map.put(c, 1);
			} else {
				map.put(c, map.get(c)+1);
			}
		}
		System.out.println(map);
	}


}
