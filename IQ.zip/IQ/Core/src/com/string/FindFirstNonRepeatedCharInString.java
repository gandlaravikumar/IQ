package com.string;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class FindFirstNonRepeatedCharInString {
		//input : AABCDBE
		//output : first non repeated character is C
	public static void main(String[] args) {
		String input = "AABCDFBECD";
		
		// Approach -1
		withoutUsingCollections(input);
		
		// Approach -2
		withUsingCollections(input);
	}

	private static void withoutUsingCollections(String input) {
		

		for (int i = 0; i < input.length(); i++) {
			boolean repeated = false;
			for (int j = 0; j < input.length(); j++) {
				if (i != j && input.charAt(i) == input.charAt(j)) {
					repeated = true;
					break;
				}
			}
			if (!repeated) {
				System.out.println("first non repeated character is " + input.charAt(i));
				break;
			}
		}

	}
	
	private static void withUsingCollections(String input) {
		Map<Character, Integer> map = new LinkedHashMap<>();
		for(int i=0; i<input.length(); i++) {
			char ch = input.charAt(i);
			if(map.containsKey(ch)) {
				map.put(ch, map.get(ch)+1);
			} else {
				map.put(ch, 1);
			}
		}
		
		for(Entry<Character, Integer> entry : map.entrySet()) {
			if(entry.getValue()==1) {
				System.out.println(entry.getKey());
				break;
			}
		}
		
	}

}
