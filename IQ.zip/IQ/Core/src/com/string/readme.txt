1.What is the Difference between "==" and "equals() method"?
Ans: == is a operator and it is used to reference comparison.
	.equals() is a method and it is used to content comparison.
 Note: In s1==s2 case. If both (s1 and s2) reference variables are point to same object, then it will return true. 
 Note: In s1.equals(s2) case. If both variables contains same data, it will return true.
 
 Note: .equals() method present in Object class also meant for reference comparison only. Based on our requirement we can
 	   override for content comparison.
 	   In String class, all wrapper class and all collection classes .equals() method is overridden for content comparison.
 
2. What is String?
Ans: String is a Class of an object, which is define in java.lang package. 
 	  which represents a set of characters or sequence of char values. Immutable strings are thread safe.
 
3. Is String a keyword in java?
Ans : No, String is not a keyword.
 		It is a final class. which is define in java.lang package and which represents a set of characters.
 
4. How many ways to create a string Objects?
Ans: 2 ways.
 		1. using string literal:
 		String s1 = "lucky";
 		Each time you create a string literal, the JVM checks the "string constant pool" first. 
 		If the string already exists in the pool, It returns the reference to that String.
 		If the string doesn't exist in the pool, a new string instance is created and placed in the pool
 		
 		2. using new keyword:
 		String s1 = new String("lucky");
 		In this case, JVM will create a new string object in normal (non-pool) heap memory, 
 		and the literal "lucky" will be placed in the string constant pool. 
 		The variable s1 will refer to the object in a heap memory (non-pool).
 		
Note: String are stored in a special memory area known as the "string constant pool".
 
5. Immutable VS mutable.
Immutable which means it cannot be changed. Whenever we change any string, a new instance is created with the modified content. 		
 For mutable strings (changeable), we can use StringBuffer and StringBuilder classes.
 
6. Why String class is immutable in java?
Ans :String pool required string should be immutable otherwise shared reference can be changed from anywhere.
 Suppose there are 10 reference variables, all refer to one object "Sachin".
 If one reference variable changes the value of the object, it will be affected by all the reference variables. 
 That is why String objects are immutable in Java. Immutable strings are thread safe.
 
7. What if someone overrides the functionality of string class and make String is changeable (mutable)?
Ans: That's the reason the string class is marked as final, so that nobody can override the behavior of it's method.
 
8. What is string intern()?
Ans: The Java String class intern() method returns the interned string.
 	  If i create a string using new keyword. It creates an exact copy of the heap string object in the String Constant Pool.
 	  The reference will pointing to heap memory only.
	  If i want to get the string from pool memory i can use String.intern() method.
	  It can be used to return string from pool memory if it is created by a new keyword.
 
 9.Why String Constant pool?
 Ans: some memory space allocated in the heap memory to store the string literals is called the string constant pool.
 	  No two string objects can have the same value in a string constant pool.
 	  If one object is created with value "abc", If i tried to create one more object with the same value "abc"
 	  It wont allow to create one more object. Creating multiple objects, it will increase the cost and reduce the performance.
 	  Immutable Strings increase the security, as they cannot modified once they created.
 
10. StringBuffer VS StringBuilder
Ans: StringBuffer is synchronized  i.e Thread safe
	 StringBuffer is less efficient than StringBuilder.
	 StringBuffer was introduced in Java 1.0.

	 StringBuilder is non-synchronized i.e not a thread safe.
	 StringBuilder is more efficient than StringBuffer.
	 StringBuilder was introduced in Java 1.5

11. Write a code in java to prove that String objects are immutable?
Ans: String s1 ="code"
	 // print s1 hash code
 	 s1 = s1+"decode";
	 // print s1 hash code.
 
12. Why StringBuffer and StringBuilder introduced already exists String class?
Ans: We all know String is immutable. If we try to modify them, a new object will be created with modified content.
 	  Creating multiple objects may cause memory and performance issue.
 	  If i want to performing lots of string modification then i will go for StringBuffer or StringBuilder.
 	  
13. How to call String methods using string literals?
Ans:	System.out.println("w3spoint".charAt(3));
		System.out.println("w3spoint".indexOf('i'));

How can you make a class Immutable?
Ans: 1. Declare the class as final so it can't be extended.
	 2. make all fields private and final so that direct access is not allowed and value can be assigned only once and it can't be changed.
	 3. Don't provide setter methods for variables.
	 4. Initialize all the fields via a constructor performing a deep copy.
	 5. Perform cloning of objects in the getter methods to return a copy rather than returning the actual object reference.
	 
	  