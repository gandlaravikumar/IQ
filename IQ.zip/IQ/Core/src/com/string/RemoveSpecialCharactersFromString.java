package com.string;

public class RemoveSpecialCharactersFromString {

	// input : $ja!va!&st%ar
	// output : javastar
	
	public static void main(String[] args) {
		String s = "$ja!va!&st%ar";
		// in regular expression below ^ represents other than this
		s = s.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(s);
	}
}


// input.replace(oldchar, newchar) is used to replace the old substring with the new substring
// input.replaceAll(regex, replacement) is used to replace the regular expressions in entire string.