package com.string;

public class RemoveWhiteSpacesFromString {
	
	// Input : ja va st a r
	// Output: javastar

	public static void main(String[] args) {
		
		String input = " ja va st a r ";
		String trimmedString = input.trim(); // only it will remove spaces from first and last of the string
		System.out.println(trimmedString);
		
		
		String NoSpace = input.replaceAll("\\s", "");
		System.out.println(NoSpace);
	}

}
