package com.string;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateCharactersInString {
	// input : programming
	// output : progamin
	
	public static void main(String[] args) {
		String input = "programming";
		
		// Approach 1
		usingJava8(input);
		
		// Approach 2
		usingIndexof(input);
		
		// Approach 3
		usingNestedForLoop(input);
		
		// Approach 4
		usingSetinterface(input);
		
	}

	private static void usingJava8(String input) {
		StringBuilder sb = new StringBuilder();
		input.chars().distinct().forEach(c -> sb.append((char) c));
		System.out.println(sb);
	}
	
	private static void usingIndexof(String input) {
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<input.length(); i++) {
			char c = input.charAt(i);
			// indexOf(c, i+1) is using for to check the (c) character is available or not in the input string from the (i+1) index.
			// if not available it will return -1
			int idx = input.indexOf(c, i+1);
			if(idx == -1) {
				sb.append(c);
			}
		}
		System.out.println(sb);
		
	}
	
	private static void usingNestedForLoop(String input) {
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<input.length(); i++) {
			boolean repeated = false;
			for(int j=i+1; j<input.length(); j++) {
				if(input.charAt(i)==input.charAt(j)) {
					repeated = true;
					break;
				}
			}
			if(!repeated) {
				sb.append(input.charAt(i));
			}
		}
		System.out.println(sb);
	}


	private static void usingSetinterface(String input) {
		StringBuilder sb = new StringBuilder();
		Set<Character> set = new LinkedHashSet<Character>();
		for(int i=0; i<input.length(); i++) {
		set.add(input.charAt(i));
		}
		
		for(Character c : set) {
			sb.append(c);
		}
		System.out.println(sb);
	}
}
