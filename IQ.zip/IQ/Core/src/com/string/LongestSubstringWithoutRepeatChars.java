package com.string;

import java.util.LinkedHashMap;
import java.util.Map;

public class LongestSubstringWithoutRepeatChars {
	
	//input : abbac
	//output : bac - 3
	
	//input : abcabcdbb
	//output : abcd - 4
	
	//input :java
	//output : jav -3
	
	public static void main(String[] args) {
		String longestSubString = null;
		int longestSubStringLength = 0;
		String s = "abbac";
		char[] charArray = s.toCharArray();
		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();
		
		for(int i=0; i<charArray.length; i++) {
			char ch = charArray[i];
			if(!map.containsKey(ch)) {
				map.put(ch, i);
			} else {
				i = map.get(ch);
				map.clear();
			}
			if(map.size() > longestSubStringLength) {
				longestSubStringLength = map.size();
				longestSubString = map.keySet().toString();
			}
		}
		System.out.println("The longest substring :"+longestSubString);
		System.out.println("The longest substring length :"+longestSubStringLength);
	}

}
