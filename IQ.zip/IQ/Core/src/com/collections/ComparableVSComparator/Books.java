package com.collections.ComparableVSComparator;

import java.util.Comparator;

public class Books implements Comparator<Books>{
	
	private String name;
	private int price;
	private int version;
	
	
	
	public Books() {
		super();
	}
	public Books(String name, int price, int version) {
		super();
		this.name = name;
		this.price = price;
		this.version = version;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	@Override
	public String toString() {
		return "Books [name=" + name + ", price=" + price + ", version=" + version + "]";
	}
	@Override
	public int compare(Books o1, Books o2) {
		if(o1.price > o2.price) {
			return 1;
		} else if(o1.price < o2.price) {
			return -1;
		} else {
			return 0;
		}
	}
	
}
