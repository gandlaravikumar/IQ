package com.collections.ComparableVSComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableExample {

	public static void main(String[] args) {
		
		/* Defaultly String class implements comparable interface */
		// list of String values
		List<String> names = new ArrayList<String>();
		names.add("ramu");
		names.add("ramesh");
		names.add("vijay");
		names.add("manohar");
		names.add("ravi");
		
		// sorting list of String values
		Collections.sort(names);
		for (String string : names) {
			//System.out.println(string);
		}
		
		/* Defaultly Integer class implements comparable interface */
		// list of Integer values
		List<Integer> numbers = new ArrayList<Integer>();
		numbers.add(2);
		numbers.add(23);
		numbers.add(5);
		numbers.add(74);
		numbers.add(27);
		
		// sorting list of String values
		Collections.sort(numbers);
		for (Integer num : numbers) {
			System.out.println(num);
		}

		/* Defaultly Laptop class doesn't implements comparable interface. so we need to implement comparable interface
		 * in Laptop class. And need to implement one abstact method i.e compareTo(Laptop o) */
		// list of Laptop objects
		List<Laptop> laps = new ArrayList<Laptop>();
		laps.add(new Laptop("Dell", 16, 800));
		laps.add(new Laptop("Acer", 12, 700));
		laps.add(new Laptop("Apple", 8, 1200));
		
		// sorting list of Laptop values
		Collections.sort(laps);
		for (Laptop l : laps) {
			System.out.println(l);
		}
	}
}
