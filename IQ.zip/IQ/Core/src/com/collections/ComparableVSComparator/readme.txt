Comparable:
1. Available in java.lang package.
2. single sorting sequence.
3. compareTo() method to sort elements.
4. affects the original class, i.e., the actual class is modified.
5. We can sort the elements of Comparable type by Collections.sort(List) method.

Comparator:
1. Available in java.util package.
2. multiple sorting sequences.
3. compare() method to sort elements.
4. doesn't affect the original class, i.e., the actual class is not modified.
5. We can sort the elements of Comparator type by Collections.sort(List, Comparator) method.

Note: Both are functional Interfaces only. (Which is having only one abstract method)