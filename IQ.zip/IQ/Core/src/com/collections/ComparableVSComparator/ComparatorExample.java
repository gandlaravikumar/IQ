package com.collections.ComparableVSComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorExample {
	
	public static void main(String[] args) {
		// list of Books objects
		List<Books> books = new ArrayList<Books>();
		books.add(new Books("Java", 350, 8));
		books.add(new Books("Cpp", 294, 2));
		books.add(new Books("Spring",432, 5));
		books.add(new Books("English",220, 3));
		
		// Method 1: If the Books class is implemented Comparator interface.
		
		  Collections.sort(books, new Books());
		  
		  for (Books b : books) { 
			  System.out.println(b); 
			  }
		 
		
		// Method 2: If the Books class is not implemented Comparator interface.
		// i need to create Comparator object. (Anonymous Inner Type) and pass this Comparator object in Collections.sort method.
		
		/*
		 * Comparator<Books> comparator = new Comparator<Books>() {
		 * 
		 * @Override public int compare(Books o1, Books o2) {
		 * 
		 * return o1.getName().compareTo(o2.getName()); }
		 * 
		 * };
		 * 
		 * Collections.sort(books, comparator);
		 * 
		 * for(Books b : books) { System.out.println(b); }
		 */
		
	}

}
