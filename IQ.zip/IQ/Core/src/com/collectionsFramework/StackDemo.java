package com.collectionsFramework;

import java.util.Iterator;
import java.util.Stack;

/*The stack is the subclass of Vector. It implements the last-in-first-out data structure.
The stack contains all of the methods of Vector class and also provides its methods like boolean push(object o), pop(), boolean peek().
The elements are added as well as removed from the rear end*/
public class StackDemo {
	public static void main(String args[]){  
		Stack<String> stack = new Stack<String>();  
		stack.push("Ayush");  
		stack.push("Garvit");  
		stack.push("Amit");  
		stack.push("Ashish");  
		stack.push("Garima");  
		String s = stack.pop(); // pop() removes an element from the top of the stack and returns the same element.
		stack.peek(); // peek() method looks at the top element of the stack without removing it.
		Iterator<String> itr=stack.iterator();  
		while(itr.hasNext()){  
		//System.out.println(itr.next());  
		}  
		}  
}
