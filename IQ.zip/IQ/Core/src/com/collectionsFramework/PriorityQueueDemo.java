package com.collectionsFramework;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;
import java.util.Queue;

/*The PriorityQueue class implements the Queue interface. It holds the elements or objects which are to be processed by their priorities.
PriorityQueue doesn't allow null values to be stored in the queue.
*/public class PriorityQueueDemo {
	public static void main(String args[]){  
		Queue<String> queue=new PriorityQueue<String>();  
		queue.add("Amit Sharma");  
		queue.add("Vijay Raj");  
		queue.add("JaiShankar");  
		queue.add("Raj");  
		System.out.println("head:"+queue.element());  // It will return the head of this queue. throws NoSuchElementException if this queue is empty.
		System.out.println("head:"+queue.peek());  // It will return the head of this queue. or return null if this queue is empty.
		System.out.println("iterating the queue elements:");  
		Iterator itr=queue.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		}  
		String removedQueue = queue.remove();   // It will removes the head of this queue and returned that value. throws NoSuchElementException if this queue is empty.
		String pollQueue = queue.poll();  // It will removes the head of this queue and returned that value. or return null if this queue is empty.
		System.out.println("after removing two elements:");  
		Iterator<String> itr2=queue.iterator();  
		while(itr2.hasNext()){  
		System.out.println(itr2.next());  
		}  
		}  
}
