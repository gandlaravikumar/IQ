package com.collectionsFramework;

import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

/*HashMap is non-Synchronized in nature i.e. HashMap is not Thread-safe whereas ConcurrentHashMap is Thread-safe in nature.*/
// ConcurrentHashMap doen't allow any null key and null value like HashTable. If you try to add you will get nullPointerException.
public class ConcurrentHashMapExample {

	public static void main(String[] args) {
		// If i use the below one HashMap and try to add a element while iterating then it will throw ConcurrentModificationException.
		// If you want to try uncomment the below HashMap and comment the ConcurrentHashMap
		// HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		
		// If i use the below one ConcurrentHashMap and try to add a element while iterating then it will not throw any Exception. So this is Fail-safe.
		ConcurrentHashMap<Integer, Integer> map = new ConcurrentHashMap<Integer, Integer>();
		map.put(1, 1);
		map.put(2, 2);
		map.put(3, 3);
		
		Iterator<Integer> itr = map.keySet().iterator();
		while(itr.hasNext()) {
			Integer key = itr.next();
			System.out.println("Map value:" + map.get(key));
			if(key.equals(2)) {
				map.put(4, 4);
			}
		}

	}

}
