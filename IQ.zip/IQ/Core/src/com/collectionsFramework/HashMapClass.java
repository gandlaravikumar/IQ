package com.collectionsFramework;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/*Java HashMap contains values based on the key.
Java HashMap contains only unique keys.
Java HashMap may have one null key and multiple null values.
Java HashMap is non synchronized.
Java HashMap maintains no order.*/
public class HashMapClass {

	public static void main(String[] args) {
		Map<Integer,String> map=new HashMap<Integer,String>();          
	      map.put(100,"Amit");    
	      map.put(101,"Vijay");    
	      map.put(102,"Rahul");   
	      //Returns a Set view of the mappings contained in this map        
	      map.entrySet()
	      //Returns a sequential Stream with this collection as its source  
	      .stream()  
	      //Sorted according to the provided Comparator  
	      .sorted(Map.Entry.comparingByKey())  
	      //Performs an action for each element of this stream  
	      .forEach(System.out::println);
	      
	      // Note: 1. https://www.javatpoint.com/java-map
	      // 2. https://www.javatpoint.com/java-hashmap
	      // Interview questions is there
	      
	      // convert from HashMap (non-synchronized) to SynchronizedMap (synchronized)
	      // From not a thread safe to thread safe.
	      Map<Integer,String> synchronizedMap = Collections.synchronizedMap(map);
	      System.out.println(synchronizedMap);
	      
	      // This is the way of printing key and value. (Take the set(entrySet) and iterate it)
		     Set<Map.Entry<Integer, String>> entrySet =  map.entrySet();
		     for(Map.Entry<Integer, String> e : entrySet) {
		    	 System.out.println(e.getKey()+" : "+e.getValue());
			    }
	      
	     // This is way of printing values by passing keys in get() method. (Take the set(keySet) and iterate it)
	    Set<Integer> keys = map.keySet();
	    for(Integer i : keys) {
	    	System.out.println(map.get(i));
	    }
	    
	    // This is the way of printing all keys
	    System.out.println("Keys "+map.keySet());
	    // This is the way of printing all values
	    System.out.println("values "+map.values());
	    
	    // This is way to print map in java8
	    map.entrySet().forEach(System.out::println);
	}
	
	// HashTable is synchronized
	// HashMap is nonSynchronized
	// SynchronizedMap is Synchronized
	// ConcurrentHashMap is Synchronized

}
