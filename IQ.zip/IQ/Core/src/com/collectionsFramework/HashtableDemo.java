package com.collectionsFramework;

import java.util.Hashtable;
import java.util.Map;

/* Hashtable used to store the data in key and value form. Using hashing technique to store unique keys.
* Hashtable class extends Dictionary class and implements the Map interface.*/
/*A Hashtable is legacy and it contains an array of a list. Each list is known as a bucket. The position of the bucket is identified by calling the hashcode() method. A Hashtable contains values based on the keys like Map.
Java Hashtable class contains unique elements.
Java Hashtable class doesn't allow null key or value.
Java Hashtable class is synchronized.
The initial default capacity of Hashtable class is 11 whereas loadFactor is 0.75.*/

/*I don't want to use HashTable, until the application is legacy or Synchronized application. Because This is Thread-safe, null keys and values are not allowed, 
and also slow performance because entire object is locked by a thread.
The same features are available in concurrentHashMap with fast performance, because only write operation bucket is locked by thread, not entire object is lock.
If i want concurrent modification then i will go for concurrentHashMap else i will go for Hashtable.*/
public class HashtableDemo {

	public static void main(String[] args) {
		Map<Integer,String> hm=new Hashtable<Integer,String>();  
		  
		  hm.put(100,"Amit");  
		  hm.put(102,"Ravi");  
		  hm.put(101,"Vijay");  
		  hm.put(103,"Rahul");  
		  
		  for(Map.Entry m:hm.entrySet()){  
		   System.out.println(m.getKey()+" "+m.getValue());  
		  } 
		  
		  hm.remove(102);
		  System.out.println("After remove: "+ hm);  
		  
		  
		  System.out.println(hm.getOrDefault(101, "Not Found")); 
		  System.out.println(hm.getOrDefault(105, "Not Found")); 
		  
		  hm.putIfAbsent(104,"Gaurav"); 
	}
	
}
