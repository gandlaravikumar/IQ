Difference between Array and ArrayList?
Array:
Array is static in size.
can store both objects or primitives type. eg: Integer[] integerArr = new Integer[10]; or int[] intArr= new int[10]; 
It performs fast in comparison to ArrayList because of fixed size.
It is mandatory to provide the size of an array while initializing.
Generics are not compatible with Arrays.
Array can use multi-dimensional. eg: int[][][] intArray = new int[10][10][5];
Array provides a length variable which denotes the length of an array. eg: intArray.length;
The assignment operator is used for the storage the elements. eg: intArray[0]=1;
	  
ArrayList:
ArrayList is dynamic in size. it can be resized itself when needed.
We cannot store primitive type in ArrayList. Only we can store Object type. eg: ArrayList<Integer> arrayList = new ArrayList<>();
resize() operation: automatic resize will slow down the performance, as it use temporary array to copy the elements from old array.
No need to provide the size to initializing.
ArrayList allow the use of Generics.
ArrayList is always single dimensional.
ArrayList provides the size() method to determine the size of ArrayList. eg: arrayList.size();
add() method is utilized for the  insertion of elements in an ArrayList. eg: arrayList.add(1);
		  
Internally ArrayList uses dynamic Array only to store the elements. Internally ArrayList size starts from 10. 
If you try to add the 11th element, automatically ArrayList size will increase up to 50%. means 10+5 = 15. 
 
Difference between ArrayList and Vector?
ArrayList:
ArrayList is not synchronized. Not Thread safe.
Programmers prefer ArrayList over Vector because ArrayList can be synchronized explicitly using Collections.synchronizedList.
ArrayList is fast because it is non-synchronized.
ArrayList is not a legacy class. It is introduced in JDK 1.2.
ArrayList initial capacity is 10. If i try to add the 11th element, it will increments 50% of current array size. i,e 15.
ArrayList uses the Iterator interface to traverse the elements.

Vector:
Vector is synchronized. Thread safe.
Vector is slow because it is synchronized.
Vector is a legacy class.
Vector can use the Iterator interface or Enumeration interface to traverse the elements.


Difference between ArrayList and LinkedList? (Both are contains duplicate element, maintains insertion order, non synchronized)
ArrayList:
ArrayList internally uses a dynamic array to store the elements.
ArrayList implements only List interface.
Manipulation with ArrayList is slow because it internally uses an array. If any element is removed from the array, all the other elements are shifted in memory.
ArrayList is faster in storing and accessing the data as internally dynamic Array is used which has random access.
There is no desendingIterator() in ArrayList.

LinkedList:
LinkedList uses Doubly Linked List to store the elements.
LinkedList implements List as well as Queue. It can acts as a queue as well.
Manipulation with LinkedList is faster then ArrayList because it used a doubly linked list, so no bit shifting is required in memory.
LinkedList is slower than ArrayList in storing and accessing the data. because accessing required node by node traversal.
LinkedList can be iterated in reverse direction using desendingIterator()

Conclusion: If there is a requirement of frequent addition and deletion in application then LinkedList is a best choice.
If more search operations requirement, ArrayList would be your best option.

	 