package com.collectionsFramework;

import java.util.TreeMap;

/*Java TreeMap contains values based on the key. It implements the Sorted Map interface and extends the Map interface.
Java TreeMap cannot have a null key but can have multiple null values.
Java TreeMap is non synchronized.
Java TreeMap maintains ascending order.*/
public class TreeMapDemo {
	
	public static void main(String[] args) {
		TreeMap<String, Integer> treeMap = new TreeMap<String, Integer>();
		
	}
}
