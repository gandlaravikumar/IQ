package com.multithreading;

class Counter {
	
	int count;

	/*
	 * suppose if t1 comes here and trying to increment count value, at the same
	 * time t2 also comes and try to increment. If 2 times increment means count
	 * should be 2. but both the treads increment at a same means count will be 1
	 * only. to over come that problem, if t1 working on increment, t2 should wait.
	 * If t2 working on increment t1 should wait. so the method should be
	 * synchronized.
	 */
	/*
	 * point to remember : If i don't make this method as synchronized, then this
	 * method or this class object (Counter c = new Counter()) is not a thread safe.
	 * means multiple threads can access this method at a same time.
	 */
	// If there is any dependency between t1 and t2 then i should go for synchronized else non-synchronized.
	// If i make this method synchronized, means only one thread can work with this method at a time.
	public synchronized void increment() {
		count++;
	}
}

public class SynchronizedKeyword {

	public static void main(String[] args) {
		Counter c = new Counter();
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				for(int i=1; i<=1000; i++) {
					c.increment();
				}
			}
		});
		
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				for(int i=1; i<=1000; i++) {
					c.increment();
				}
			}
		});
		
		t1.start();
		t2.start();
		
		// asking main tread to wait until t1 is done. so that main thread don't print sytem.out.println until t1 is done. 
		try {
		t1.join();
		t2.join();
		} catch (Exception e) {
		}
		
		System.out.println("count is "+c.count);
	}
}
