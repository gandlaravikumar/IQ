package com.multithreading;

/*in this ThreadSleepDemo class am calling 2 threads at a same time. i want to wait a thread sometime in that time 2nd thread
should execute and wait sometime so on.*/
// Thread.start() method, it will create a new thread and that thread will call automatically run() method.

class Hi extends Thread{
	
	public void run() {
		for(int i=0; i<5; i++) {
			System.out.println("Hi");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}

class Hello extends Thread{
	public void run() {
		for(int i=0; i<5; i++) {
			System.out.println("Hello");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

public class ThreadSleepDemo {

	public static void main(String[] args) {
		
		Hi t1 = new Hi();
		Hello t2 = new Hello();
		
		
		// start the t1 object (1st object)
		t1.start();
		
		// By default every class having Main thread.
		// applying sleep method for Main thread. Because i don't want to start the 2 objects (t1 and t2) at a same time.
		
		try {
			// Here sleep method will throw checked Exception. so need to implement try catch block.
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		// start the t2 object (2nd object)
		t2.start();
		
		
		// Join Method
		// join method is used to hold the thread until the current thread done with their job.
		/*
		 * In the above code t1.start will create a new Thread and doing their job. same
		 * like t2.start will create a new thread and doing their job. In between
		 * Main thread will try to do their job. means trying to print the "Bye".
		 */
		// so we need to say to Main thread, just hold on until the t1 and t2 are done with their jobs.
		
		// Before join i will check thread is alive or not
		System.out.println("before join t1 is "+t1.isAlive());
		
		// join the t1 and t2
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// once the thread job is done it will be dead.
		System.out.println("after join t1 is "+t1.isAlive());
		System.out.println("Bye");
	}
}
