package com.multithreading;

/*in this RunnableSleepDemo class am calling 2 threads at a same time. i want to sleep a thread sometime in that time 2nd thread
should execute and sleep sometime so on.*/
/*Here am unsing Runnable interface. which is @FunctionalInterface*/
// Thread.start() method, it will create a new thread and that thread will call automatically run() method.
class A implements Runnable {
	
	public void run() {
		for(int i=0; i<5; i++) {
			System.out.println("A");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}

class B implements Runnable {
	public void run() {
		for(int i=0; i<5; i++) {
			System.out.println("B");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

public class RunnableSleepDemo {

	public static void main(String[] args) {
		
		A a = new A();
		B b = new B();
		
		/*
		 * Runnable interface don't have start method like Thread class. so i need to
		 * create Thread object manually. Then i need to pass runnable target into that
		 * Thread object.
		 */
		Thread t1 = new Thread(a);
		Thread t2 = new Thread(b);
		
		// converted the runnable interfaces (class A and class B) to Threads (t1 and t2). So now start method available.
		t1.start();
		t2.start();
	}
}
