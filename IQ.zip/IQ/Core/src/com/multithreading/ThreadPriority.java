package com.multithreading;

public class ThreadPriority {
	public static void main(String[] args) {
		
		Thread t1 = new Thread();
		Thread t2 = new Thread();
		
		// some times if i working with multiple threads, i don't know which thread is doing what.
		// so i can define the names to threads and use it later.
		
		// print the name of the thread
		System.out.println("Before set the name t1 name is "+t1.getName());
		System.out.println("Before set the name t2 name is "+t2.getName());
		
		//set the names to threads
		t1.setName("hi");
		t2.setName("hello");
		
		System.out.println("After set the name t1 name is "+t1.getName());
		System.out.println("After set the name t2 name is "+t2.getName());
		
		// get Priority of the thread
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		
		// set the Priority of the thread.
		t1.setPriority(Thread.MIN_PRIORITY);
		t2.setPriority(Thread.MAX_PRIORITY);
	}


}
