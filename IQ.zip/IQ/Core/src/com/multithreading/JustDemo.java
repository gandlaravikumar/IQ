package com.multithreading;
/*When the JVM starts, it creates a thread called "Main". your program will run on this "Main" thread, unless you create additional threads yourself.
The first thing the "Main" thread is looking for your main method and use it. That is the entry-point to your program. If you create
additional threads in the main method those threads would be the child threads of main thread.*/

public class JustDemo {

	public static void main(String[] args) {
		// This Main thread is created by the JVM defaultly.
		//when the program runs, the main thread will search for main method and execute.
		System.out.println(Thread.currentThread().getName());
	}
}
