package com.multithreading;

public class MainClass {

	public static void main(String[] args) {
		ThreadClass tc = new ThreadClass();
		// To make the user thread as Daemon Thread.
		 //tc.setDaemon(true);
		tc.start();
		
		for(int i=0; i<10; i++) {
			System.out.println(i +" printing from Main thread");
		}
		

	}

}
