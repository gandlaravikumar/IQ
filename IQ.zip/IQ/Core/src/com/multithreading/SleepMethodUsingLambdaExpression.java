package com.multithreading;
// recreate the RunnableSleepDemo class by using Lambda Expression, to reduce the code length and works more efficient.

public class SleepMethodUsingLambdaExpression {

	public static void main(String[] args) {
		/*
		 * If i create a new class which implements runnable interface that class will use only one time.
		 * After that i need to create Thread class object first and need to pass the runnable target to that thread object.
		 * Instead of doing that things and all, create a anonymous Thread class object and pass the runnable value.
		 */
		Thread t1 = new Thread(() -> 
		{
			for(int i=0; i<5; i++) {
				System.out.println("X");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
		Thread t2 = new Thread(() -> 
		{
			for(int i=0; i<5; i++) {
				System.out.println("Y");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
		
		t1.start();
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		t2.start();
	}
}
