package com.multithreading;

public class ThreadClass extends Thread {
	
	@Override
	public void run() {
		
		for(int i=0; i<100; i++) {
			System.out.println(i +" printing from child thread");
		}
	}

}
