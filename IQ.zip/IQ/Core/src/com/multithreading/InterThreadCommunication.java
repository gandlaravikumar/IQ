package com.multithreading;

/*There are 2 threads t1 and t2. If t1 is produce some value and t2 will consume that value.
Means t1 and t2 is communication with each other. That is called Inter Thread Communication*/
//setNum() and getNum() should be synchronized. Because only one thread should be access at a time. If Producer thread is working, Consumer thread should wait. and vice versa.
// In which method wait() is used. That method should be synchronized.
class Q {
	int num;
	boolean isValueSet = false;
	
	public synchronized void setNum(int num) {
		
		while(isValueSet) {
			try { wait();} catch (InterruptedException e) {	}
		}
		System.out.println("set "+num);
		this.num = num;
		isValueSet = true;
		notify();
	}
	
	public synchronized void getNum() {
		while(!isValueSet) {
			try { wait();} catch (InterruptedException e) {	}
		}
		System.out.println("get "+num);
		isValueSet = false;
		notify();
	}
	
}

class Producer implements Runnable {
	Q q;

	public Producer(Q q) {
		this.q = q;
		Thread t1 = new Thread(this, "Producer");
		t1.start();
	}
	
	public void run() {
		int i=0;
		while(true) {
			q.setNum(i++);
			try { Thread.sleep(1000); } catch(Exception e) {}
		}
	}
}

class Consumer implements Runnable {
	Q q;
	public Consumer(Q q) {
		this.q = q;
		Thread t2 = new Thread(this, "Consumer");
		t2.start();
	}
	
	public void run() {
		while(true) {
			q.getNum();
			try { Thread.sleep(1000); } catch(Exception e) {}
		}
	}
}

public class InterThreadCommunication {
	public static void main(String[] args) {
		Q q = new Q();
		new Producer(q);
		new Consumer(q);
	}
	
}
