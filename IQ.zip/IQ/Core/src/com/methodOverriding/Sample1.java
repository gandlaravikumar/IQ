package com.methodOverriding;

// Difference between Object o = new Sample1(); and Sample1 c = new Sample1();
public class Sample1 {
	
	public void test() {
		System.out.println("simple test");
	}
	
	public static void main(String[] args) {
		// If i don't know the runtime return type then i go for
		Object o = new Sample1();
		/*
		 * 1. If we don't know exact runtime return type of Object then we should use this approach. 
		 * we can use parent reference to hold any type of object.
		 * 2. By using this approach (parent reference) we can call only
		 * methods available in parent class and child specific methods we can't call. If we want we can override through child class.
		 */	
		
		// If i know the return type
		Sample1 c = new Sample1();
		/*
		 * 1. If we know exact runtime type of Object then we should use this approach. 
		 * we can use child reference to hold only for that particular child class object only.
		 * 2. By using this approach (child reference) we can call both parent and child class methods.
		 */	
	}

}
