package com.methodOverriding;

class Parent {

	public void name() {
		System.out.println("LOKA");
	}
}

public class Child extends Parent{

	public void name() {
		System.out.println("RAVI");
	}

	public static void main(String[] args) {
		Child c = new Child();
		c.name();
		
		Parent p = new Parent();
		p.name();
		
		// Upcasting (reference variable of Parent class/Interface refers to the object of Child class is called Upcasting)		
		Parent p1 = new Child(); // converting child to parent is called Upcasting.
		p1.name();
		
		// Performing Downcasting Explicitly 
		Child c1 = (Child) p1;  // converting parent to child is called Downcasting.
		c1.name();
		
		// we can't convert parent to child Implicitly. It will get classcastexception.
		//Child c2 = new Parent(); // it gives compile-time error  
	}

}


// when we use upcasting and nocasting
// If we don't know exact runtime return type of object then we should go for Parent p = new Child();
// If we know exact runtime return type of object then we should go for Child c = new Child();
