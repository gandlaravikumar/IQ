Parent p1 = new Child();
		p1.name();
If both methods are non static, It depends up on type of Object what we created. child class (Child) is invoke. (method overriding)
If both methods are static, It depends up on type of reference variable. parent class (Parent) is invoke. (method hiding)


Both methods must be static or non static. Else compile time error.

When both methods are static methods, actually we do not call as method overriding. This is called as method hiding.
If any static method is there, that method belongs to the part of class, it is not related to instance of the class.


public		--> strongest
protected	--> weak
Default		--> weaker
private		--> weakest


Either the access privileges must be same or weaker to stronger is allowed. Else compile time error. (Cannot reduce the visibility Exception)

child method access privileges should be same as parent method or stronger than parent method.

If parent method and child method throws unchecked exceptions also. It will not get any problem and No rules and conditions.

child class only can't throw a broader checked exception (Exception).