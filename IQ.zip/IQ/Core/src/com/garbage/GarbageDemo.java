package com.garbage;

/*How can the garbage collection be requested?
		Ans : There are two ways in which we can request JVM to execute the garbage collection.
		1) Call the System class System.gc() method which will request the jvm to perform GC.
			Example : System.gc();
		2) Runtime is a class which provides some methods to perform GC. The method getRuntime() returns the singleton object of Runtime class.
			The method gc() can be invoked using the Runtime object to request the GC.
			Example : Runtime.getRuntime().gc();*/
public class GarbageDemo {
	
	GarbageDemo gcDemo3;
	public static void main(String[] args) {
		GarbageDemo gcDemo1 = new GarbageDemo();
		GarbageDemo gcDemo2 = new GarbageDemo();
		
		gcDemo1 = null; // eligible for GC
		gcDemo1 = gcDemo2; // eligible for GC
		
		// Creating Islands of Isolation
		gcDemo1.gcDemo3 = gcDemo2;
		gcDemo2.gcDemo3 = gcDemo1;
		
		gcDemo2 = null;
		
		// method 1
		System.gc();
		System.out.println("Method1 is done");
		
		// Method 2
		Runtime.getRuntime().gc();
		System.out.println("Method2 is done");
	}
	/*
	 * What is the purpose of overriding finalize() method? 
	 * Ans: It's called by GC just before collecting any object which is eligible for GC.
	 * Thus Finalize() method provides last chance to object to do cleanup and free any remaining resource.
	 */
	  
	@Override
	protected void finalize() throws Throwable {
	System.out.println("finalize method is called");
	}

}
