package com.newfeatures;

/*what happens in sequential stream?
Ans; 1. suppose there are 4 cores in my machine. core1, core2, core3, core4.
	 2. If i execute sequential stream, that stream will divided into 4 threads. t1, t2, t3, t4. and all the threads will run in core1 only.
	 3. Remaining 3 cores (core2, core3, core4) are empty. This is bad in performance, and bad in memory utilization.
	 4. The output of this sequential stream is T1,T2,T3,T4.
	 5. Might be t4 depends on t3, t3 depends on t2, t2 depends on t1. means all t1, t2, t3, t4 are depends on each other. */

/*What happens in parallel stream?
Ans: 1. parallel stream means utilize multiple cores of processor.
	 2. But when you use parallel streams, we divide code into multiple streams that executes parallely on seperate cores and
	 	finally result is the outcome of individual cores outcomes combined.
	 3. suppose there are 4 cores in my machine core1, core2, core3, core4.
	 4. Let me divide my stream into 4 threads. t1,t2,t3,t4. On core1 t2. On core2 t4. on core3 t1. on core4 t3 is executing
	 5. The output of this parallel stream is T2,T4,T1,T3. Not in sequential order.
	 6. Order of execution is not under control
	 7. Use parallel stream only when order of execution of threads does not matter and threads are independent each other*/

public class Paraller_Stream {

}
