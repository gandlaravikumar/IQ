package com.newfeatures;

/*If a class implements 2 interfaces. That 2 interfaces having same default methods. Then that is the diamond problem.
*/
public class DiamondProblemClass implements FunctionalInterfaceDemo1, FunctionalInterfaceDemo2{

	public static void main(String[] args) {
		DiamondProblemClass diamondProblemClass = new DiamondProblemClass();
		diamondProblemClass.firstName();

	}
	
	// Solution to diamond problem is--- the syntax is below
	// InterfaceName.super.methodName();
	@Override
	public void firstName() {
		FunctionalInterfaceDemo1.super.firstName();
	}
	

	@Override
	public void singleAbstMethod() {
		// TODO Auto-generated method stub
	}

}
