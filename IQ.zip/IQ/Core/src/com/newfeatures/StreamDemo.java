package com.newfeatures;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/*What are Streams?
Stream is an interface, available in java.util.stream package.
The Stream API is used to process collections of objects.
If we want to process bulk objects of collection then go for stream concept.
It's a special iterator class that allows processing collections of objects in a functional manner.
*/

public class StreamDemo {

	public static void main(String[] args) {
		List<Integer> arList = Arrays.asList(15, 25, 5);
		
		// configuration of the streams can be done by 2 ways (filter and map)
		
		// filter (In filter original elements are not going to change)
		List<Integer> filterList = arList.stream().filter(x -> x >= 15).collect(Collectors.toList());
		filterList.stream().forEach(x -> System.out.println(x));
		
		// map (In map original elements are going to change)
		// 15 is mapped with 15*15, 25 is mapped with 25*25, 5 is mapped with 5*5.
		arList.stream().map(x -> x*x).forEach(x -> System.out.println(x));
		
		//processing a stream in different ways like (Collect, Count, Sorted, Min, Max, forEach, toArray, of() ect...)
		
		//collect
		//Definition :If we want to collect elements of stream after filtering or mapping and add them to the required collection then use collect method.
		List<Integer> collectList= arList.stream().filter(i -> i> 5).collect(Collectors.toList());
		collectList.forEach(x -> System.out.println(x));
		
		//count
		//If we want to count how many elements are there in collection that satisfy given condition then use count() method
		long filterCount = arList.stream().filter(x -> x>=15).count();
		System.out.println("filteredCount "+filterCount);
		long rawCount = arList.stream().count();
		System.out.println("rawCount "+rawCount);
		
		//sorted
		// 1. If we want to sort elements inside a stream use this sorted() method. This is default natural sorting order.
		// 2. if we want to sort using customized sorting order then use comparator.
		arList.stream().filter(x -> x>=15).sorted().forEach(x -> System.out.println(x));
		
		// sorted in Descending order
		arList.stream().sorted((i1, i2) -> i2.compareTo(i1)).forEach(x -> System.out.println(x));
		
		//min (First it will sort the values based on defined condition. From that sorted list first element is the min value)
		Integer minValue = arList.stream().min((i1, i2) -> i1.compareTo(i2)).get();
		System.out.println(minValue);
		//max (First it will sort the values based on defined condition. From that sorted list last element is the max value)
		Integer maxValue = arList.stream().max((i1, i2) -> i1.compareTo(i2)).get();
		System.out.println(maxValue);
		
		//forEach()
		// All methods that we saw till now returned something, like min max value, sorted collection etc.
		// This method does not return anything.
		// It is used to print the elements from stream.
		
		//toArray
		//we can use this method to copy elements from stream to specified array.
		// Note: toArray() always returns Object[].
		Stream<Integer> streamValues = arList.stream();
		Object[] objArray = streamValues.toArray();
		for (Object object : objArray) {
			System.out.println("element in array is "+object);
		}
		
		//of()
		// 1. Stream concept is not application just for the collections it's also applicable for"ANY GROUP OF VALUE".
		// 2. even for arrays you can use stream.
		// Stream.Of() this method can take any group of values(Array of values) and convert them to stream so that multiple stream operations can be applied to it.
		Stream.of(1,11,111,1111,11111).forEach(x -> System.out.println(x));
		
		String[] name = {"code", "decode", "demos"};
		Stream.of(name).filter(x -> x.length() > 4).forEach(x -> System.out.println(x));
		
	}

}
