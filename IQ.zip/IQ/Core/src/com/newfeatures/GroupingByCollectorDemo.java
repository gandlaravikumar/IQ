package com.newfeatures;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

/*Why do we need Grouping Collector?
Ans: Given a stream of objects, there are scenarios like where these objects belongs to which category.
	Eg: Create a map with key as Age and value as list of employees in that age group.
		                               or
		 count the no of occurrence of words in given string. and store in Map<String, Long>.*/

/*How Grouping Collector works?
Ans: Grouping collectors use a classification function, which is an instance of the Function<T,K>
	T - Type of object is stream.
	K - 'group names' or 'group keys'.
	for every value of K there is a collection of objects all of which return that value of K when subjected to the classification function.
	And finally all these K-values and corresponding Collection of stream objects are stored by the grouping collector in a Map<K, Collection<T>>*/
	

public class GroupingByCollectorDemo {

	public static void main(String[] args) {
		Student s1 = new Student(30, "ravi");
		Student s2 = new Student(45, "seenu");
		Student s3 = new Student(30, "naga");
		Student s4 = new Student(25, "Bhavana");
		Student s5 = new Student(1, "Gundu");
		Student s6 = new Student(30, "ravi");
		List<Student> list = Arrays.asList(s1,s2,s3,s4,s5,s6);
		
		// groupingBy collector using 1 parameter
		Map<Integer, List<Student>> mapResult = list.stream().collect(Collectors.groupingBy(emp -> emp.getAge()));
		System.out.println(mapResult);
		
		// By default internally it is storing the groups as Lists like (Collectors.groupingBy(emp -> emp.getAge(), Collectors.toList()));
		// If i want to store the groups as set, i can do like (Collectors.groupingBy(emp -> emp.getAge(), Collectors.toSet())).

		// groupingBy collector using 2 parameter
		// If there are duplicate persons like same name and same age.
		// Remember if you want to use set on custom object, you have to override hashCode and equals method and tell it. which particular field you want to be unique.
		Map<Integer, Set<Student>> uniqueMapResult = list.stream().collect(Collectors.groupingBy(emp -> emp.getAge(), Collectors.toSet()));
		System.out.println(uniqueMapResult);
		
		// In groupingBy collector there is 2 parameters are there.
		// 1st parameter will help you to give the group of elements.
		// 2nd parameter will help you how the group of elements need to be collected. like List or Set etc.
		
		// groupingBy collector using 3 parameter
		// It will sort based on ages
		Map<Integer, Set<Student>> sortedMapResult = list.stream().collect(Collectors.groupingBy(emp -> emp.getAge(), TreeMap::new, Collectors.toSet()));
		System.out.println(sortedMapResult);
		
	}

}

class Student {
	
	int age;
	String name;
	
	public Student(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
		public String toString() {
			return name;
		}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result +((name == null) ? 0 : name.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		if(obj == null)
			return false;
		if(getClass() !=obj.getClass())
			return false;
		Student other = (Student) obj;
		if(name == null) {
			if (other.name != null)
				return false;
		} else if(!name.equals(other.name))
			return false;
		return true;
	}
}