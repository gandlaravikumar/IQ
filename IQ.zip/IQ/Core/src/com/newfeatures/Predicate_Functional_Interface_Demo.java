package com.newfeatures;

import java.util.function.BiPredicate;
import java.util.function.Predicate;

/*what is Predicate?
 Ans: It is a pre defined functional interface (Having only 1 abstract method)
 The only abstract method of predicate is test(T t).
 public boolean test(T t);
 and It takes one input parameter and return boolean value as a result.*/

/*How to use Predicates?
Ans: Whenever we want to check some boolean condition then you can go for Predicates.
	 Example: if i need to test the length of the given string is greater than or equal to 5.
	 where you need to test conditions, use test() method of predicate.*/

/*Input to predicate can be anything like.
 1. Predicate<String>
 2. Predicate<Integer>
 3. Predicate<Employee>*/

/*Only one type argument is required which is input.
Return type is not required as it's always Boolean only.*/

/*Advantages of Predicates?
Ans: Code Reusability. Means declare one time and implement multiple times.
	 Means i declare one time in one class Predicate<String> checklength = s -> s.length() >= 5;
	 Implement will do from different classes and different times with different strings checklength.test("Ravidd");
	 Sortness in the code.
	 Conditional checks are holded by Functional Interfaces.*/
	 
public class Predicate_Functional_Interface_Demo {

	public static void main(String[] args) {

		// check the length of the string is greater than 5 or not
		Predicate<String> checklength = s -> s.length() >= 5;
		System.out.println(checklength.test("Ravidd"));
		
		// check the length of the string is even or not
		Predicate<String> checkEven = s -> s.length() %2 == 0;
		System.out.println(checkEven.test("abcdefg"));
		
		// What is Predicate joining?
		// Ans: you can combine predicates.
		// There are 3 ways to join. And, Or, Negate
		
		// And: Multiple Predicates can be joined with And (If both are true it will return true, else false)
		System.out.println(checklength.and(checkEven).test("code decode"));
		
		// Or: Multiple Predicates can be joined with Or (If atleast one is true it will return true, else false)
		System.out.println(checklength.or(checkEven).test("code decode"));
		
		// Negate: works with only one Predicate
		// Negate: it will reverse the result
		System.out.println(checklength.negate().test("code decode"));
		
		// BiPredicate (if we need 2 arguments for operation)
		BiPredicate<Integer, Integer> checkSumOfTwo = (a,b) -> a+b >= 5;
		System.out.println(checkSumOfTwo.test(2, 5));
		
		// If we want to operate on 3 arguments then TriPredicate?
		// * There are no TriPridicate or TriFunction etc. (XXXXX But it looks like TriFunction is exist. please check it once XXXXX).
		// * No QuadPredicate No QuadFunction.
		// * Java 8 has inbuilt Functional interface that can take only 1 or 2 arguments no more.

		
	}

}
