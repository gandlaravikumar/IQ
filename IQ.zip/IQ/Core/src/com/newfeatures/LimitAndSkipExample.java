package com.newfeatures;

import java.util.Arrays;
import java.util.List;

/*Difference between limit() and skip()?
Limit: The limit(n) method is an intermediate operation that returns a stream with requested size.
	   The n parameter can't be negative.
	   
Skip:  The skip(n) method is an intermediate operation that skips the first n elements and return the remaining elements from the stream.
	   The n parameter can't be negative, and if it's higher than the size of the stream, skip() returns an empty stream.*/
public class LimitAndSkipExample {

	public static void main(String[] args) {
		
		List<Integer> list = Arrays.asList(4,5,6,8,23,35,36,77,78,99);
		
		// limit(n)
		list.stream().limit(5).forEach(x -> System.out.print(x+" "));
		
		System.out.println();
		
		// skip(n)
		list.stream().skip(5).forEach(x -> System.out.print(x+" "));
	}

}
