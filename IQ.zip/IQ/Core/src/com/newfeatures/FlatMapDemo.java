package com.newfeatures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMapDemo {

	public static void main(String[] args) {
		Employee e1 = new Employee(234, Arrays.asList(1234567890, 234556644, 44554433));
		Employee e2 = new Employee(43, Arrays.asList(2452452, 23452345));
		Employee e3 = new Employee(435, Arrays.asList(563456124, 353252, 2524625));
		Employee e4 = new Employee(53, Arrays.asList(24524524, 53634563));
		
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(e1); employeeList.add(e2); employeeList.add(e3); employeeList.add(e4);
		
		// I have an employee list. print all id's from that employee list.
		List<Integer> empIds = employeeList.stream().map(emp -> emp.getId()).collect(Collectors.toList());
		System.out.println(empIds);
		
		// print all employee mobile numbers
		List<List<Integer>> mapList = employeeList.stream().map(emp -> emp.getMobile()).collect(Collectors.toList());
		System.out.println(mapList);
		// It prints the big list. That big list contains again small number of lists. So, list having list.
		
		// I don't want list inside list. i want only list. then i will go for flatmap.
		// Also advantage is, If i want to remove the duplicates from the list of list, then i will go for flatmap.
		// First i will flattering then assign to set. It will remove the duplicates.
		// Note: In flatmap after emp.getMobile() we need to convert to stream for flattering. FlatMap() takes stream of list. map takes only list.
		List<Integer> flatmapList = employeeList.stream().flatMap(emp -> emp.getMobile().stream()).collect(Collectors.toList());
		System.out.println(flatmapList);
	}

}





class Employee {
	private int id;
	private List<Integer> mobile;
	
	public Employee(int id, List<Integer> list) {
		super();
		this.id = id;
		this.mobile = list;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Integer> getMobile() {
		return mobile;
	}

	public void setMobile(List<Integer> mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", mobile=" + mobile + "]";
	}
}