package com.newfeatures;

import java.util.Optional;

/*Optional is a predefined final class which is used to avoid NullpointerException.
It is used to represent a value is present or not.
Java 8 added a new class called Optional class which is available in java.util.package*/

public class OptionalDemo {
	public static void main(String[] args) {
		
		String name = "ravi";
		Optional<String> nameCheck = Optional.ofNullable(name); // passing the name argument in ofNullable() and get the Optional object.
		if(nameCheck.isPresent()) { // From the Optional object there is a method called isPresent(). It will return boolean value weather the Optional object is empty or not. As of Java 11, we can do the opposite with the isEmpty method.
		String value = nameCheck.get(); // If the Optional object is not null, then get the value by using get() which is available in Option class. It can only return a value if the object is not null. otherwise, it throws a no such element exception.
		System.out.println(value.toUpperCase());
		} else {
			System.out.println("The name is null");
		}
		
		// Instead of checking the condition first through isPresent() and printing the value. this is lengthy. so we will use ifPresent() or ifPresentOrElse() method.
		// If the value is present print this value. Here only one condition. like if condition.
		nameCheck.ifPresent(n -> System.out.println(n));
		
		// what happens if the value is not there. like if else condition. For that we need to use ifPresentOrElse(). This will available in JDK 9 only.
		//nameCheck.ifPresentOrElse(n -> System.out.println(n), () -> System.out.println("The name is null"));
		
		
		String[] words = new String[10];  // Taking String array with 10 capacity
		Optional<String> wordCheck = Optional.ofNullable(words[5]); // Taking the 5th word from String array and get the Optional object.
		System.out.println(wordCheck.isPresent()); // check that optional object is present or not.
		
		
		// Default value with orElse()
		// Given an employee table, fetch the employee with given Id and print it's name. If name is not present then print default name.
		// orElse() method is used to taking a default value if the Optional value is not present.
		String myName = null;
		String orElseResult  = Optional.ofNullable(myName).orElse("kumar");
		System.out.println(orElseResult);
		
		//orElseGet()
		// instead of taking a default value if the Optional value is not present, It takes a supplier functional interface, which is used and returns the value.
		String orElseGetResult = Optional.ofNullable(myName).orElseGet(() -> "Gundu");
		System.out.println(orElseGetResult);
	}
	
}


/*
 * Creating Optional Objects? 
 * Ans: We can create Optional object with Optional's static method Of(). 
 * The argument passed to the of() method can't be null. Otherwise, will get a NullPointerException.
 * If there might be a chance that passing value might be null, then we can use the ofNullable() Method. By doing this, if we pass in a
 * null reference, it doesn't throw an exception but rather returns an empty Optional object.
 */

/*
 * What is the difference between Optional.of() and Optional.ofNullable()?
 * Ans:Both are used to create the Optional object only. But if you are confirm that the passing argument can't be null, then go for of(). Otherwise, will get a NullPointerException. 
 * If you not confirm that the passing argument can't be null, then go for ofNullable(). It doesn't throw an exception but it will give you an empty Optional object.
 */

/* Interview Question:
 * Given an employee table, fetch the employee with given Id and print it's name in upper case. If name is null then print "The name is null", using java 8?
 */