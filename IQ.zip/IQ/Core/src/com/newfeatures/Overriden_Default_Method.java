package com.newfeatures;

public class Overriden_Default_Method implements FunctionalInterfaceDemo1{
	
	// here i am over riding firstName value from gandla to ravi
	@Override
	public void firstName() {
		System.out.println("ravi");
	}

	public static void main(String[] args) {
		Overriden_Default_Method overriden_Default_Method = new Overriden_Default_Method();
		overriden_Default_Method.firstName();

	}

	@Override
	public void singleAbstMethod() {
		System.out.println("implementation of abstract method");
		
	}

}
