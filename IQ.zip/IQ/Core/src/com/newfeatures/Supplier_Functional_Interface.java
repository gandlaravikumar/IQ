package com.newfeatures;

import java.util.Date;
import java.util.function.Supplier;

/*What is Supplier: Supplier is a pre defined functional interface (Having only 1 abstract method).
 * The only abstract method of Supplier is get().
 * It will just supply required Objects and will not take any input.
 * public R get();*/
public class Supplier_Functional_Interface {

	public static void main(String[] args) {
		Supplier<Date> supplier = () -> new Date();
		System.out.println(supplier.get());
		
		
		/*
		 * Note: There is no input in supplier. So no 1 or 2 input arguments needed.
		 * Hence no BiSupplier, no chaining.
		 */

	}

}
