Why java 8?
Ans: To introduce Conciseness (shortness) in the code.
	 Java 8 brings functional programming which is enabled by Lambda expressions.
	 By using LAMBDA EXPRESSION which creates Conciseness (shortness) in the code.
	 These kind of conciseness already available in Python, Scala.

What are the new features in java 8?
Ans: 1. Lambda Expression
	 2. Stream API
	 3. Default methods in the interface
	 4. Static methods in the interface
	 5. Functional Interfaces
	 6. Optional
	 7. Method references
	 8. Date API

What are the advantages using java 8?
Ans: 1. Conciseness code or short line of code
	 2. compact code (Less boiler plate code)
	 3. reusable code

What is Stream In Java 1.8?
Ans: Stream is an interface, available in java.util.stream package.
Stream API is used to process collections of objects.
A stream is a sequence of objects that supports various methods which can be pipelined to produce the desired result.

What is lambda expression?
Ans: Lambda expression is an anonymous function (without method name, return type and access modifier) and having one lambda (->) symbol.
	 lambda expression is used to initialize the functional interfaces.

What are functional interfaces?
Ans: The interface which can have only one abstract method.
	 It can have any number of static methods, default methods. no restrict on that.
	 There are many functional interfaces already present in java such as eg: Function, Comparable, Comparator, Runnable.
	 
How lambda expression and functional interfaces are related?
Ans: functional interfaces provides references to the lambda expression. This is the relation.
Comparator<String> c = (s1,s2) ->s1.compareTo(s2);
The first part (Comparator<String> c) this is Functional interface.
The second part ((s1,s2) ->s1.compareTo(s2)) this is lambda expression.
To call lambda expression we need functional interface.

What is default method?
Default methods contains default implementation (with body). If we want override we can override in implemented classes.
It is a way for adding new methods to the interfaces without effecting the implemented classes.
Means if i add a new abstract method (without body) in interface, all implemented classes should be implement that abstract method, else compile errors will come.
But if i add default method (with body) in interface, If we want override we can override in implemented class. without effecting other implemented classes. 

Is default keyword one of the access modifier?
Ans: No. Default is not the access modifier like public or private or protected.
	 For default access modifier we don't use any keyword.
	 Till 1.8 version default keyword used in 'switch cases' only but never in interface.
	 Now it is used in interfaces to provide default implementation.
Note: In interfaces all the methods are public till java 1.8. we don't have any default and static methods till 1.8.

How to override default methods?
Ans: you can override default method by keeping same method signature (name+arguments)
	 we should not use default keyword in java class. In java default keyword use to only switch case.
	 Adding public as access modifier in java class bcz, by default all default methods are public in interface so, in child u can't reduce visibility of overridden default method.
	 Giving our own implementation.
	 
What is static method?
Only reason for introducing static methods in interfaces is that you can call those static methods with just interface name explicitly (without object creation).
And also it providing security by not allowing implementation classes to override them.
no need to create class and then its object.
Hence less memory will consumption. cost also will reduce.
It's implementation cannot be changed in child classes. Means Static methods of interface can't be overridden.
NOTE: static methods are not available to implementing the classes. They are not like default methods. they are just static methods.

Name some pre-defined functional interfaces?
1. Predicate<T>   -> public boolean test(T t);
					 It takes one input and return boolean value.
					 Its used for conditional checks.
					
2. Function<T,R>  -> public R apply(T t);
					 It takes one input and returns one output.
					 Return type is not fixed like predicate, hence we declare both input type and return type.
					 Its used to perform operations and return result.

3. Consumer<T>    -> public void accept(T t);
				     It will consume input. Consumers never return anything. 

4. Supplier<R>    -> public R get();
					 It will just supply required Objects and will not take any input.

Steps to create and process Stream?
Ans: We can get stream object by: Stream s = collectionObject.stream();
	 Once we get stream object we can do configuration of Stream and processing that configuration.
	 configuration can be done by 2 ways. Map, Filter. Ex: collectionObject.stream().map(x -> x*x)
	 Processing a stream in different ways like Collect, Count, Sorted, Min, Max, forEach, toArray, of(). Ex: forEach(x -> System.out.println(x)); 
					 
Difference between Streams in java 1.8 and java.io.Stream?
Ans: java.io.streams is a sequence of characters or binary data which is used to be written to a file or to read data from a file.
	 While streams java 1.8 is no where related to files, its related to collection object.
	 Java io streams related to files whereas java 8 streams are related to collection object.
	 Hence if we need to perform some operation on collection there we should go for streams.

Difference between java 1.8 streams and collection?
Ans: To represent group of collection as single entity then we should use collection concept.
	 If we want to perform operation on bulk objects of collection then we should go for Streams.

What is filter in Streams?
If i want to fetch/filter objects from collection. Ex: filter only even or odd numbers from ArraryList.
filter takes Predicate argument and returns boolean.

What is map in Streams?
If i want to perform some operation on each object of the collection then create another mapped object with different values(after operation
is performed) for each object of that collection, then use map.
Map takes a function argument and apply operation on each element and transforms it to another new stream.

Filter Vs Map?
Ans: If we want to fetch/filter objects from collection then use Filter configuration.
	 If we want to perform some operation on each object of collection then created new object (ex: square the value), then use Map configuration.
	 In filter, due to filtering, number of objects in filtered list is less than original list. But in Map both new and original list is size is same.
	 In filter values are not going to change. In Map values are going to change.

What is an Intermediate operation?
The operation which returns stream are called intermediate operations. They are lazy.
Eg: filter(), map(), distinct(), sorted(), limit(), skip(), peek().

What is Terminal operation?
The operations which return non-stream values like primitive or object or collection or return nothing are called terminal operations.
you can chain multiple intermediate operations and none of the will do anything until you invoke a terminal operation.
At that time, all of the intermediate operations that you invoked earlier will be invoked along with the terminal operation.
Eg: forEach(), toArray(), reduce(), collect(), min(), max(), count(), anyMatch(), allMatch(), noneMatch(), findFirst(), findAny().

Difference between Intermediate and Terminal Operations?
	Intermediate Operations									Terminal Operations
1.	They return stream.										1. They return non-stream values.
2.	They can be chained with multiple intermediate			2. They can't be chained together. It has only one terminal operation
	Operations.												   at a time.
3. 	Intermediate operations are lazily loaded.				3. Terminal operations are eagerly loaded.
4.	They don't produce end result.							4. They produce end result.

Difference between map and flat map?
Map: The function you pass to the map() operation returns a single value.
	 Map() is used to transformation only.
FlatMap: The function you pass to flatMap() operation returns a stream of value.
		 flatMap() is a combination of map and flat operation.
		 flatMap() is used for both transformation and flattering.

