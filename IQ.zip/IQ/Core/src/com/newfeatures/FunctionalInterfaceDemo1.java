package com.newfeatures;

@FunctionalInterface
public interface FunctionalInterfaceDemo1 {
	
	public void singleAbstMethod();
	
	default void firstName() {
		System.out.println("Gandla");
	}
	
	default void lastName() {
		System.out.println("Kumar");
	}
	
	
	/*
* Can you use hashcode() default implementation in Interface? 
	* Ans: we are not allowed to override, Object class methods as default methods in interface.
	 * else will get compile time error. You cannot give your default implementation
	 * of hashcode() in interface. 
	 * Means. i.e, java.lang.Object contains hashcode() method. that hashcode() we cannot override in interface by making that default. 
	 * If you want to override you can directly access from implementing class and do override. 
	 * by default all classes has access to all methods of object class.
	 */
	 
	// Note: hashCode is a method from java.lang.Object class. cannot override a method in interface by making default.
	/*
	 * default int hashCode() { return 2*3; }
	 */

}
