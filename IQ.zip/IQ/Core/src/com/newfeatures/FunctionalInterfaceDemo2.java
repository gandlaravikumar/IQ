package com.newfeatures;

public interface FunctionalInterfaceDemo2 {

	default void firstName() {
		System.out.println("Ravi");
	}
	
	
	static void staticMethod() {
		System.out.println("this is static method");
	}
	
	// interface static methods are good for providing utility methods, for example null checking. i.e whose definition will never change
	static boolean nullCheck(String name) {
		if(name.length()>0 && name.contains(""))
			return true;
		else
			return false;
	}
}
