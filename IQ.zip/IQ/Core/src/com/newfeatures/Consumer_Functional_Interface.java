package com.newfeatures;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

/* What is Consumer: Consumer is a pre defined functional interface (Having only 1 abstract method).
 * The only abstract method of Consumer is accept(T t).
 * That accepts one input arguments and returns noresult
 * public void accept(T t);*/

/*BiConsumer: BiConsumer is a pre defined functional interface 
that accepts two input arguments and returns noresult*/

public class Consumer_Functional_Interface {

	public static void main(String[] args) {
		
		//Consumer
		Consumer<Integer> squareMe = i -> System.out.println(i*i);
		squareMe.accept(2);
		
		Consumer<Integer> doubleMe = i ->System.out.println(i+i);
		doubleMe.accept(4);
		
		// Consumer chaining or Consumer combine
		// we can combine multiple Consumers together using 'andThen'.
						
		//using andThen
		squareMe.andThen(doubleMe).accept(5);
		// Here first it will do squareMe with value 5. no result will come. So, and then it will do doubleMe with value 5.
		
		// Biconsumer (if we need 2 arguments for operation)
		BiConsumer<Integer, Integer> biConsumer = (a, b)-> System.out.println(a+b);
		biConsumer.accept(2, 3);
		
		
		
	}

}
