package com.newfeatures;

import java.util.Arrays;
import java.util.List;

/*
 * What is Reduce? 
 * -> It is a Terminal operation which returns the Optional.
 * -> Stream.reduce() combine elements of a stream and produces a single value. 
 * -> reduce operation applies a binary operator to each element in the stream where the first argument to the operator is the return value of
 * the previous application and second argument is the current stream element.
 */
public class ReduceOperation {

	public static void main(String[] args) {
		List<Integer> intList = Arrays.asList(1,2,3,4,5);
		
		// see there are 5 elements are there 1,2,3,4,5. all 5 elements converted into single element by adding each other like below.
		int sum =0;
		for(Integer i : intList) {
			sum += i;
		}
		System.out.println(sum);
		
		
		// Same like above, combine the multiple elements of a stream and produce single element by using reduce().
		System.out.println(intList.stream().reduce((a, b) -> a+b).get());
		
		// here a is the value from previous output. B is the current element.
		// Initially a=0 and b is 1. If a+b then the output assign to a. Now a is 1 and b is 2. If a+b means 1+2. then output assign to
		// a. means a= 3. now b is 3. and so on...
	}

}
