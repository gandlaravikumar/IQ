package com.newfeatures;

/*Definition: Only reason for introducing static methods in interfaces is that you can call those methods with just interface name explicitly.
no need to create class and then its object.
Hence less memory will consumption. cost also will reduce.
NOTE: static methods are not available to implementing classes. They are not like default methods. they are just static methods.*/
public class StaticMethodDemo implements FunctionalInterfaceDemo2{

	public static void main(String[] args) {
		// syntax for calling static method is below
		// InterfaceName.StaticMethodName();
		FunctionalInterfaceDemo2.staticMethod();
		
		// If i create object for this class, from that object if i tried to call the interface static method. It will give compile error.
		// interface static method won't visible to class object.
		// It can visible through only InterfaceName.
	}

}
