package com.newfeatures;

import java.util.function.BiFunction;
import java.util.function.Function;

/*What is Function?
Ans: It is a pre defined functional interface (Having only 1 abstract method)
 * The only abstract method of Function is apply(T t).
 * public R apply(T t);
 * It takes one input and returns one output.
 * Return type is not fixed like predicate, hence we declare both input type and return type.*/
public class Function_Functional_Interface_Demo {

	public static void main(String[] args) {
		
		Function<Integer, Integer> squareMe = x -> x*x;
		System.out.println(squareMe.apply(2));
		
		Function<Integer, Integer> cubeMe = x -> x*x*x;
		System.out.println(cubeMe.apply(3));
		
		
		// Functional chaining or Functional combine
		// we can combine multiple functions together using 'andThen and compose'.
		
		//using andThen (first squareMe then cubeMe)
		System.out.println("first squareMe and than cubeMe " +squareMe.andThen(cubeMe).apply(2));
		// Here first it will do squareMe with value 2. result will come. So, and then it will do cubeMe with the result.
		
		//using compose (first cubeMe then squareMe)
		System.out.println("first cubeMe using compose "+squareMe.compose(cubeMe).apply(2));
		
		// Multiple functions can be chained together like:
		//f1.andThen(f2).andThen(f3).andThen(f4).apply(Input);
		
		// BiFunction (if we need 2 arguments for operation)
		BiFunction<Integer, Integer, Integer> multiplyBoth = (a,b) -> a*b;
		System.out.println(multiplyBoth.apply(2, 3));
		

	}

}
