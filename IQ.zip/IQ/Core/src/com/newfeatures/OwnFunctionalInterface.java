package com.newfeatures;

/*Can you create your own functional interface?
As we know functional interface is an interface with exactly one single abstract method and can have multiple static or default methods.
To create our own Functional interface, you can do following steps:
1. Create an interface
2. Annotate that with @FunctionalInterface.
3. Define exactly one abstract method.
4. There is no restriction on number of static and default methods defined in such and interfaces.

Java can implicitly identify functional interface but still you can also annotate it with @FunctionalInterface.
It just give you the security that in case if u by mistake add 2 abstract methods then Compiler will throw compile time error.*/

@FunctionalInterface
public interface OwnFunctionalInterface {

	public void abstractMethod1();
	
	default void defaultMethod1() {
	}
	default void defaultMethod12() {
	}
	
	static void staticMethod1() {
	}
	
	static void staticMethod2() {
	}
}
