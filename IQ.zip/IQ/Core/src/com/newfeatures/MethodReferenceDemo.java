package com.newfeatures;

/*Definition: It is the replacement of lambda expression.
initialize the functional interface in two ways
one is using lambda expression
second one is using method reference*/

public class MethodReferenceDemo {

	public static void main(String[] args) {
		// if i have already implemented method, then i will go for method reference as below
		FunctionalInterfaceDemo1 functionalInterfaceDemo = Test :: implementationMethod;
		functionalInterfaceDemo.singleAbstMethod();
		
		// if no implementation available, then use following code for lambda expression
		FunctionalInterfaceDemo1 funionalInterfaceDemo = () -> System.out.println("here needs to be implement");
		funionalInterfaceDemo.singleAbstMethod();

	}

}


class Test {
	// implementation method
	public static void implementationMethod() {
		System.out.println("i already have implemented method");
	}
}