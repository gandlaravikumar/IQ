package com.newfeatures;

import java.util.function.Consumer;

/*Definition: Lambda expression is an anonymous function (without name, return type and access modifier) and having one lambda (->) symbol.
lambda expression is used to initialize the functional interfaces.*/
public class LambdaExpression {
	
	public static void main(String[] args) {
		// Here am taking Consumer functional interface as example.
		// Here Lambda Expression '->' is used to initialize the Consumer Object.
		
		//Consumer
		Consumer<Integer> squareMe = i -> System.out.println(i*i);
		squareMe.accept(2);
	}
	
	 
}
