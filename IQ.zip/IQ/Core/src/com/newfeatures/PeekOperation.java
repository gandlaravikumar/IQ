package com.newfeatures;

import java.util.Arrays;
import java.util.List;

/*
 * What is peek? 
 * Stream peek() method is an intermediate operation. 
 * Peek() exists mainly to support debugging, where we want to see the elements as they flow past a certain point of pipeline. 
 * peek() takes consumer object and perform some action on object and return nothing.
 */
public class PeekOperation {

	public static void main(String[] args) {
		List<Integer> arList = Arrays.asList(15, 25, 5, 30);
		System.out.println(arList.stream().filter(a -> a%2==0).map(a -> a+a).filter(a -> a>5).count());
		// In the above line, first filter is doing and map is doing, again filter is doing and finally count is doing.
		// If i want to know what is happening in between the filter, map and again filter, then i need to use Peek for debug.
		System.out.println(arList.stream().filter(a -> a%2==0).peek(System.out::println).map(a -> a+a).filter(a -> a>5).count());
		// Now in between it will print what are the values are filter. Like that i can write the peek to debug after the map scenario also.


	}

}
