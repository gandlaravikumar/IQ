package com.exception.handling;

public class UserDefinedException {

	public static void main(String[] args) {
		int age = 17;
		try {
			if (age >= 18) {
				System.out.println("welcome to vote");
			} else {
				throw new RaviException("Ravi not allowed to vote");
			}
		} catch (RaviException e) {
			System.out.println(e);
		}

	}
}

class RaviException extends Exception {
	public RaviException (String errorMsg) {
		System.out.println(errorMsg);
	}
}