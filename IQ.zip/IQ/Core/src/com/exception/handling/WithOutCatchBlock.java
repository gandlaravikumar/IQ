package com.exception.handling;

import java.io.BufferedReader;
import java.io.InputStreamReader;

// This is one of the way to use TRY block with out using catch block from java 1.7
// Try with Resources from Java 1.7
public class WithOutCatchBlock {

	public static void main(String[] args) throws Exception {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		{
			String str = "";
			str = br.readLine();
		}

	}

}
