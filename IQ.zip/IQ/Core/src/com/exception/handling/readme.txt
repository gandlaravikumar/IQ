What is an Exception?
Ans: Exception is an abnormal condition which occurs during the execution of a program and disrupts normal flow of the program.
	 If not handled properly it can cause the program to terminate.
	  
What is Exception Handling?
Ans: The Exception Handling is one of the powerful mechanism to handle the runtime errors.
	 so that the normal flow of the application can be maintained.

Hierarchy of Java Exception classes?
Ans : The java.lang.Throwable class is the root class of Java Exception hierarchy inherited by two subclasses: Exception and Error.
	  Ending with 'able' like serializable, cloneable, runnable, Iterable all are interfaces. But this Throwable is class.
	  The hierarchy of Java Exception classes is given in the diagram. go through it.

Types of Exception?
Ans: Checked Exception: Checked exceptions are checked at compile-time.
	 The exceptions which are checked by compiler, such type of exceptions are consider as checked exceptions.
	 Or The classes that extends the Throwable class except RuntimeException and Error are known as checked exceptions.
	 For example, IOException, SQLException, FileNotFoundException, HallticketMissingException, PenNotWorkingException etc.
	 In the case of Checked exceptions compiler will check whether programmer handles exception or not. If not we will get compile time error.
	 
	 UnChecked Exception: Unchecked exceptions are checked at run-time.
	 The exceptions which are checked by run-time, such type of exceptions are consider as UnChecked exceptions.
	 Or The classes that extends the RuntimeException are known as unchecked exceptions.
	 For example, ArithmeticException, NullPointerException, ArrayIndexOutOfBoundsException, BombBlastException, ShortCircuitException etc.
	 This exceptions are occur very very rarely. That's y compiler will not check this type of exceptions.

Note: Whether exception is Checked or Unchecked compulsory it will occur only at Runtime. There is no chance of occurring any exception at compile time.
But why checking whether the programmer is handling or not at the beginning only by compiler means., just like taking precaution for smooth execution at run time.

	 Errors: Errors we cannot handle, because errors are not caused by our code. Errors are caused by due to lack of system resource. 
	 If sufficient heap memory is not there, then OutOfMemory exception will come.
	 Stack size is going to be over flow, then StackOverFlowError will come.
	 Errors comes under unchecked exceptions. Because it is not checked by compiler.
Note: Runtime exceptions and it's child classes, error and it's child classes are unchecked except this remaining are checked exceptions.

Different Between Throw and Throws keyword?
Ans: Throw: 1) The "throw" keyword is used to manually throw an exception.
			2) propagation cannot be done using throw.
			3) Throw is used within the method.
			4) cannot throw multiple exceptions.
	Throws: 1) The "throws" keyword is used to declare an exceptions. Means we are just telling that the method might be throws an exception.
	 		2) propagation can be done using throws.
	 		3) It is always used with the method signature.
	 		4) can declare multiple exceptions.
	 		
Difference Between Exception and Error?
Ans: Throwable class contains 2 child classes - Exception and Error.
	 Exception: 1) Exceptions are caused by our program and this are recoverable by us (we can handle by using try catch block or using throws).
	 			2) Compiler will have knowledge about checked Exceptions hence Compiler will force you to use try-catch blocks.
	 			3)Exceptions in java are of type java.lang.Exception.
	 Error: 1) Errors are caused by lack of system resources. This are not recoverable by us. 
	 		System admin or server admin is responsible to fix this system issues.
	 		2) Compiler will not have any knowledge about unchecked exceptions and Errors.
	 		3) Errors in java are of type java.lang.Error.
	 		
Difference between Try and Catch?
Ans: Try :  It is having set of statements which can throw exception. Try can followed by Catch or multiple Catch or finally.
	 Catch: when exception occur, this block catches that exception and work accordingly to handle it or to throw it as required.

Difference between final, finally, finalize()?
Ans: final: final is a keyword, which is applicable for classes(can't extend), methods(can't override) and variables(can't modify).
	 finally: finally is a block, always followed with try catch block. And it is used to execute some import statements. like closing the connection etc,.
	 finalize(): finalize() is a method. This is available in Object Class. 
	 			 The GarbageCollector is going to call finalize() method just before the object is going to destory to perform some cleanup activities.

Can we write only try block without catch and finally blocks?
Ans: No. Either catch or finally is must.

If i write try block without catch and finally block what is the error?
Ans: compile time error saying "insert finally to complete try statement".

Can we write any other statements between try catch or finally block?
Ans: No. Try must be followed directly by either catch or finally.

What happens when an exception is thrown by the Main method?
Ans: When an exception is thrown by main() method, The main method is calling from JRE, so JRE needs to be handle.
unfortunately there is no code in JRE to handle the exceptions. So, JRE terminates the program and prints the exception message and the stack-trace in system console.

When 'unreachable catch block error' will come?
Ans: This error comes when you keep super-class(Exception) first and sub-class(NullpointerException, ArithmeticException etc,.) later.

What is Multi Catch block?
Ans: To reduce the code duplication and makes it easier to maintain, JAVA 7 came up with this multi catch block concept.
	 Here the catch block arguments having different exceptions piped.
	 E.g:   try{
	 				//----------
	 			}
	 		catch(NullPointerException | SQLException ex) {
	 				//----------
	 			}

What is the difference between ClassNotFoundException and NoClassDefFoundError?
Ans: 1. ClassNotFoundException is an exception that occurs when you try to load a class at run time, 
		using Class.forName() or loadClass() methods and mentioned classes are not found in the classpath.
		Example: If i load the class like below.
		Class.forName("com.practice.Test1");
		But the "Test1" class is not available in class path. Then it will throw ClassNotFoundException.
		
	 2. NoClassDefFoundError is an error that occurs when a particular class is present at compile time, but was missing at run time.
	 	Example: I have a class A and class B. I created object (A a = new A())  in class B. Now i compile the program.
	 	Two .class files will be generated. One is A.class and another one is B.class.
	 	If you remove the A.class file and run the B.class file, Java Runtime System will throw NoClassDefFoundError.
	 	
	 
	 
	 
	 