package com.oops;

public class SwitchCaseDemo {
	static int age = 18;
	public static void main(String[] args) {
		
		switch (age) {
		case 18:
			System.out.println("ready to vote");
			break;   // If there is no break, it will execute remaining cases blindly
		case 21:
			System.out.println("education completed");
			break;

		default:
			System.out.println("nothing");
			break;
		}
		
		
		// using ConditionalOperator
		System.out.println(age >= 18 ? "True" : "False");
		
	}

}
