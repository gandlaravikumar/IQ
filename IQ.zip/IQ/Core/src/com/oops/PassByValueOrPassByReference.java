package com.oops;

// Is java pass by value or pass by reference?
// Ans: Java is pass by value.
public class PassByValueOrPassByReference {
	
	int eyes;
	
	public static void main(String[] args) {
		//PassByValue
				// The parameter copied into another memory location instead of passing to the real memory address.
				// Even though if you try to modified the value the original value remains same. It won't change.
				/*
				 * When i tried to send this 'a' param into passbyValue method, it will copy the
				 * value into different memory location and pass into particular method. Tried to change the value.
				 * But the value is not changed. Hence java is pass by value.
				 */
				int a = 2;
				passByValue(a); // passing a primitive reference variable
				System.out.println("value of a is "+ a); // value remains same
				
				
		// PassByReference
		// Modified the original value in the parent. Which means changing the value at real address in the memory.
				PassByValueOrPassByReference p = new PassByValueOrPassByReference();
				p.eyes = 2; // setting the value
				passByReference(p); // passing a object reference variable
				System.out.println("value of eyes is "+ p.eyes); // value modified

	}
	
	public static void passByValue(int aCopy) {
		// changing the value
		aCopy = 12;
	}
	
	public static void passByReference(PassByValueOrPassByReference p) {
		// changing the value
		p.eyes = 3;
	}
}
