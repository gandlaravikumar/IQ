package com.oops;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
// I can also create enum constant in current class like below.
enum Days {  
	  SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY  
	}  

// I created one Enum file called EnumerationDemo.java
// In this file trying to access that enum constants
public class EnumerationPrinting {
	
	public static void main(String[] args) {
		
		// Enum file name .values() gives the all constant names.
		for(EnumerationDemo e : EnumerationDemo.values()) {
			System.out.println(e); // It will print the constant name.
			System.out.println(e.getDescription() + " "+e.getExperience()); // It will print the constant param values.
		}
		
		//If i don't want all the constants. Then i can use EnumSet.range(from, to)
		for(EnumerationDemo constant : EnumSet.range(EnumerationDemo.lokesh, EnumerationDemo.sahana)) {
			System.out.println(constant);
		}
		
		// This is EnumSet
		Set<Days> set = EnumSet.of(Days.TUESDAY, Days.WEDNESDAY);
		Iterator<Days> iter = set.iterator();  
	    while (iter.hasNext())  
	      System.out.println(iter.next());  
	    
	 // This is EnumMap
	    EnumMap<Days, String> map = new EnumMap<Days, String>(Days.class);
	    map.put(Days.MONDAY, "1");  
	    map.put(Days.TUESDAY, "2");  
	    map.put(Days.WEDNESDAY, "3");  
	    
	    for(Map.Entry m:map.entrySet()){    
	        System.out.println(m.getKey()+" "+m.getValue());    
	       }
	  }  
		
	}
