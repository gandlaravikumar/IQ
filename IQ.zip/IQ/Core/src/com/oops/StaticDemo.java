package com.oops;

/*static variables are same for all the objects. (Ex: ceo name is same in all the Employee objects)
Non-static variables are different for all the objects.*/
class Employee {
	int eid;
	int salary;
	static String ceo;
	
	/*
	 * to initialize the static variables we need to use static blocks. And this
	 * static blocks will load only one time at the time of class loader
	 * cannot use non-static variable in static block.
	 * And also If i want to run any piece of code before the main method this static block will help.
	 */
	static {
		ceo = "c.p gurnani";
		System.out.println("initializing static variables");
	}
	
	/*
	 * to initialize the non static variables we need to use constructors. And this
	 * constructors will load for every object creation.
	 */
	public Employee(int eid, int salary) {
		this.eid = eid;
		this.salary = salary;
		System.out.println("initilizing non static variables"); // This constructor will load how many times we created object.
	}
	
	public void show() {
		System.out.println(eid+" "+salary+" "+ceo);
	}
}

public class StaticDemo {

	public static void main(String[] args) {
		
		Employee ravi = new Employee(518, 30000);
		
		Employee ramesh = new Employee(123, 40000);
		
		ravi.show();
		ramesh.show();

	}

}
