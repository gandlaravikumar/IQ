package com.oops;

class Student {
	
	/*
	 * Why Encapsulation? 
	 * It is a process of wrapping code and data together into a single unit.
	 * For data safety purpose by making the variable as private,
	 * and we can also maintain the logs in setters and getters methods, who is
	 * setting the variable and access the variable.
	 */
	
	
	// We can create a fully encapsulated class in Java by making all the data members as private. 
	// Now we can use setter and getter methods to set and get the data in it (those are public methods).
	// means Binding your data with methods is called Encapsulation.
			
	private int rollNo;
	private String name;
	
	// setter and getter
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}


public class EncapsulationDemo {
	
	public static void main(String[] args) {
		Student s1 = new Student();
		// only variables need to be assign through set Methods
		s1.setRollNo(123);
		s1.setName("Ravi");
		
		// only variables need to get through get Methods
		System.out.println(s1.getRollNo()+" "+s1.getName());
		
	}

}
