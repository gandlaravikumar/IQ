package com.oops;
// Enumerations is used to create the constants.

/*Steps to create enums:
	1. create a enum file
	2. create some constants like ravi, lokesh, gundu
	3. create private, final parameters according to that constants
	4. create constructor with params
	5. create getter methods.*/
	
	
public enum EnumerationDemo {
	ravi("He is from java developer", "5years"),
	lokesh("he is from CA", "2 years"),
	Gundu("he is playing", "1 year"),
	Bhavana("she is good house wife", "3 years"),
	sahana("working in lageto", "2 years");
	
	private final String description;
	private final String experience;
	
	
	private EnumerationDemo(String description, String experience) {
		this.description = description;
		this.experience = experience;
	}

	public String getDescription() {
		return description;
	}

	public String getExperience() {
		return experience;
	}

}
