package com.oops;

/*Definition : Singleton means one. That means i can create only one instance of a class.*/
public class SingletonExample {

	public static void main(String[] args) {
		Country country = Country.getInstance();

	}

}

class Country {
	/*
	 * you have to remember 3 steps to create Singleton class 
	 * Step1: create private constructor 
	 * Step2: create static object of the class.
	 * Step3: create the static method and return the created static object
	 */
	
	// Step1: create private constructor. Don't allow user to create new objects. That's y make the constructor as private.
	private Country() {
		
	}
	
	// Step2: create static instance of this class.
	// Why this object should be static means? The below getInstance is a static method which should return static reference only.
	// i.e static method always should return static reference only.
	static Country obj = new Country();
	
	// Step3: create the static method and return the created static object
	public static Country getInstance() {
		return obj;
	}
}
