package com.oops;
// Math Class is used to do math operations
public class MathClassDemo {

	public static void main(String[] args) {
		
		//power value
		System.out.println(Math.pow(2, 3));  // 2^3 = 2*2*2 = 8
		
		//absolute value 
		System.out.println(Math.abs(-25.1));  // If the value is -ve or +ve. Finally it will return positive value only
		
		//ceil
		System.out.println(Math.ceil(27.2));  // It will return the double value of higher round figure.
		
		//floor
		System.out.println(Math.floor(27.2)); // It will returns the double value of lower round figure.
		
		//max
		System.out.println(Math.max(23.4, 54.2));
		
		//min
		System.out.println(Math.min(43.4, 34.7));
		
		//square root
		System.out.println(Math.sqrt(25));
	}
}
