package com.ravi.SpringCoreXMLBasedConfiguration;

public class Fuel {

	private String oil;
	private String gas;

	public Fuel(String oil, String gas) {
		super();
		this.oil = oil;
		this.gas = gas;
	}

	@Override
	public String toString() {
		return "Fuel [oil=" + oil + ", gas=" + gas + "]";
	}

}
