package com.ravi.SpringCoreXMLBasedConfiguration;

public interface Vehicle {

	void drive();
}
