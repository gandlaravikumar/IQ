package com.ravi.SpringCoreXMLBasedConfiguration;

public class Car implements Vehicle {
	
	public void drive() {
		System.out.println("car driving");
	}

}
