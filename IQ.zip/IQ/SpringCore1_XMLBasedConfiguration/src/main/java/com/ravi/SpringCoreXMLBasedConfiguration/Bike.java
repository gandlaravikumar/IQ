package com.ravi.SpringCoreXMLBasedConfiguration;

public class Bike implements Vehicle {
	
	public void drive() {
		System.out.println("bike driving");
	}
}
