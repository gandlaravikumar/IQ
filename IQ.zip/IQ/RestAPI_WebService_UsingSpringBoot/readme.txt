RESTful web services using springBoot and JPA.

Jackson is pre build in spring web projects. this Jackson is the responsible to convert list of objects into json.

What is REST and RESTFUL?
Ans: REST represents REpresentational State Transfer.
	 RESTFUL web services are web services that follows REST architectural concept for developing applications,
	 that can be accessed over the network.
	 
What is a REST Resource?
Ans: Every content in the REST architecture is considered a resource.
	 The resource is nothing but object. which can be represented as text files, HTML pages etc.
	 Every resource is identified globally by using it's URI.
	 
What is URI?
Ans: Uniform Resource Identifier is the full form of URI, which is used for identifying each resource of the REST architecture.
URI is in the format of:
<protocol>://<service-name>/<ResourceType>/<ResourceID>
https://en.wikipedia.org/wiki/Representational_state_transfer

What are the features of RESTful web services?
Ans: The service is based on Client-Server model.
	 Resources are accessible through URI.
	 Provides the REpresentational State Transfer.

What is the concept of statelessness in REST?
Ans: As per REST architecture, a RESTFUL web service should not keep a client state on server.
	 means, if you hit the service one time or 100 times, the REST web services will not going to remember your body data or sessions what you are sending.
	 You need to send the context data every time. Because REST is stateless.

What are advantages of REST web services?
Ans: It supports multiple technologies for data transfer such as text, xml, json, image etc.
	 Represents REpresentational State Transfer
	 Loosely coupled implementation between server and client.
	 REST is a lightweight protocol.
	 REST methods can be tested easily over browser.
	  
Disadvantages of REST web services?
Ans: we all know REST is stateless. So, in every HTTP request from the client, we need to send some information regarding the client
	 state is required by the web service.
	 Sessions can't be maintained.

