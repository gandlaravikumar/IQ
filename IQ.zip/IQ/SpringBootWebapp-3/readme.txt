This application is SpringBoot + Hibernates web application using REST API

1. By default rest response is Json format. jackson-core jar will help us to convert from java object into json.

Content Negotiation:
as a server you have options of providing data in different format. like example xml, json, pdf ect.

In postman tool Accept -> application/json -> By default spring support json format.
In postman tool Accept -> application/xml -> jackson dataformat xml jar -> which is used to support for XML format.

server to client -> produces
client to server -> consumes

If server want to generate only XML, not to provide Json:
produces= {"application/xml"}

If server accepts on json, it will not accept any XML format:
consumes={"application/json"}


