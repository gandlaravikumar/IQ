package com.telusko.springbootWebapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.telusko.springbootWebapp.dao.AlienRepo;
import com.telusko.springbootWebapp.model.Alien;
// This application is SpringBoot + Hibernates web application using REST API. (CRUD)
@Controller
public class AlienController {

	@Autowired
	AlienRepo alienRepo;
	
	@RequestMapping("/aliens") // By default it will take as a path. i.e @RequestMapping(path="/aliens")
	@ResponseBody // we are informing to our dispacher servlet , we are sending the data. not a page name.
	public List<Alien> getallAliens() {
		System.out.println("am requestmapping");
		return alienRepo.findAll();
	}
	
	@GetMapping(path = "/aliens") // It is a GetMapping. And this GET request is default request. If i use both @RequestMapping and @GetMapping. Rest api will take @GetMapping only.
	@ResponseBody
	public List<Alien> getAliens() {
		System.out.println("am from getmapping");
		return alienRepo.findAll();  // It will return all the aliens in the format of json. Spring internally have jackson-core jar. It will convert java object to json.
	}
	
	@RequestMapping("/alien/{aid}") // @RequestMapping means defaultly it is a GET request
	@ResponseBody
	public Optional<Alien> getAlien(@PathVariable("aid") Integer aid) {
		return alienRepo.findById(aid);
	}
	
	@PostMapping(path = "/alien", consumes = {"application/json"})
	// Here it accepts only json format data. and it is a post request. If i remove consumes then it will support for both xml and json.
	public Alien addAlien(@RequestBody Alien alien) {
		alienRepo.save(alien);
		return alien;
	}
	
	@DeleteMapping("/alien/{aid}")
	// It is a delete request
	public String deleteAlien(@PathVariable int aid) { // @PathVariable indicates that a method parameter should be bound to a URI template variable.
		Alien a = alienRepo.getById(aid);
		alienRepo.delete(a);
		return "deleted";
	}
	
	@PutMapping(path = "/alien", consumes = {"application/json"})
	// it is put request
	public Alien saveOrUpdateAlien(@RequestBody Alien alien) {
		alienRepo.save(alien);
		return alien;
	}
	
	
	//In this controller class these methods are doing nothing. just accepting the request and fetching the data from JPA repo.
	// So, in next example there is no controller class will be available.
}
