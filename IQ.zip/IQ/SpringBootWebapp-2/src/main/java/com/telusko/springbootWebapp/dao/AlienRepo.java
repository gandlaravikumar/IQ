package com.telusko.springbootWebapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.telusko.springbootWebapp.model.Alien;
// Here Spring JPA will provide this CrudRepository interface
// If i implement this interface using any class, That class should be annotated with @Component. So that implement class will inject into dependent object.
// But here am not implementing this interface and no were override the interface methods any were. Spring JPA will do implementation for you.
public interface AlienRepo extends CrudRepository<Alien, Integer> {
	// Here protocall is method should be start with "findBy" and "parameter name". Then Spring JPA will understand.
	List<Alien> findByTech(String tech);
	
	//Here protocall is method should be "findBy" and "parameter name" and GreaterThan or LessThan. 
	List<Alien> findByAidGreaterThan(int aid);
	
	// here we need to use JPQL query for customized queries.(my own query). It's almost same like HQL.
	@Query("from Alien where tech=?1 order by aname")
	List<Alien> findByTechSorted(String tech);

}
