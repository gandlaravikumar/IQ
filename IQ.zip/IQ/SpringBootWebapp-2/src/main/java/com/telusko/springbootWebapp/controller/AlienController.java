package com.telusko.springbootWebapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.telusko.springbootWebapp.dao.AlienRepo;
import com.telusko.springbootWebapp.model.Alien;

@Controller
public class AlienController {

	@Autowired
	AlienRepo alienRepo;
	
	@RequestMapping("/login")
	public String home() {
		return "home";
	}
	
	// URL looks like this http://localhost:8080/addAlien?aid=107&aname=Lokesh&tech=CA
	@RequestMapping("addAlien")
	public String addAlien(Alien alien) {
		alienRepo.save(alien);
		return "home";
	}
	
	//URL looks like this http://localhost:8080/getAlien?aid=105
	@RequestMapping("getAlien")
	public ModelAndView getAlien(@RequestParam("aid") Integer aid) {
		Alien alien = alienRepo.findById(aid).orElse(new Alien());
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("showAlien");
		mv.addObject("alien", alien);
		return mv;
	}
	
	// URL looks like this http://localhost:8080/getByTech?tech=Java
	@RequestMapping("getByTech")
	public ModelAndView getByTech(String tech) {
		// we can also filter by parameter
		List<Alien> alien = alienRepo.findByTech(tech);
		
		// we can also filter by shorting
		System.out.println(alienRepo.findByAidGreaterThan(102));
		
		//for customized queries
		System.out.println(alienRepo.findByTechSorted(tech));
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("showAlien");
		mv.addObject("alien", alien);
		return mv;
	}
	
	// If you see the URL's how it looks like.
	// For example take fetch URL http://localhost:8080/getAlien?aid=105
	// Instead of sending ?aid=105 parameters in URL, we can do like this using rest api http://localhost:8080/alien/105
	// For this kind of implementation go to SpringBootWebapp-3 project
}
