package com.telusko.springbootWebapp;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

	@RequestMapping("home")
	//@RequestMapping is used to handle the requests
	
	// @ResponseBody
	// @ResponseBody is used to what ever you are returning, that is actually a data. not a page.
	public String home() {
		
		System.out.println("welcome to spring boot app");
		return "home.jsp";
	}
}
