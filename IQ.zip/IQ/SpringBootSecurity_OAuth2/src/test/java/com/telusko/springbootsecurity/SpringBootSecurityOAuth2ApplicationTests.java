package com.telusko.springbootsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityOAuth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
