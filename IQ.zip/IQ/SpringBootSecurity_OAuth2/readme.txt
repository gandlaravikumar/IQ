why SSO? or OAuth2?
Ans: If you have user details in your database, then you will provide the spring security authentication.
You will responsible if your database hacks.
And second one is even if you have the database details, most of the users there are using some types of social networking login.

OAuth 2 is an authorization framework that enables applications to obtain limited access to user accounts on an HTTP service.
