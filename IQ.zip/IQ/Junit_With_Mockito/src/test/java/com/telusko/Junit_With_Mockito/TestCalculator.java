package com.telusko.Junit_With_Mockito;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class TestCalculator {
	
	Calculator calc = null;
	
	// one way is creating a fake object (see Junit_With_FakeObject project)
	// This is other way to create mock service by using Mockito framework.
	CloudService service = Mockito.mock(CloudService.class);
	
	/*
	 * this setup method is used to initialize the objects with out creating objects
	 * in open source. And this method will call before the testing of the units
	 */
	@Before
	public void setUp() {
		calc = new Calculator(service);
	}
	
	@After
	// @After is used to release some object resources after the testing of the units.
	
	@Test
	public void testperformAction() {
		
		// static implementation for mockito service (CloudService)
		// we are saying to CloudService that when we pass 2,3 it should return 5 (That is called mocking)
		when(service.add(2, 3)).thenReturn(5);
		/*
		 * when ever i call the below line it will call performAction method in
		 * Calculator.java by passing 2,3 values. in that method we are actually testing
		 * PerformAction method only, not testing the service call service.add(i,j).
		 * because that service, we made as mocking by passing the static values in the above line.
		 */
		assertEquals(10, calc.performAction(2, 3));
		
		// how can we verify if our application is calling mock service or not. By using the below line we can verify.
		verify(service, atLeast(1)).add(2, 3);
	}

}
