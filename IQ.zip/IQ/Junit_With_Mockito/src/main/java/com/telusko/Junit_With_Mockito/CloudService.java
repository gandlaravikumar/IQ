package com.telusko.Junit_With_Mockito;

public class CloudService {
	
	public int add(int i, int j) {
		
		return i+j;
	}

}
