package com.telusko.Junit_With_Mockito;

public class Calculator {
	
	CloudService service;
	
	public Calculator(CloudService service) {
		this.service = service;
	}
	
	public int performAction(int i, int j) {
		
		// the below line is using mock service
		return service.add(i, j)*2;
		
		// the below line is not using mock service
		// return (i+j)*2;
	}

}
