What is Mockito?
If our java class is dependent with some other class Object (suppose Google service). we no need to test the Google Service.
If we test those google services and all it will take very long time. That's y we need to mock those Google services.
Means it is a duplicate copy of that service.
we can do this mocking with the help of different mocking frame works. (Jmock or Easy mock or Mockito).

Assertions:
Assertions form a very important part in junit library.
in this we are comparing the expectations with actual values after running the application.
we have soo many assertXXX() like below:
assertEquals(expected, actual);
assertNull(object);
assertNotNull(object);
assertTrue(condition);
assertFalse(condition);