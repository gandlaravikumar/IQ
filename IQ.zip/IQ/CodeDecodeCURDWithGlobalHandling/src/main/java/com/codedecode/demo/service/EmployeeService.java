package com.codedecode.demo.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codedecode.demo.custom.exception.BusinessException;
import com.codedecode.demo.custom.exception.EmptyInputException;
import com.codedecode.demo.entity.Employee;
import com.codedecode.demo.repo.EmployeeCrudRepo;

@Service
public class EmployeeService implements EmployeeServiceInterface {


	@Autowired
	EmployeeCrudRepo empCrud;

	@Override
	public Employee addEmployee(Employee employee) {
		if(employee.getName().isEmpty() || employee.getName().length() == 0) {
			throw new EmptyInputException("601", "Input fileds are empty");
		}
		Employee savedEmployee = empCrud.save(employee);
		return savedEmployee;
	}

	@Override
	public List<Employee> getAllEmployees() {
			List<Employee> empList = empCrud.findAll();
		if (empList.isEmpty()) {
			throw new BusinessException("604", "employee list is empty.. nothing to return");
		}
		return empList;
	} 
	

	@Override
	public Employee getEmployeeById(Long id) {
		// NoSuchElementException - if there is no value present
		return empCrud.findById(id).get();
	}

	@Override
	public void deleteEmpById(Long id) {
			empCrud.deleteById(id);
	}
	
}
