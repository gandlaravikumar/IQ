package com.codedecode.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.codedecode.demo.entity.Employee;
import com.codedecode.demo.service.EmployeeServiceInterface;

@RestController
public class EmployeeController {

	
	@Autowired
	EmployeeServiceInterface employeeServiceInterface;
	
	@PostMapping("/save")
	//@RequestBody it is used to handle the request parameter should be bound in the body if the web request
	public ResponseEntity<?> addEmployee(@RequestBody Employee employee) {
		Employee employeeSaved = employeeServiceInterface.addEmployee(employee);
		return new ResponseEntity<Employee>(employeeSaved, HttpStatus.CREATED);
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Employee>> getAllEmployee() {
		return new ResponseEntity<List<Employee>>(employeeServiceInterface.getAllEmployees(), HttpStatus.OK);
	}
	
	@GetMapping("/emp/{id}")
	public ResponseEntity<?> getEmployeeById(@PathVariable Long id) {
		return new ResponseEntity<Employee>(employeeServiceInterface.getEmployeeById(id), HttpStatus.OK);
	}
	
	@DeleteMapping("/emp/{id}")
	public ResponseEntity<?> deleteEmpById(@PathVariable Long id) {
		employeeServiceInterface.deleteEmpById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@PutMapping("/update")
	//@RequestBody it is used to handle the request parameter should be bound in the body if the web request
	public ResponseEntity<?> updateEmployee(@RequestBody Employee employee) {
		Employee employeeSaved = employeeServiceInterface.addEmployee(employee);
		return new ResponseEntity<Employee>(employeeSaved, HttpStatus.CREATED);
	}
}
