In this project CRUD operations are there, SpringBoot + Hibernates + REST API. along with Global Exception Handling in Spring Boot.

@ControllerAdvice:
This annotation handles exceptions globally. It allows you to use the same ExceptionHandler for multiple controllers.
This way, we can define how to treat an exception in just one place because this handler will be called whenever the exception is 
thrown from classes that are covered by ControllerAdvice.

@ResponseStatus:
Our error responses are always giving us the HTTP status 500 instead of a more descriptive status code.
To address this we can annotate our Exception with @ResponseStatus and pass in the desire HTTP response status.

@ExceptionHandler : Spring annotation that provides a mechanism to treat exceptions that are thrown during execution of handlers (Controller operations).
This annotation, if used on methods of controller classes, will serve as the entry point for handling exceptions thrown within this controller only.

Although, the most common way is to use @ExceptionHandler on methods of @ControllerAdvice classes so that the exceptions handling will be applied globally.
@ExceptionHandler and @ColntrollerAdvice are used to define a central point for treating exceptions and wrapping them up in a class.

why always prefer to Global Exception handling not to Custom Exception handing?
-> In Custom Exception Handling, suppose in controller class having 100 methods, each method should handle the exceptions with try and catch block.
Then the code becomes very huge and boiler plate code will increase.
-> In Global Exception handling, no need to write try and catch block for every method in controller class.
we define all the types of exceptions in only one class (MyControllerAdvice.java), there we handle the exceptions Globally.

why Custom Exceptions?
the reason is that there might be a case that not all controller methods are going to handle the same type of exceptions.
Means that, different controller methods handles different type of exceptions (student exception, teacher exception, null pointer exception).
There we need different catch and different customized exception and different messages for different controllers. 
In that case we need to use Custom Exception.
But if you have some thing which is common exceptions handle by most of the controllers then we need to go for Global Exception Handling,
as the bolier plate code is reduced.


How CustomExceptions will work?
Ans: If request comes from controller to service. In service class exception raised and throw it back to controller class.
In controller class by using catch block will handle the exception. 
If 100 methods throws nullPointerExceptions, then 100 times we need to write cache block in custom exception handling. That' y GlobalException came.
If 100 methods throws 100 different exceptions, then customException is the recommended way.

How GlobalExeptions will work?
Ans: If request comes from controller to service. In service class exception raised and throw it back to controller class.
But in controller class there is no catch block to handle the exceptions. So, That's y we created one class called MyControllerAdvice.java
and annotated with @ControllerAdvice. This class works like GlobalException class. 
Means in MyControllerAdvice.java class i defined how to handle NullPointerException. 
In entire application where NullPointerException will comes, this MyControllerAdvice.java class will handles.

