package com.telusko.springbootFirstPrgm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
/*
 * @Scope(value = "prototype") 
 * prototype -> It will not create instance by default for you. 
 * If i run the application it will not create objects and not store in spring container, until if
 * i call getBean(). if i call multiple times (getBean()) it will create
 * multiple objects.
 */
public class Alien {
	
	private int aid;
	private String aname, tech;
	@Autowired      // By default @Autowired will search with Type of the object.
	@Qualifier("lap1") // @Qualifier is used to search with name of the object. By default it will be de-capitilized like @Qalifier("laptop"). If i use @Qualifier("lap1"), then in the Laptop class @Component also should be the same name like @Component("lap1")
	private Laptop laptop;
	
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	public Laptop getLaptop() {
		return laptop;
	}
	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}
	
	public void show() {
		System.out.println("showing");
		laptop.complie();
	}

}
