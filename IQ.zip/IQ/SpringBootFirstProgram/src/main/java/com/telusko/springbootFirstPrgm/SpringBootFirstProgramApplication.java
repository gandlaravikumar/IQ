package com.telusko.springbootFirstPrgm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
/*
 * As per the Spring Boot doc, the @SpringBootApplication annotation is
 * equivalent to using @Configuration, @EnableAutoConfiguration,
 * and @ComponentScan with their default attributes. Spring Boot enables the
 * developer to use a single annotation instead of using multiple. But, as we
 * know, Spring provided loosely coupled features that we can use for each
 * individual annotation as per our project needs.
 */
public class SpringBootFirstProgramApplication {

	public static void main(String[] args) {
		//Here ConfigurableApplicationContext is nothing but Spring container.
		ConfigurableApplicationContext context = SpringApplication.run(SpringBootFirstProgramApplication.class, args);
		
		Alien a = context.getBean(Alien.class);
		
		a.show();
	}

}
