package com.java8.programs;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.HashMap;

/*Count the no of occurrence of words in given string using java 8?
input: "welcome to code decode and code decode welcome you";
output: {code=2,and=1,to=1,decode=2,welcome=2,you=1}*/
public class OccurrenceOfWordsInGivenString {
	
	public static void main(String[] args) {
		String str ="welcome to code decode and code decode welcome you";
		
		usingOldway(str);
		usingJava8(str);
		usingCollectionsFrequency(str);
		occurrenceOfSingleWord("Communication");
		
	}

	private static void usingOldway(String str) {
		String[] sArray = str.split(" ");
		Map<String, Integer> map = new HashMap<String, Integer>();
		int occurrence = 0;
		
		for(int i=0; i<sArray.length; i++) {
			for(int j=0; j<sArray.length; j++) {
				if(sArray[i].equalsIgnoreCase(sArray[j])) {
					occurrence ++;
				}
			}
			map.put(sArray[i], occurrence);
			occurrence = 0;
		}
		System.out.println(map);
	}

	private static void usingJava8(String str) {
		List<String> list = Arrays.asList(str.split(" "));
		// collect this list in such a way that will get a map like key as a word and value as their occurrence of the word.
		// groupingBy function will collect all the similar element and it will return the count of that.
		
		//Function interface having static method called identity. 
		//This identity method will return what ever we are passing in identity. Ex below.
				//Function<String,String> fn = Function.identity();
				//System.out.println(fn.apply("hi"));
				
		Map<String, Long> map = list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(map);
		
		// another way to print the map
		//map.entrySet().forEach(System.out::println);
		
		// If you print the repeated keys only
		map.entrySet().stream().filter(entry -> entry.getValue()>1).map(entry -> entry.getKey()).forEach(System.out::println);
		// I am filtering the entry which value is >1. From that entry am taking key and printing
		
	}

	private static void usingCollectionsFrequency(String str) {
		List<String> words = Arrays.asList(str.split(" "));
		Set<String> result = words.stream().filter(word -> Collections.frequency(words, word) >1).collect(Collectors.toSet());
		// passing list of words, and single word in frequency() method, and checking the word frequency is >1 in that list or not.
		System.out.println(result);
	}
	
	
	private static void occurrenceOfSingleWord(String str) {
		Map<String, Long> map = Arrays.stream(str.split("")).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(map);
	
	}
}
