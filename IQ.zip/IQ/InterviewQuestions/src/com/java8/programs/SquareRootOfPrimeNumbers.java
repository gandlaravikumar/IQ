package com.java8.programs;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

// Square root of first 10 prime numbers in java 8?
public class SquareRootOfPrimeNumbers {
	
	public static void main(String[] args) {
		
		usingOldWay();
		usingNewWay();
	}

	private static void usingOldWay() {
		List<Double> sqRootList = new ArrayList<Double>();
		int i=2;
		while(sqRootList.size()<10) {
			if(isPrime(i)) {
				sqRootList.add(Math.sqrt(i));
			}
			i++;
		}
		System.out.println(sqRootList);
	}

	private static boolean isPrime(int number) {
		return number>1 && IntStream.range(2, number).noneMatch(i -> number%i==0);
	}

	private static void usingNewWay() {
		List<Double> sqRootList = Stream.iterate(1, i->i+1) //Iterate from 1.
								  .filter(SquareRootOfPrimeNumbers::isPrime) // Filter the prime numbers by using method reference (Because we have already implemented method isPrime).
								  .map(Math::sqrt) // get the sqrt for the prime numbers.
								  .limit(10) // up to 10 sqrt limit
								  .collect(Collectors.toList()); // finally collect to the list.
		
		System.out.println(sqRootList);
		// In between we can use peek() also for debug.
		
	}


}
