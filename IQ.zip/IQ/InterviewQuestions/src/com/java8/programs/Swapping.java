package com.java8.programs;

public class Swapping {

	public static void main(String[] args) {
		
		// Swapping of two numbers
		int x = 10;  
		int y = 20; 
		  x = x + y;  
		  y = x - y;  
		  x = x - y; 
		  
		  System.out.println("value of x:" + x);  
		  System.out.println("value of y:" + y); 
		  
		// Swapping of two strings
		  String firstName = "ravi";
		  String LastName = "kumar";
		  
		  //Step1: append the 2 strings like a = a+b
		  //Step2: call the method substring(int beginindex, int endindex). beginindex as 0 and endindex as, a.length() - b.length()
		  //Step3: call the method substring(int beginindex) by passing  b.length() as argument
		  firstName = firstName + LastName; // raviKumar
		  
		  LastName = firstName.substring(0,firstName.length() - LastName.length());
		  firstName = firstName.substring(LastName.length());
		  System.out.println(firstName);
		  System.out.println(LastName);
	}
}
