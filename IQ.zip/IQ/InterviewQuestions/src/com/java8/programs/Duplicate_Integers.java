package com.java8.programs;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/*Find the duplicate elements in a given integers list in java using stream functions?
input : [10,28,87,10,20,76,28,80,80,80]
output: 10,28,80*/
public class Duplicate_Integers {
	
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(10,28,87,10,20,76,28,80,80,80);
		
		//step1: Take a set
		Set<Integer> set = new HashSet<Integer>();
		
		//step2: add the list values to set.
	   // Generally set adds only unique values. If i put not condition (!) to set, it will add only duplicate values.
		list.stream().filter(x -> !set.add(x)).collect(Collectors.toSet()).forEach(x -> System.out.println(x));
	}

}
