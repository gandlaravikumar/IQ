package com.java8.programs;

import java.awt.RenderingHints.Key;
import java.util.stream.IntStream;

//Refactor the given isPrime(int num) to java 8?
//The number which is divided by 1 and itself only. is called prime number.
//Why is 1 not a prime number?
// 1 is not a prime number because it has only one factor, namely 1. Prime numbers need to have exactly two factors.
//Why is 2 a prime number?
//2 is a prime number because its only factors are 1 and itself(2).

public class IsPrimeNumber {

	public static void main(String[] args) {
		
		int number = 6;
		// check the given number is prime or not
		usingOldMethod(number);
		
		// Can you refactor this usingOldMethod(number) code into java8? yes ofcourse. please check below.
		usingJava8(number);
	}
	
	private static void usingOldMethod(int number) {
		// Example if i want to check a number is prime or not.
		// I should check that number will be divided by any other numbers or not. except 1 and itself.
		// I should not divide that number with 1 or itself. So int i value should start from 2 in for loop.
		// Also i value, number value should not be same. Because number should NOT be divide by itself. That's y it should i<number in for loop.
		boolean isPrime = true;
		for(int i=2; i<number; i++) {
			if(number%i == 0) {
				isPrime = false;
				break;
			}
		}
		if(isPrime && number>1) { // Here the number should be greater than 1. Because 1 is not a prime number.
			System.out.println(number +" "+"is a prime number");
		} else {
			System.out.println(number +" "+"is not a prime number");
		}
		
	}
	
	private static void usingJava8(int number) {
		// Take a static method range() from IntStream Interface. Pass the startInclusive, endExclusive.
		// It will iterate from 2 to number. For every iterate it will try to divide the number.
		// If the condition (number%i==0) satisfied, then it is not a primary key.
		// If the condition not satisfied, then it is a primary key. 
		// Hence am taking noneMatch (not satisfied) condition. If none matched (nothing) with that condition. Then it is a primary key.
		boolean result = number>1 && IntStream.range(2, number).noneMatch(i -> number%i==0);
		
		if(result) {
			System.out.println(number +" "+"is a prime number");
		} else {
			System.out.println(number +" "+"is not a prime number");
		}
	}

}
