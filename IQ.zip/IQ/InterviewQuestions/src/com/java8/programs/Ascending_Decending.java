package com.java8.programs;

import java.util.ArrayList;
import java.util.List;

//Print Employee details based on salary Descending order?
public class Ascending_Decending {

	public static void main(String[] args) {
		Employee e1 = new Employee(234, "lokesh", 350);
		Employee e2 = new Employee(43, "sahana", 250);
		Employee e3 = new Employee(435, "bhavana", 150);
		Employee e4 = new Employee(53, "ravi", 100);
		Employee e5 = new Employee(42, "telusko", 200);
		Employee e6 = new Employee(425, "tpoint", 400);
		Employee e7 = new Employee(58, "w3schools", 300);
		
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(e1); employeeList.add(e2); employeeList.add(e3); employeeList.add(e4);
		employeeList.add(e5); employeeList.add(e6); employeeList.add(e7);
		
		// Print Employee details based on salary Descending order
		employeeList.stream().sorted((obj1,obj2) ->obj2.getSalary()-obj1.getSalary()).forEach(x -> System.out.println(x));
		
		// Print only Employee Id's based on Ascending order.
		employeeList.stream().sorted((obj1,obj2) ->obj1.getId()-obj2.getId()).map(x -> x.getId()).forEach(x -> System.out.println(x));
		
		// Fetch Top 3 salaried Employees
		employeeList.stream().sorted((obj1,obj2) ->obj2.getSalary()-obj1.getSalary()).limit(3).forEach(x -> System.out.println(x));
		
		//  Fetch all employees having salary Less than 3rd highest salary
		employeeList.stream().sorted((obj1,obj2) ->obj2.getSalary()-obj1.getSalary()).skip(3).forEach(x -> System.out.println(x));
	}

}

class Employee {
	private int id;
	private int salary;
	private String name;
	public Employee() {
		
	}
	
	public Employee(int id, String name, int list) {
		super();
		this.id = id;
		this.salary = list;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
}