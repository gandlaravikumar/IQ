package com.java8.programs;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class InterviewQuestions {

	public static void main(String[] args) {
		// count the no of occurrence of words in given string using java 8
		String input = "welcome to code decode and code decode welcome you find code to to to";
		String[] words = input.split(" ");
		Map<String, Long> map = Stream.of(words).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(map);
		
		//find the duplicate elements in a given integers list in java using stream functions?
		// input: [10,28,87,10,20,76,28,80]
		// output: 10,28
		
		List<Integer> list = Arrays.asList(10,28,87,10,20,76,28,80);
		Set<Integer> set = new HashSet<Integer>();
		list.stream().filter(x -> !set.add(x)).forEach(x -> System.out.println(x));
		
		// input: [10,28,87,10,20,76,28,80,80,80]
		// output: 10,28,80
		List<Integer> numbers = Arrays.asList(10,28,87,10,20,76,28,80,80,80);
		Set<Integer> s = new HashSet<Integer>();
		numbers.stream().filter(x -> !s.add(x)).collect(Collectors.toSet()).forEach(x -> System.out.println(x));
		
		
		// difference between limit() and skip() with examples
		List<Integer> ls = Arrays.asList(4,5,6,8,23,35,36,77,78,99);
		ls.stream().limit(7).forEach(x -> System.out.println(x+" "));
		ls.stream().skip(7).forEach(x -> System.out.println(x+" "));
		
		// given number is prime or not
		System.out.println(isPrime(7));
		
		// print square root of first 10 prime numbers
		List<Double> sqrtOf10Prime = Stream.iterate(1, i -> i+1)
									 .filter(InterviewQuestions::isPrime)
									 .map(Math::sqrt)
									 .limit(10)
									 .collect(Collectors.toList());
		System.out.println(sqrtOf10Prime);

	}
	
	public static boolean isPrime(int number) {
		return number>1&& IntStream.range(2,  number).noneMatch(n -> number%n==0);
	}

}
