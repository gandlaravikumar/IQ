package com.java8.programs;
// Write a program to multiply 2 no's using Functional interface?
public class MultipleNumbers {

	public static void main(String[] args) {
		Finterface f = (a,b) -> a*b;
		System.out.println(f.multiplyTwoNumbers(2, 3));
	}
}
