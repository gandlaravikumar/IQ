package com.java8.programs;

@FunctionalInterface
public interface Finterface {
	
	public int multiplyTwoNumbers(int a, int b);

}
