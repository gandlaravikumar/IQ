package com.oops;

import java.util.Scanner;

public class FindingAverageOfNumbers {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int dailyIncome;
		int totalIncome = 0;
		int avgIncome;
		int x = 0;
		int numberOfDaysIncome = 5;
		
		while(x < numberOfDaysIncome) {
			x++;
			System.out.println("Enter your Income of day "+x+" : ");
			dailyIncome = input.nextInt();
			totalIncome = totalIncome + dailyIncome;
		}
		avgIncome = totalIncome/numberOfDaysIncome;
		
		System.out.println("averageIncome is "+avgIncome);
	}
}
