package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

// To run this program ojdbc jar is required. Add this jar to java build path.
public class OracleJdbcTest {

	static final String DB_URL = "jdbc:oracle:thin:@10.51.136.39:1521:TLMRAC2";
	   static final String USER = "oracle_trlms_admin";
	   static final String PASS = "LaD64.FPTh711";
	public static void main(String[] args) {
		try {
		Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
		Statement stmt = conn.createStatement();
		ResultSet rs=stmt.executeQuery("select * from users");  
         while (rs.next()) {
            // Retrieve by column name
            System.out.print(", First: " + rs.getString("FIRSTNAME"));
         }
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } 
	}



}
