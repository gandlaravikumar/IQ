
public class Childern {
	private int childernId;
	private String childernName;
	//In the child pojo class, create an additional property of type parent for storing the parent object in child object.
	private Parent parentObjects;
	
	public int getChildernId() {
		return childernId;
	}
	public void setChildernId(int childernId) {
		this.childernId = childernId;
	}
	public String getChildernName() {
		return childernName;
	}
	public void setChildernName(String childernName) {
		this.childernName = childernName;
	}
	public Parent getParentObjects() {
		return parentObjects;
	}
	public void setParentObjects(Parent parentObjects) {
		this.parentObjects = parentObjects;
	}
}
