import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

//In the many to one relationship, the relationship is applied from child object to parent object, 
//but in one to may parent object to child object right..! just remember
public class LogicForInsert {
	public static void main(String[] args) {
		//Insert (If i insert childrens, Parent also will insert)
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Parent p = new Parent();
		p.setParentId(480);
		p.setParentName("ravi");
		
		Childern c1 = new Childern();
		c1.setChildernId(1);
		c1.setChildernName("Bhavana");
		c1.setParentObjects(p);
		
		Childern c2 = new Childern();
		c2.setChildernId(2);
		c2.setChildernName("Gundu");
		c2.setParentObjects(p);
		
		Transaction transaction = session.beginTransaction();
		session.save(c1);
		session.save(c2);
		
		transaction.commit();
		
		// Select (If i want to select one children, respective parent also will select)
		// If i want to select one children and their parent
		Object obj = session.get(Childern.class, new Integer(2));
		Childern selectChildern = (Childern) obj;
		System.out.println(selectChildern);
		System.out.println(selectChildern.getParentObjects());
		
		
		// If i want to select all childrens and their parents
		Query qry = session.createQuery("from Childern c");
		List l = qry.list();
		Iterator it = l.iterator();
		while (it.hasNext()) {
			Object object = it.next();
			Childern childern = (Childern) object;
			System.out.println(childern);
			System.out.println(childern.getParentObjects());
		}
		
		// If we delete child, parent will not deleted because, it may have lot of other child objects.
		// if parent has only one child, in this case if we delete child, parent will also got deleted, but in all other cases it will throws exception.
		// Make sure it should have only one children. If multiple children is there, it will throw an exception.
		Object o = session.get(Childern.class, new Integer(1));
		Childern deleteChildern = (Childern) o;
		Transaction deleteTransaction = session.beginTransaction();
		session.delete(deleteChildern);
		deleteTransaction.commit();
		
		
	}
}
