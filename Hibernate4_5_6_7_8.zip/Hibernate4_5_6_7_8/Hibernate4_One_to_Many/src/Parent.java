import java.util.Set;

public class Parent {
	
	private int parentId;
	private String parentName;
	private Set childerns;
	
	public int getParentId() {
		return parentId;
	}
	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
	
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public Set getChilderns() {
		return childerns;
	}
	public void setChilderns(Set childerns) {
		this.childerns = childerns;
	}
	
}
