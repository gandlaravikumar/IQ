import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

//One to Many means -> one row of table related with multiple rows of other table
// One parent have multiple Childrens
public class LogicForInsert {
	public static void main(String[] args) {
		//Insert (If i insert Parent, childrens also will insert)
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Parent p = new Parent();
		p.setParentId(480);
		p.setParentName("ravi");
		
		Childern c1 = new Childern();
		c1.setChildernId(1);
		c1.setChildernName("Bhavana");
		
		Childern c2 = new Childern();
		c2.setChildernId(2);
		c2.setChildernName("Gundu");
		
		Set s = new HashSet();
		s.add(c1);
		s.add(c2);
		
		p.setChilderns(s);
		
		Transaction transaction = session.beginTransaction();
		//session.save(p);
		
		transaction.commit();
		
		// Select (If i want to select one Parent, respective childrens also will select)
		// If i want to select one parent and their children
		Object obj = session.get(Parent.class, new Integer(480));
		Parent selectParent = (Parent) obj;
		System.out.println(selectParent);

		// If i want to select all parents and their childrens
		Query qry = session.createQuery("from Parent p");
		List l = qry.list();
		Iterator it = l.iterator();
		while (it.hasNext()) {
			Object object = it.next();
			Parent parent = (Parent) object;
			System.out.println(parent);
		}
		
		//Delete (If i delete Parent, childrens also will delete)
		Object o = session.get(Parent.class, new Integer(480));
		Parent deleteParent = (Parent) o;
		Transaction deleteTransaction = session.beginTransaction();
		//session.delete(deleteParent);
		deleteTransaction.commit();
		
		
		
	}
}
