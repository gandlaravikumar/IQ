
public class Childern {
	private int childernId;
	private String childernName;
	// this parentId is foreign key
	private int parentId;
	
	public int getChildernId() {
		return childernId;
	}
	public void setChildernId(int childernId) {
		this.childernId = childernId;
	}
	public String getChildernName() {
		return childernName;
	}
	public void setChildernName(String childernName) {
		this.childernName = childernName;
	}
	public int getParentId() {
		return parentId;
	}
	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
}
