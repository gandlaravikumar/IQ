package com.telusko.JpaDemo;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class AppLogic {

	public static void main(String[] args) {
		
		/*
		 * Basically all the classes which represents the database table in JPA is
		 * called Entityes. To manage those entityes we have EntityManager.
		 */
		/*
		 * Here am building this maven application using JPA specifications with hibernates. in feature
		 * if i want to change from hibernates to toplink, only dependencies need to
		 * modify is enough in pom.xml. (In place of hibernate dependencies toplink
		 * dependencies needs to be replace. with other minor changes switching will be
		 * done.)
		 */
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu"); // This "pu" is the name of persistence-unit. which is available in persistence.xml
		EntityManager entityManager = emf.createEntityManager();
		
		// To save the object in DB
		Alien a = new Alien();
		a.setAid(45);
		a.setName("Gundu");
		a.setTech("playing");
		
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		// To save the object in DB we need to use persist() of entity manager.
		entityManager.persist(a);
		entityTransaction.commit();
		
		// To fetch the object from DB we need to use find() of entity manager.
		Alien alien = entityManager.find(Alien.class, 4);
		System.out.println(alien);
	}
}
