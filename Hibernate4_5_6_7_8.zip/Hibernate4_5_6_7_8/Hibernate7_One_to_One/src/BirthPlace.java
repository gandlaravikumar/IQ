public class BirthPlace {
	private int BirthNo;
	private String BirthLocation;
	private Student s;
	
	public int getBirthNo() {
		return BirthNo;
	}
	public void setBirthNo(int birthNo) {
		BirthNo = birthNo;
	}
	public String getBirthLocation() {
		return BirthLocation;
	}
	public void setBirthLocation(String birthLocation) {
		BirthLocation = birthLocation;
	}
	public Student getS() {
		return s;
	}
	public void setS(Student s) {
		this.s = s;
	}
}
