import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/*1. To apply one to one relationship between two pojo class objects it is possible by without taking a separate 
	 foreign key column in the child table of the database.
2. To apply one to one relationship, we copy the primary key value of parent object into primary key value of the child object.
   So that the relationship between two objects is one to one.
3. If we want to copy parent object primary key value into child object primary key,
   we need to use a special generator class given by hibernate called foreign.
   Actually this foreign generator is only used in one to one relationship only.
4. We are going to apply one to one between student and BirthPlace pojo classes, here the relation is one BirthPlace is assigned for one student only.
5. In order to get one to one relationship between student and BirthPlace, we are copying primary key value of student into primary key value of BirthPlace.*/

public class LogicForInsert {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Student s1=new Student();
		s1.setStudentId(100);
		s1.setStudentName("ravi G");

		Student s2=new Student();
		s2.setStudentId(101);
		s2.setStudentName("Gundu R");
		
		BirthPlace h1=new BirthPlace();
		h1.setBirthNo(234); // This value is replace with studentId in DB. means parent object primary key will copy. 
		h1.setBirthLocation("Bangalore");
		h1.setS(s2); // Gundu object

		BirthPlace h2=new BirthPlace();
		h2.setBirthNo(232); // This value is replace with studentId in DB. means parent object primary key will copy.
		h2.setBirthLocation("Tirupathi");
		h2.setS(s1); // Ravi object
		
		
		Transaction transaction = session.beginTransaction();
		//session.save(h1);
		//session.save(h2);
		
		transaction.commit();
	    System.out.println("One to One insert is Done..!!");
	    
	    // Fetch one to one
	    Object o = session.get(BirthPlace.class, new Integer(101));
	    BirthPlace a = (BirthPlace)o;
	    Student s = a.getS();
	    System.out.println(s.getStudentName());
        System.out.println(a.getBirthLocation());
	}
}
