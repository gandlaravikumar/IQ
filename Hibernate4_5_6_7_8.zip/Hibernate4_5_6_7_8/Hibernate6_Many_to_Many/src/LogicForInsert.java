import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/*Applying many to many relationship between two pojo class objects is nothing but applying one to many relationship on both sides,
which tends to Bi-Directional i mean many to many. */
/*The relationship is one student may joined in multiple courses and one course contains lot of students*/

/*While applying many to many relationship between pojo classes,  a mediator table is mandatory in the database, 
to store primary key as foreign key both sides, we call this table as Join table.*/

public class LogicForInsert {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Student s1=new Student();
		s1.setStudentId(100);
		s1.setStudentName("James");
		s1.setMarks(98);

		Student s2=new Student();
		s2.setStudentId(101);
		s2.setStudentName("Lee");
		s2.setMarks(99);
		
		Course c1=new Course();
		c1.setCourseId(500);
		c1.setCourseName("Hibernate");
		c1.setDuration(7);

		Course c2=new Course();
		c2.setCourseId(501);
		c2.setCourseName("Java");
		c2.setDuration(30);
		
		Set s =new HashSet();
	      s.add(c1);
	      s.add(c2);

	      s1.setCourses(s);
	      s2.setCourses(s);
		
		Transaction transaction = session.beginTransaction();
		session.save(s1);
		session.save(s2);
		
		transaction.commit();
		session.close();
	    System.out.println("Many To Many Bi-Directional is Done..!!");
	    sessionFactory.close();
	}
}
