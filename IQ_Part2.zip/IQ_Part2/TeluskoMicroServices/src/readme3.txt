Difference Between CLOUD-READY VS CLOUD-NATIVE:
CLOUD-READY: The application which is ready to move from own servers(On-Premises) to Cloud.
for this we need to change the configuration files and work with environment variables ect.
CLOUD-NATIVE: The new application is developed freshely to deploy in Cloud.

We need to follow some rules to achive the CLOUD-NATIVE.,
That is 12 Factor App:
1.CodeBase : One codebase tracked in revision control, many deployment enironments.
you should have only one codebase to track version control. Example gitlab or github ect.
And you can have many environments, like dev environment, QA environment, production environment etc.
2.Dependencies: In earlier days we are using lib folder where we can store all the jar files or dependencies.
If i want to give this application to DEV OOPS team, i need to give this lib jars also. That is not a good idea.
might be version difference issues will come.
make sure you have a seperate file like Manifest file. Example in java we have Maven.
In Maven we have to mention all the dependencies with versions.
Don't link it with code base. keep it seperate. whenever you are sharing this codebase with someone, you also share this manifest file.
They can download with version and actual dependencies.
3.Configuration: Don't hardcode database connection url or username or password or port numbers etc anywhere in code.
Create a environment file or .env file or .properties file and save all the values there.
If you change the physical server or anything related to your environment you don't have to change your source code.
Just change the environment variable and your job is done. Don't touch your source code once it is build.
4.Backing Services: Having loose coupling between your application and backing services.
Backing services are nothing but databases or 3rd party services which you are using. Try to create a separate stuff for that backing services.
Treat this kind of backing services as a attached resources. Might be in feature it will change.
Example: currently you are using Mysql, later if you want you can change to postgress. That switching will be easy.
Configure separately and treat as part of resource. Not as part of application.
5.Build,Release,run: If your code is ready, first build it. In java you can do it with Maven.
Once you got the jar file, you can give a release to it.Maybe configuration,environmentable variables and all the stuff. This release will go to the running environment.
6.Processes: Execute the app as one or more stateless processes.
Means, In the earlier days we are going for sessions or statefull services.
Statefull means, as a client if you connect to a particular server for the first request and you share some data. Next time when ever you connect to the server, sever knows you.
server knows you who are you, they have information about you. It is good only instead of sending every request newly.
what happens if something went wrong with the statefull service. server didn't reconize you.
But the idea behind is, instead of going statefull, go for stateless.
Where every process is just a process, is not storing any data in the process. Here every request behaves as a new request and process it.
7.Port binding: Every service is having unique port number.
Example: In microservices, every service is having different port number.
8.Concurrency:Scale out via the process model.
Means, even though if you are using multithreading, it can scale upto limit.
if you are using particular machine, i want to use multiple threads, and i want to use complete power of machine. But ofcourse machine has a limit there right.
Instead of going scale up you can go for scale out. means instead of going for vertical scaling, go for horizontal scaling.
example: instead of going for one machine with 4 CPU and 4 GB RAM. go with each machine have 1 CPU with 1 GB RAM.
9.Disposability:Every time where ever you open the resource and make sure you close it.
When every sometings goes wrong, make sure all the data should store in DB properly and graceful shutdown.
10.Dev/Prod parity:Keep development, staging and production as similar as possible. Means no much gap between development and production.
11.Logs:Treat logs as event streams.
12.Admin Processes:Run admin/management tasks as ON-OFF processes.
By using this 12 Factor App we can build a CLOUD-NATIVE application.

