What is Microservices?
If i want to build a application, first i need to breakdown the application into small modules, like login,payment,users,sellers,search,shipping ect.
So, different team can work on different modules with different technologies. like java,c++,phyton ect.
We can scalibity the modules based on requirement.
Means, If any amazon festival offers going on next week, then we can scalabity the modules based on requirement.
we can run the payment module on 10 instances, search module on 15 instances like that.

What is Cloud Computing?
Ans: A Cloud basically means group of computers on an network.

Why this Cloud Computing?
Ans: In earlier days software development or web application development or if i want to make a website, i need to use certain technologies.
HTML,CSS,JAVASCRIPT,JAVA ect. And to run the application i need a server. which we called as web server.
This web server is running on my machine, ofcourse it also needs an IP address. And bydefault if you are running on your own machine you use something called localhost.
Means it is running in your own local machine. But when you are building an application or website you want to world to use it. you are not doing it for yourself right.
In this case it is not possible. Because the website hosted in your machine and you don't have public ip address. because what you will get from the router are private address.
If you want the world to access your website you need to get the public address, Let's brought the public address.
And now basically use a public IP address for you machine.
Means I have my own laptop, in that laptop i installed the webserver and also i have public address.
And now you can give this public IP address to world, they can use it. If world didn't remember your IP address, that's fine. you can get a domine name and give it to the world.
But the thing is your application is hosted in your laptop now and make sure your application is accessable 24*7 365 days.
But it is not possible. Usually if i forgot to put charger or windows updates or system crash ect.
And also computing power is not suffectient. Because if milions of users try to access your computer and now this laptop is not capable to survey all the customers.
That's y you need a good hardware. In the earlier days we can go for hardware shop and purchase all extra devices to build a good server.
basically you need good server CPU, RAM, Storage and good OS which doesn't go for update frequently.And also we need to provide security.
In earlier days we will get a room and setup the server machines, and make sure it is up and running with good internet speed. elecity power continously, and we have cooling sytem to cool the entrire room environment.
And also we need some people or admin to manage that machine. to do this things and all we need to spend lot of money.
And one more main important problem is, even though if you are to set up this things and all and working fine. daily 1k or 2k people will login to your e-commorse application.
Suddendly tomorrow there is a festival offer, So tomorrow 1 lakh users are tyring to login into your application. Lot of new sales are going or 50% discount ect.
At this point your server will go down. Before it going to down, again you will go for market and purchase again good computing power server and setup things and make it ready to work tommorow for festival sale.
Now the festival sale is over, Now you don't have that much of users. the extra computing power what we purchased for festival sales, it is useless. wasting of money.
To solve this problem, instead of doing yourself everuting like buying the computers, maintaing it, getting the person who maintaing it ect.
THere are some companies who will provide this services.
you can give money to those companies and they will provide the servers and managing it.
These people they will buy server and create a multiple VMs on same server and give it to different clients. which is called multi tenent. which means we don't have one customer, we have multiple cusomter on same server.
Still there is one machine only, what happens if somethings goes worng, any power failure, any network goes down, again entire website goes down.
This is where we though don't use one mchine, lets use multiple machines at multiple locations.
our users are not from one location, there are from multiple locations. (every county)
if you want to get the all the customers you need servers in different locations, that will reduce the latancy also,
Now this is where instad of going for one server, we can go for multiple servers and there are conneted and provide the solution.
For example if i send a request to add 5 numbers to one server, multiple servers can come together and sole the problem.
That's what happens why you search something in google. when you search something in google, it is not one server is involing. There are multiple servers worked together to give you the result.
When you connect multiple servers that's where the new term arrives which is cloud.
cloud is combination of multiple servers which are there, you are not handiling and someone is handiling for you.
There are multiple server providers are there.
Amazon - AWS
Microsoft - Azure
Google - Cloud
IBM etc.
Initially we can ask to colud, hey amazon corrently i have 1k cusomter, give me computing power for those users.
THe moment i get more users, i can just scale it. give me 2 instance or gve me bigger instance.
It is called elastic scalling or Elastic cloud computing.
In daily day life we are using cloud service, Example Google, Gmail, google photos etc.

*In Earlier Days everything is with you. That is On-Premises.
Functions, application, Run time and containers, operating systems and management tools, networking, storage, and servers, Data center with you.
*If you want to use some cloud service, Am ok to manage software layers and OS. But i don't want to manage the hardwares. This is called Iaas. (Infrastructure as a service).
Functions, application, Run time and containers, operating systems and management tools with you. networking, storage, and servers, Data center with cloud.
*I don't want to manage OS also. I can manage only containers like docker or kubernates, application and functions. This is called Caas. (Container as a service)
Functions, application, Run time and containers with you. operating systems and management tools, networking, storage, and servers, Data center with cloud.
*Pass(Platform as a service)
Functions, application with you. Run time and containers, operating systems and management tools, networking, storage, and servers, Data center with cloud.
*Faas(Function as a service)
Functions with you. application, Run time and containers, operating systems and management tools, networking, storage, and servers, Data center with cloud.
*Saas(Software as a service)
Functions, application, Run time and containers, operating systems and management tools, networking, storage, and servers, Data center with cloud. Example: google photos.(photos storing and editing everything in cloud only)

As a developer i will focus more on Caas or Paas.
Now a day all companies are moving from On-Premises t cloud.
But the problem is security. Because for example if you host you application on a public cloud, amazon is managing it.
They can share the hardware with other people as well. In this case there are some issues in terms of security.
As a company you are storing your customers data on 3rd party. there is a kind of rise here. Because bydefault all these servers are public clouds right.
Means they can accessable to everyone by hacking. SO we DON'T trust them. Also we need to follow some regulations from government.
So, we need to create a private cloud inside your companyies wall.
Basically i have a private cloud for my own company. You have multiple data centers. someone is managing it, but you have control on it.
Advantage is safety. Drawback is cost. Because you have to manage everything.
That's y Hybrid cloud came into picture.
Means every company have some confidential data which can place in private cloud. And some data which is OK to put in public cloud. That is called Hybrid cloud.
