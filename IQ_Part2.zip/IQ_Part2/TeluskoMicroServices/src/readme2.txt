Blue-Green Deployment:
Lot of applications or services which you used it says that they are going for maintaince at this time.
Most of the time is mid nights, because less users are using the application.

Example: if you upgrade the application from 1.0 to 1.1 version once a year or 6 months once. and the upgrade will take 1 hour time.
It is ok. no problem.
But now a days, we are using agail methodology. daily or frequently updates are coming with new features.
So daily developers need to wait until midnight to deploy the new version. And the users can't use the application at midnights. Because maintaince is going on.
 
 They upgrade from 2.5 to 3.0.
 Suddenly the application not started after deploy in public server.
 Again you need to go back to older version. Again you need to test it, again you need to deploy it.
 what is the solution for it? The solution is Blue-Green Deployment.
 
 That means we have 2 running instances at a same time.
 one is blue server and second one is green server.
 At one point only one instance is live. Even you have 2 running instances. only one instance is access for public (Blue instance is live).
 In Green instance, developer team will upgrade the application from 2.5 to 3.0.
 The moment you upgrade the green instance and you think it is ready to go live now, you will gradually move your users from blue to green.
 offcourse you will not move every one because what if something goes worng. so do it gradually.
 if something goes worng, least users will get effected.
 If all the users are moved to green, then blue will go to idel state.
 Blue server we can use as recovery server. If something goes worng in green, wroute all the traffice to blue.
 If green is working fine, then upgrade blue instance also.
 If now again 3.1 version came. now i need to update in blue first. Same process will repeat.
 
 Note: we have a Router configuration in between user and application.
 So that Router routs the user request to the live server.
 