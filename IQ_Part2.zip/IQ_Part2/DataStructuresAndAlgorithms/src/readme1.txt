first go through com.telusko:
first go through linearbinarysearchimplementation
next go through bubblesortimplementation
next go through selectionsortimplementation
next go through insertionsortimplementation
next go through quicksortimplementation
next go through mergesortimplementation

next go through com.codedecode 1,2,3....