Code Decode interview Question:
1. Given an integer array nums sorted in non-decreasing order, return an array of the squares of each number sorted in non-decreasing order.
Example 1:
input: nums = [-4,-1,0,3,10]
output: [0,1,9,16,100]
Explanation: After squaring, the array becomes [16,1,0,9,100]
After sorting, it becomes [0,1,9,16,100].

Example 2:
Input nums = [-7,-3,2,3,11]
Output: [4,9,9,49,121]

We can achive this example in 2 Techniques.
1. Brute Force Technique. -> Take the time complexity O(n2)
2. Two Pointers Technique. -> Take the time complexity O(n). (recommended)