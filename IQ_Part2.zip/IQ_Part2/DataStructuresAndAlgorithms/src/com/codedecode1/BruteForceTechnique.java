package com.codedecode1;

public class BruteForceTechnique {
	//Take the time complexity O(n2)
	public static void main(String[] args) {
		int[] nums = {-4,-1,0,3,10};
		productSubArray(nums);
		
		for(int n : nums) {
			System.out.print(n+" ");
		}

	}
	
	static void productSubArray(int[] a) {
		for (int i =0; i <=a.length-1; i++) {
			a[i] = a[i] *a[i];
		}
		
		int size = a.length;
		for(int i=0; i < size-1; i++) {
			for(int j=0; j< size-i-1; j++) {
				if(a[j] > a[j + 1]) {
					int temp = a[j];
					a[j] = a[j+1];
					a[j+1] = temp;
				}
			}
		}
	}
}
