Most asked LinkedList Coding Interview Question.

Question: How to find if a linked list contains a cycle loop or not in java?
1) With fast and slow pointer approach.
	a) Time complexity: O(n). Only one traversal of the loop is needed.
	b) Auxiliary Space: O(1) There is no space required.