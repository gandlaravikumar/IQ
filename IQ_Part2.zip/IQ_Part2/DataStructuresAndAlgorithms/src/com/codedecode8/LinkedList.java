package com.codedecode8;

public class LinkedList {

	class Node {
		int data;
		Node next = null;
		
		Node(int data) {
			this.data = data;
		}
	}
	
	Node head = null;
	Node tail = null;
	
	public void addNodes(int new_Data) {
		Node new_Node = new Node(new_Data);
		
		if(head == null) {
			head = new_Node;
			tail = new_Node;
		} else {
			tail.next = new_Node;
			tail = tail.next;
		}
	}
	
	public static void main(String[] args) {
		LinkedList linkedList = new LinkedList();
		
		linkedList.addNodes(1);
		linkedList.addNodes(2);
		linkedList.addNodes(3);
		linkedList.addNodes(4);
		linkedList.addNodes(5);
		linkedList.addNodes(6);
		
		linkedList.head.next.next.next = linkedList.head.next;
		
		linkedList.findCycleLoopInLinkedList();
	}

	private void findCycleLoopInLinkedList() {
		Node slowPointer = head;
		Node fastPointer = head;
		
		while(slowPointer !=null && fastPointer!=null && fastPointer.next!=null) {
			fastPointer = fastPointer.next.next;
			slowPointer = slowPointer.next;
			
			if(slowPointer == fastPointer) {
				System.out.println("we have a loop here at node "+slowPointer.data);
				break;
			}
		}
	}

}
