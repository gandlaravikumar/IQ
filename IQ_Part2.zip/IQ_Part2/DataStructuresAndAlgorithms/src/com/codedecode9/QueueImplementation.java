package com.codedecode9;

public class QueueImplementation {

	class Node {
		String item;
		Node behind;
	}
	public Node head = null;
	public Node tail = null;
	
	public boolean isEmpty() {
		if(head == null) {
			return true;
		} else {
			return false;
		}
	}
	
	public void enqueue(String str) {
		if(head == null) {
			head = new Node();
			head.item = str;
			tail = head;
			return;
		}
		tail.behind = new Node();
		tail.behind.item = str;
		tail = tail.behind;
	}
	
	public String dequeue() {
		if(isEmpty()) {
			return null;
		} else {
			String returnVal = head.item;
			head = head.behind;
			return returnVal;
		}
	}
	public static void main(String[] args) {
		QueueImplementation myQueue = new QueueImplementation();
		System.out.println(myQueue.isEmpty());
		myQueue.enqueue("String A");
		myQueue.enqueue("String B");
		myQueue.enqueue("Srring C");
		System.out.println(myQueue.isEmpty());
		System.out.println(myQueue.dequeue());

	}

}
