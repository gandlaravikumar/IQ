Stack and Queue Operations / Implementations:

What is Stack?
* It is a linear Data Structure.
* Only one item can be accessed at one time.
* It is a LIFO (Last In First Out) data structure.

Operations supported by Stack:
* Push: This functionality is used to add an element to the stack.
* Pop: This method will remove the top element from stack and return it.
* IsEmpty: This function will return true is the stack is empty, otherwise it will rturn false.

Applications of Stack:
* Reversing a String.
* Validating parenthesis in expressions.
* Converting an expression from infix to postfix.

Different ways to make a Stack:
* java.util.List
* java.util.Array
* java.util.Stack
* Linked List

What is Queue?
* Queue is a linear data structure.
* Only one item can be accessed at one time.
* It is a FIFO (First In First Out) data structure.

Operations supported by Queue:
* Enqueue: Inserts an element at the rear end of the queue.
* Dequeue: Deleted and returns the value of an item from the front end of the queue.
* IsEmpty: Return true if the queue is empty else return false.

Applications of Queue:
* Task Scheduling application
* Email queues
* Buffer for devices like keyboards.

Different types of Queue:
* Simple queue
* Circular queue
* Priority queue
* Double Ended queue

Different ways to make a queue:
* java.util.List
* java.util.Array
* java.util.Queue
* Linked List

