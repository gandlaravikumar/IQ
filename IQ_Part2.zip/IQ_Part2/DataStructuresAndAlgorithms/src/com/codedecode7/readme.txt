Most asked LinkedList Coding Interview Question.

Question: Create a java program to find the middle node of the linked list in java in one pass?
Algorithm steps:
* Create a custom java class for implementation LinkedList.
* Create inner class for Nodes creation in the linked list. It should have data and pointer to next node.
* Then create head and tail nodes initially as null.
* Create methods to add nodes.
* Create method to print while linked list.
* Then a main method.