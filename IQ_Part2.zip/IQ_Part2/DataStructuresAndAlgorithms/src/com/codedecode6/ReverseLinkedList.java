package com.codedecode6;

public class ReverseLinkedList {

	Node head;
	static class Node {
		int data;
		Node next;
		
		public Node(int data) {
			this.data = data;
			this.next = null;
		}
	}
	void printNode() {
		Node current = head;
		while(current!=null) {
			System.out.print(current.data+" ---->");
			current = current.next;
		}
		System.out.println("null");
	}

	public static void main(String[] args) {
		ReverseLinkedList linkedList = new ReverseLinkedList();
		linkedList.head = new Node(1);
		Node second = new Node(2);
		Node third = new Node(3);
		Node fourth = new Node(4);
		Node fifth = new Node(5);
		
		// connection of Nodes
		linkedList.head.next = second;
		second.next = third;
		third.next = fourth;
		fourth.next = fifth;
		
		linkedList.printNode();
		linkedList.head = linkedList.reverseList(linkedList.head);
		linkedList.printNode();

	}
	
	public Node reverseList(Node node) {
		Node prev= head.next;
		Node next = head.next.next;
		head.next = null;
		
		while (prev !=null) {
			prev.next=head;
			head = prev;
			prev = next;
			if(next != null) {
				next = next.next;
			}
		}
		return head;
	}


}
