Linked List Implementation:
What is Linked List?
* A linked list is a linear data structure used for storing collections of data in the form of nodes.
* The elements in a linked list are linked using pointers.
* In simple words, a linked list consists of nodes where each node contains a data field and a reference(link) to the next node in the list.

Types of Linked list:
There are many types of linked list.
* Singly Linked List.
* Doubly Linked List.
* Circular Linked List.
* Doubly Circular Linked List.
* Header Linked List.

What is Singly Linked List?
* A singly linked list is a type of linked list that is unidirectional, that is, it can be traversed in only on direction from head to the last node(tail).
* Each element in a linked list is called a node. A single node contains data and a pointer to the next node which helps in maintaining the structure of the list.
* The first node is called the head, it points to the first node of the list and helps us access every other element in the list. The last node,also sometimes called the tail, points to NULL which helps us in determining when the list ends.

