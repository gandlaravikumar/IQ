mergesortimplementation:

 Time Complexity for this mergesortimplementation is O(n log(n))
 
 Same like QuickSort mergesort also follows technique called By Divide and Conquer.
 Means break down the problem into sub problems and appy algorithms and get the solution for each sub problem, then combine the sub solutions to get the final solution.
 
 
 break down the array into multiple arrays by using midIndex.
 midIndex=(leftIndex+rightIndex)/2
 even through if i get float value like 2.5 i will take 2 only.