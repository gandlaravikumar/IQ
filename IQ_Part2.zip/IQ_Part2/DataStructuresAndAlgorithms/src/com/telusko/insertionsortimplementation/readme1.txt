insertionsortimplementation:
Here we don't use swapping. Here we use shifting.

step1: In insertionsortimplementation assume that always first element is already sorted.
step2: start from 2nd element. compare the second element to previous elements.
step3: if the second elemtnt is less than the previous elemtn than shift it.
step4: repeat the same process through for loop.
step5: finally will get the sorted array.