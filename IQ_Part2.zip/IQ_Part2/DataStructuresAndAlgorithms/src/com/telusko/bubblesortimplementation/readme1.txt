There are different sorting options available:
1. Bubble sort
2. selection sort
3. insertion sort
4. merge sort
5. quick sort
6. counting sort
7. radix sort
8. heap sort
9. bucket sort
fist 5  sorts are famous :-)

Bubble sort:
it is not efficient, but simple to understand.
step1: compare the first 2 (0,1) elements. If the first element is greater than second element than swap it.
step2: compare the next 2 (1,2) elemtns, if the first elemtn is greater than second element than swap it.
step3: repeate the process untill all the elements are get sorted.
Time complexity for this bubble sort is O(n^2)
because we use two loops. 1st loop is for iterations. 2nd loop is for each iteration we have to compare the values.