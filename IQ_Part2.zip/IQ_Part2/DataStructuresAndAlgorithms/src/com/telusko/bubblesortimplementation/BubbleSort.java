package com.telusko.bubblesortimplementation;

public class BubbleSort {

	public static void main(String[] args) {
		int nums[] = {6,5,2,8,9,4};
		int temp=0;
		
		for(int i=0; i<nums.length; i++) {
			for(int j=0; j<nums.length-i-1; j++) { // no need to check the same sorted value again and again that's y (nums.length-i-1).
				if(nums[j] > nums[j+1])
				{
					temp = nums[j];
					nums[j] = nums[j+1];
					nums[j+1] = temp;
				}
			}
		}
		
		System.out.println("after sorting");
		for(int num :nums) {
			System.out.print(num +" ");
		}
	}

}
