steps to do selectionsort implementation:
step1: let us assume the first index value is minimun value.
step2: start comparing the minimun value with the second value.
step3: if the minimun value is the less than the second value, then check with 3rd value and soo on.
step4: if the minimun value is the greater than any other value, then make that other value is minimun value and compare with other remaing values.
step5: once we go through all the values, we know the minimun value. now swape the minimun value with first element.
step6: repeat the same process through for loop.
step7: finally will get the sorted array.

In selectionsort also we have outer loop and inner loop. But we are doing swaping only onces in every big iteration.
That' the advantage of selectionsort over bubblesort.
Time complexity for seclectionsort is O(n^2). But atleast it is better than the bubble sort in the terms of swapping.

please go through SelectionSort.java