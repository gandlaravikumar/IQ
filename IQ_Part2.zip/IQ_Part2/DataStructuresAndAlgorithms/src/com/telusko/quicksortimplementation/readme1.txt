quicksortimplementation:
In average case it will go to O(n log(n)) which is good.
in worse case it will go to O(n^2) also which is bad.

how to do Quick Sort?
Follow the below steps to achive quicksortimplementation.
1. By Divide and Conquer : Divide the problem into multiple problems, and find multiple solutions and combined it.
2. By Recursion : calling method by itself.
3. By Pivot: Central point of the problem.


Divide the array into 2 parts. but i need to find a point from where you need to divide, and that point is Pivot.
There are multiple ways to find pivot.
1. we can take middle value from array
2. last value from array.
3. first value from array.
 