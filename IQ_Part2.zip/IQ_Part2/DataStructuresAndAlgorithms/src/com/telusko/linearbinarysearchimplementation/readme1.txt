What is Data Structures?
Data structures is a way to organise and store the data effecticently (high perfomance and less memory to store).

What are Algorithms?
Alogrithms is nothing but set of instructions.
Eg: if i want to add 2 numbers.
Instruction1: take 2 values from user
instruction2: perform the operation
instruction3: give the value back to the user.
These 3 instructions are the set of insructions to add the 2 numbers. what i have mentiond the instructions are called "pseudo code".
one more Example: If i want to cook i need to follow some steps right. those steps are your algorithm.

Searching an element in a sorted Array:
int num[] = {5,6,8,9,11,13,17}.
we have multiple solutions to search sorted Array like linear sreach and binary search.

steps for Liner Search:
step1: take the length of the array
step2: iterate all the elemnts using for loop. if the array size is 1000, then it will take 1000 steps to iterate.
step3: inside forloop check the target value is eual to each index value or not.
step4: if the value is matches then return the i else reutn -1.

Pseudocode for Liner Search:
Procedure LinearSearch(A: list of items, target: item to search for)
	n = length(A)
	for i from 0 to n-1
		if A[i] equals target then
			return i // Return the index where the target element is found
		end if
	end for
	return -1 // Return -1 if the target element is not found in the list
end procedure

steps for binary Search:
step1: find the midindex value by startingIndex + endingIndex dividedby 2. i,e midIndex=startIndex/endIndex.
Note: in case midindex value comes to float values like 1.5 or 2.5 then take mid index is 1 or 2.
step2: check the targetvalue is equl to midindex value or not, if yes return it, else check it is greater than or lessthan.
	   if target is greater value than the mid index value, then the values befor the mid value is of no importance. change the mid index to start index.
	   if target is less vlue than the mid index value, then the values after the mid value is of no impotance. change the mid index to end index.
step3: repete the step1 and step2.

Pseudocode for binary Search:
procedure BinarySearch(A: list of sorted items, target: item to search for)
	left = 0
	right = length(A)-1
	
	while left <= right
		mid = (left + right)/2
		if A[mid] equals target then
			return mid // Return the index where the target element is found
		else if A[mid] < target then
			left = mid+1 // Continue searching in the right half
		else
			right = mid-1 // Continue searchingin the left half
		end if
	end while
	
	return -1 // Return -1 if the target element is not found in the list
end procedure

Time Complexity: Means it should take less time. Measure of how the running time of an algorithm increases with the size of the input data.
Space Complecity: Means It should take less memory.
	  
Big O Notation:
Big O Notation is used to understand your time complexity of your algoithm.
If someone says hey your algorith is not fast enough, then you have to first find the Big O Notation of it.
why it is Big O means, it is represent with Big O (order).
There are multiple Big O Notations are below:
1. O(1) : Constant Time
2. O(log n) : Logarithmic Time
3. O(n) : Linear Time
4. O(n log n) : Linearithmic Time
5. O(n^2) : Quadratic Time
6. O(2^n) : Exponential Time
7. O(n!) : Factorial Time

Scenario1 Fetching an element from an array:
If i want to fetch an element from an array with the help of index value it is very easy. Because our computer knows the address of the index value, so it will go directly there and get the value, it is very fast.
Even though the element in the array is in 1st place or last place Donesn't matter. Array size is small or big also doen't matter. Every tmie it is Constant.
just pass the index value and get the element. So, here to time taken to get the particualr element with the help of index value is Constant.
In this case time complexity for fetching an element from an array is always O(1) Constant Time. Here (1) is Constant.

Scenario2 Linear Search:
If i have array size is 10, in that target elemtn is in last position then it takes 10 steps. if the size increases the steps also will incress.
So, in this case time complexitu for searching an target element from an array is O(n) Linear Time. Here (n) is number of elements in the array.
the number if elements is incresses, then automatically time complexity will also increasess.

Scenario3 Binary Search:
In Binary search we are divinding the array using midindex and searching.
As the array size increases it will not directly increases the number of steps.
So, in this case time complexitu for searching an target element from an array is O(log n) Logarithmic Time.
Here (log n) is, by default we have base 2. So here we have (log2^n).
n is number of elements in the array. suppose we have 8 element in an array. log2^8 = 3 i,e.(2*2*2=8).
suppose we have 16 element in an array. log2^16 = 4 i,e.(2*2*2*2=16).
That means as your number of elements increases from 8 to 16 it will only increase 1 step from 3 to 4.

Please refere once the BigONotationGraphs images.
Please go through first LinearSearch.java later BinarySearch.java

