package com.codedecode4;

public class BubbleSort {

	public static void main(String[] args) {
		
		int arr[] = {80,32,45,12,30};
		bubbleSort(arr);
		
	}
	
	public static void bubbleSort(int nums[]) {
		
		for(int i=0; i<nums.length-1; i++) {
			boolean isSwapped = false;
			for(int j=0; j<nums.length-1-i; j++) { // no need to check the same sorted value again and again that's y (nums.length-1-i).
				if(nums[j] > nums[j+1])
				{
					int temp = nums[j];
					nums[j] = nums[j+1];
					nums[j+1] = temp;
					isSwapped = true;
				}
			}
			if(!isSwapped) {
				break;
			}
		}
		
		for(int i=0; i<nums.length;i++) {
			System.out.print(nums[i]+" ");
		}
	
	}
}
