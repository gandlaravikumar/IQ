Cocept and implementation using 2 for loop in java

What is Bubble Sort?
* It is the simplest sorting algorithm
* It repeatedly iterate over the array an compare the adjacent element
* Based on the comparison it swaps the element it they are in wrong order.
* At the end of every iteration largest element will get accumulated at the end of the array
* When the all iterations gets completed we will get sorted array.

Important Points:
* Worst and Average Complexity of bubble sort in this program is O(n^2). Because we are using 2 for loops.
* Best Complexity of bubble sort is O(n). when we pass already sorted order like OptimalApproachTechnique.java.
