package com.codedecode3;

import java.util.ArrayList;
import java.util.List;

//space complexity is O(n2)
public class Pascal_Triangle {

	public static void main(String[] args) {
		List<List<Integer>> result = pascalTriangle(5);
		System.out.println(result);

	}
	
	private static List<List<Integer>> pascalTriangle(int numRows) {
		List<List<Integer>> mainList = new ArrayList<List<Integer>>();
		List<Integer> currentList, prevList = null;
		
		for(int i=0; i< numRows; i++) {
			currentList = new ArrayList<Integer>();
			for(int j=0; j<=i; j++) {
				if(j==0 || j==i) {
					currentList.add(1);
				} else {
					currentList.add(prevList.get(j-1) + prevList.get(j));
				}
			}
			prevList = currentList;
			mainList.add(currentList);
		}
		return mainList;
	}
}
