What is Pascal Triangle?
Ans: Pascal triangle is a triangle which contains some numbers which has bean organized in form of some orders.

example:      1
			 1 1
			1 2 1
		   1 3 3 1
		  1 4 6 4 1
		  
here we observed 3 points:
1. first and last number is always 1.
2. no. of rows = no. of columns
3.the element at the jth position is sum of (j-1)+j position of present row.

Question: Given an integer numRows, return the first numRows of pascal's triangle.
In pascal's triangle, each number is the sum of the two numbers directly above it as shown.
Example 1:
Input: numRows = 5
output: [[1],[1,1],[1,2,1],[1,3,3,1],[1,4,6,4,1]]

Example 2:
Input: numRows =1
output: [[1]]

