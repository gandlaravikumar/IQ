package com.codedecode2;

public class BruteForceTechnique {
	//time complexity is O(n2)
	//Space complexity O(1)
	public static void main(String[] args) {
		int[] nums = {2,0,1,0,2,0,1,0,1,2};
		sortColours(nums);
	}
	
	static void sortColours(int[] a) {
		for (int i =0; i < a.length; i++) {
			for(int j = i+1; j<a.length; j++) {
				if(a[i]>=a[j]) {
					int temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		for(int i : a) {
			System.out.print(i + " ");
		}
	}
}
