In order to make this application work we need to change two things.
one is application.properties file. another one is Main application file. (TeluskoServiceRegistryApplication.java)

To enable the Eureka server, we have to put @EnableEurekaServer in main method file as a class level.
and also we need to do some configuration like, what is the name of the Eureka server. and all in application.properties file.

As a Eureka clients (Quiz service, Question service) all the services need to register themselves in Eureka server (service registry).
Did you think Eureka server also need to registry themself? offcourse not required right.
So, make eureka.client.register-with-eureka=false.
we need to give the eureka hostname. like eureka.instance.hostname=localhost.
And also we don't want to fetch the registry. So will make that false.

you can run the application and hit the url http://localhost:8761/

Run the telusko-question-service application then see in this url http://localhost:8761/ (service-registry).

Your question service will register in this service-registry. you can register multiple question service instances also.