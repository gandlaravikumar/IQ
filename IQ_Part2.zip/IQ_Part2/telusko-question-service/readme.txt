To run this application we need to create a new schema (questions_db).
In /TeluskoMicroServices1/src/main/resources folder there is a questions.csv.
create a Table and columns in DB with table name "question".
for column names please check the questions.csv file.
or RUN the application, it will create table and columns for us.
once table is created, just import the questions.csv data into the question table.



we can create multiple instances for each project. And every instance have different port number.

Do the configuration like below:

In eclipse ->right click on project
click 'Run As' or 'Debug As' -> Run Configurations or Debug Configurations
right click on your project name, which is under Spring Boot App -> New Configuration
Name : Give some name like whatever you want for 2nd instance. syntax(ProjectName-instance2). Example: telusko-question-service-instance2
project : select the project for which project you want to create 2nd instance.
mainType : select the main java file.
Click on Arguments Tab.
In VM arguments give the below line to run the 2nd instance, we need to give the port number like below.
-Dserver.port=8082
So that our 2nd instance will run on 8082 port number.
Like this we can create the multiple instances of same service and run in the different ports.
Example: like below we can create multiple instances for telusko-question-service project. We can run every instance at a same time with different ports.
http://localhost:8080/question/getScore
http://localhost:8081/question/getScore
http://localhost:8082/question/getScore


If one instance is shutdown, another instance will up and running. That is the main use for multiple instances.

