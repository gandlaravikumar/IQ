first go through linkedlistimplementation
next go through stackimplementation
next go through queueimplementation
next go through treedatastructureimplementation