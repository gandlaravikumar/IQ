package com.telusko.stackimplementation;

public class RaviDynamicSizeMain {

	public static void main(String[] args) {
		RaviDynamicSizeStack stack = new RaviDynamicSizeStack();
		System.out.println("============= pushing ===========");
		stack.push(15);
		stack.show();
		stack.push(8);
		stack.show();
		stack.push(10);
		stack.show();
		stack.push(11);
		stack.show();
		stack.push(12);
		stack.show();
		stack.push(13);
		stack.show();
	
		System.out.println("============= poping ===========");
		
		stack.pop();
		stack.show();
		stack.pop();
		stack.show();
		stack.pop();
		stack.show();
		stack.pop();
		stack.show();
	}
	
}
