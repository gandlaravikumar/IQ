package com.telusko.stackimplementation;

public class RaviStaticSizeMain {

	public static void main(String[] args) {
		RaviStaticSizeStack stack = new RaviStaticSizeStack();
		// this push method will store the data into array.
		stack.push(15);
		stack.push(8);
		stack.push(10);
		stack.push(11);
		stack.push(12);
		stack.push(13);
		
		//this pop() method removes an element from the top of the stack and returns it.
		int removedValue = stack.pop();
		System.out.println("removed value is "+removedValue);
		
		// This peak method fetch the top element of the stack without removing it.
		int peakValue = stack.peak();
		System.out.println("peak value is "+peakValue);
		
		// this will returnt the size of stack.
		int size = stack.size();
		System.out.println("size value is "+size);
		
		// this will tells us, the stack is empty or not
		boolean isEmpty = stack.isEmpty();
		System.out.println("Empty is "+isEmpty);
		
		stack.show();
	}
	
}
