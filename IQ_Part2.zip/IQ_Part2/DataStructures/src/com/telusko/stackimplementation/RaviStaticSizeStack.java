package com.telusko.stackimplementation;

// generally Stack is a class in java. it belongs to the package java.util;.
// But i don't want to use inbuilt Stack class. So, i created my own class clalled RaviStack.
public class RaviStaticSizeStack {

	// first i will create one static array to store the values.
	int[] stackArray = new int[5];
	int top =0;
	
	// this push method will store the data into array.
	public void push(int data) {
		if(top==5) {
			System.out.println("Stack is full");
		} else {
			stackArray[top] = data;
			top++;
		}
	}
	
	// this pop method removes an element from the top of the stack and returns the same element as the value of that function
	public int pop() {
		int removedValue = 0;
		if(isEmpty()) {
			System.out.println("Stak is Empty");
		} else {
		top--;
		 removedValue = stackArray[top];
		stackArray[top] = 0; // remove the top element from array by assign '0'.
		}
		return removedValue;
	}
	
	// This peak method fetch the top element of the stack without removing it.
		public int peak() {
			int peakValue = stackArray[top-1];
			return peakValue;
		}
		
		// this will retun the size of the array.
		public int size() {
			return top;
		}
		
		// this mwthod tells, the array is empty or not.
		public boolean isEmpty() {
			return top<=0;
		}
	
	public void show() {
		for(int num : stackArray) {
			System.out.print(num+" ");
		}
	}
	
}
