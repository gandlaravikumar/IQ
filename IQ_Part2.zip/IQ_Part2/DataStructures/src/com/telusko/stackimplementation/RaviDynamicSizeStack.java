package com.telusko.stackimplementation;

public class RaviDynamicSizeStack {
	
	int capacity = 2;
	// first i will create one array with initial capacity 2.
	int[] stackArray = new int[capacity];
	int top =0;
	
	// this push method will store the data into array.
	public void push(int data) {
		if(size()==capacity) {
			// if size()==capacity means stack is full, then we need to expand the capacity.
			expandSize();
		}
			stackArray[top] = data;
			top++;
	}
	
	public void expandSize() {
		int length = size();
		int[] newStackArray = new int[capacity*2];
		// System.arraycopy() method will take 5 params.
		// 1.from where you want to copy
		// 2.from which index you want to copy
		// 3.to where you want to copy
		// 4.to whuch index you want to copy
		// 5.how many elements you want to copy. (i want to copy all the elements, so get the size())
		// now all the stackArray copied to newStackArray.
		System.arraycopy(stackArray, 0, newStackArray, 0, length);
		// even if you expand newStackArray, everywhere you are working with stackArray.Means everywhere you are using stackArray reference.
		// so, we need to replace stackArray reference with newStackArray reference by stackArray = newStackArray.
		stackArray = newStackArray;
		capacity *= 2;
	}
	
	// this pop method removes an element from the top of the stack and returns the same element as the value of that function
	public int pop() {
		int removedValue = 0;
		if(isEmpty()) {
			System.out.println("Stak is Empty");
		} else {
		top--;
		 removedValue = stackArray[top];
		stackArray[top] = 0; // remove the top element from array by assign '0'.
		
		// when ever you pop(), it will remove the element from stackArray. So, you need to shrink the array capacity as well.
		// because you have a array with capacity 16, in that array i have only 4 elements. Remaining memory is wasting, so we need to shrink the array capacity.
		//example: if i have a array with capacity 16, in that array i have 8 Elements. at this point i don't want to shrink.
		//but the moment the elements goes lessthan 4, in this point i want to shrink to half of the capacity. means capacity will go from 16 to 8.
		//if the number of elements goes below 1/4, Then make the size of the array half.
		shrink();
		}
		return removedValue;
	}
	
	private void shrink() {
		int length = size();
		// capacity/2 it will give half, again /2 it will give 1/4
		if(length<=(capacity/2)/2) {
			capacity = capacity/2;
			// once capacity reduced to half of it's size, then create a new array with new capacity, then copy the elements to newStackArray.
			int[] newStackArray = new int[capacity];
			System.arraycopy(stackArray, 0, newStackArray, 0, length);
			stackArray = newStackArray;
		}
	}

		// this will retun the size of the array.
		public int size() {
			return top;
		}
		
		// this mwthod tells, the array is empty or not.
		public boolean isEmpty() {
			return top<=0;
		}
	
	public void show() {
		for(int num : stackArray) {
			System.out.print(num+" ");
		}
		System.out.println();
	}
	


}
