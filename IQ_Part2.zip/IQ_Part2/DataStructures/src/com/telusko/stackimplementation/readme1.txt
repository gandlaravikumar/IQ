what is stack?
Ans: Stack called as Abstract Data Type. Means we can only focus on features it provides, but not the implementation.
Stack folloes the LIFO. (Last Input First Output)

Features:
add -> push -> The method pushes (insert) an element onto the top of the stack.
delete -> pop -> The method removes an element from the top of the stack and returns the same element as the value of that function.
find -> peek -> This peak method fetch the top element of the stack without removing it.

suposse the stack size is 4. if you try to insert 5th element, then it will give 'stack overflow error'.
supose the stack is empty, if you try to delete some element using pop() method, then it will give 'stack underflow error'.

Note: First go through RaviStaticSizeMain.java later RaviDynamicSizeMain.java