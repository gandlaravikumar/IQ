package com.telusko.queueimplementation;

public class RaviCircularArrayQueue {

	
	// initially i will take a array with capacity 5
	int[] queueArray = new int[5];
	int size;
	int front;
	int rear;
	
	// this enQueue method will insert the value into queueArray.
	public void enQueue(int data) {
		//initially first and rear both are in 0th positiom.
		//whenever you insert the element to queueArray, then we can do rear++.
		//if the size is 5 then the modularOf 5 (%5).
		queueArray[rear] = data;
		rear = (rear+1)%5;
		size = size+1;
	}
	
	// this deQueue method will remove the value from queueArray.
	public int deQueue() {
		int removedData = queueArray[front];
		front = (front+1)%5;
		size = size-1;
		return removedData;
	}
	
	public void show() {
		for(int i=0; i<size; i++) {
			// queueArray[front+i] in this why front+i using means, when deQueue() happend firstvalue will remove and fromt will moved to next Value.
			// So, we should start the iteration from front.
			System.out.print(queueArray[(front+i)%5] +" ");
		}
		System.out.println();
		
		for(int n: queueArray) {
			System.out.print(n+" ");
		}
	}

	public int getSize() {
		return size;
	}
	
	public boolean isEmpty() {
		return getSize()==0;
	}
	
	public boolean isFull() {
		return getSize()==5;
	}
	

}
