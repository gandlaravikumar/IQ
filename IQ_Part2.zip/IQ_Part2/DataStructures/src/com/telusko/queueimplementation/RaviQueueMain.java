package com.telusko.queueimplementation;

public class RaviQueueMain {

	public static void main(String[] args) {
		
		callLinearArrayQueue();
		callCircularArrayQueue();
	}
	
	private static void callLinearArrayQueue() {
		RaviLinearArrayQueue queue = new RaviLinearArrayQueue();
		
		// max enQueue insert is 5, because size is 5 only.
		queue.enQueue(5);
		queue.enQueue(2);
		queue.enQueue(7);
		queue.enQueue(3);
		queue.enQueue(9);
		
		queue.deQueue();
		queue.deQueue();
		
		
		
		queue.show();
		
		//see here i enQueue 4 times and deQueue 2 times.
		// means 4 values inserted and 2 values removed. (removed means not exactly removing, we are just shifting the index postions). now totally 4 values are there in queueArray.
		// if i try to insert 2 more values, it will give arrayIndex exception. Because queueArray size is only 5. and it is linear array.
		//To solve this type of exceptions, we can go for circular array.
	}

	private static void callCircularArrayQueue() {
		// Circular array means, if the array size is 5 and it is full, if i try to insert 6th element, it will again go to 0th index.
		//indexes go like 0th,1st,2nd,3rd,4th, again 0th,1st,2nd,3rd,4th,again 0th,1st..like..
		//for this we need to do modular operations like below..
		//	5%5 = 0,
		//	1%5 = 1,
		//	2%5 = 2,
		//	3%5 = 3,
		//	4%5 = 4,
		//	5%5 = 0, // here again start from 0
		//	6%5 = 1, 
		//	7%5 = 2, and so on..need.
		RaviCircularArrayQueue queue = new RaviCircularArrayQueue();
		// n no of  enQueue insert. because it is circularArray
		queue.enQueue(5);
		queue.enQueue(2);
		queue.enQueue(7);
		queue.enQueue(3);
		queue.enQueue(9);
		queue.enQueue(1);
		
		queue.deQueue();
		queue.deQueue();
		
		
		
		queue.show();
		
	}

}
