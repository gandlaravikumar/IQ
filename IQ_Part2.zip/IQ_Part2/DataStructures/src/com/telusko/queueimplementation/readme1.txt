what is Queue?
Ans: Queue follows the concept of FIFO. (First In First Out).

enqueue -> insert the element.
dequeue -> remove the element.


basicially in Queue  we have 2 ends, one end value will enter, another end value will out.
front and rear.
firstvalue is called as front, lastvalue is called as rear.
initially first and rear both are in same positiom.
whenever you insert the element, then we can do rear++.
whenever you delete the element, then we can do front++.


Note: go through RaviQueueMain.java

