package com.telusko.linkedlistimplementation;

public class RaviLinkedList {

	// this firstNode will refer to the first Node (means it is a first node)
	RaviNode firstNode;
	
	//when ever user calls this insertAtLast method, the data will insert at last node.
	public void insertAtLast(int data) 
	{
		//when ever user calls this insertAtLast method, we need to create a node object first.
		//As we all know a Node contains data and address of next node.
		//data will get from user, Atlast we are adding this node, So address is always null only.
		RaviNode node = new RaviNode();
		node.data = data;
		node.address = null;
		
		// if there is no firstNode, (means, there is no atleast one node) then make that node as firstNode
		if(firstNode == null) 
		{
			firstNode = node;
		} 
		// if firstNode available. then we need to treverse from firstNode to last node until the address is null.
		// if address is null, then that is last node. AtLast we need to add the new node.
		else {
			// we are taking firstNode
			RaviNode n = firstNode;
			
			// from first node we are checking address is avaiable or not
			while (n.address!=null) 
			{
				// if address is not null then this is not last node
				// then go for the next node by saying n = n.address
				// initially n is firstNode
				n = n.address;
			}
			// if address is null, then this is last node. then assign your node to that null node.
			n.address = node;
		}
		
	}
	
	//when ever user calls this insertAtStart method, the data will insert at first node.
	public void insertAtStart(int data) 
	{
		//we need to create a node object first.
		RaviNode node = new RaviNode();
		//data will come from user.
		node.data = data;
		// before assigning our node to firstNode, will take the firstNode to the address.
		// Because, if already some nodes are there, now you want to insertAtStart. 
		// take that firstNode and assign to the current node. So, that current node becomes firstNode.
		node.address = firstNode;
		
		// assigning our node to firstNode
		firstNode = node;
	}
	
	//when ever user calls this insertAtMiddle method, the data will insert at middle node, based on index position.
	public void insertAtMiddle(int index, int data) {
		
		RaviNode node = new RaviNode();
		node.data = data;
		node.address = null;
		
		// if the index is 0, then simply call the insertAtStart. so that data will insert at statring inddex.
		if(index==0) {
			insertAtStart(data);
		}
		
		else {
		RaviNode n = firstNode;
		//we need to treverse from 0 to index value.
		for(int i=0; i<index-1; i++) {
			// go for the next node by saying n = n.address
			// initially n is firstNode
			n = n.address;
		}
		//assign previous node address to current node address
		node.address = n.address;
		// assign the current node to previous node address
		n.address = node;
		}
	}
	
	public void deleteAt(int index) {
		if(index==0) {
			// if you want to delete 0th index, then make the addess of firstNode  as firstNode
			firstNode = firstNode.address;
		} else {
			RaviNode n = firstNode;
			RaviNode tempNode = null;
			//we need to treverse from 0 to index value, to delete that
			for(int i=0; i<index-1; i++) {
				// go for the next node by saying n = n.address.
				// initially n is firstNode
				n = n.address;
			}
			// get the next node address and save into tempNode
			tempNode = n.address;
			//assign that tempNode address to the current node address
			n.address = tempNode.address;
			System.out.println("deleted "+tempNode.data);
			// after deleted, if you want to assign that deleted node to garbage collection, just simply make that node as null.
			tempNode = null; // now this will go for garbage.
		}
	}
	
	public void show() {

		// we need to treverse from firstNode
		RaviNode n = firstNode;

		while (n.address != null) {
			// if address is not null then print that data
			System.out.println(n.data);
			// after printing the data, then go for the next node.
			// initially n is firstNode
			n = n.address;
		}

		// As we all know, address is null for lastNode. So lastNode data will not print inside the while loop, because it's address is null.
		// so outside the while loop we are printing the (n.data) to print lastNode data.
		System.out.println(n.data);
	}
}
