package com.telusko.linkedlistimplementation;

public class RaviMain {
	
	public static void main(String[] args) {
		RaviLinkedList linkedList = new RaviLinkedList();
		
		// insertAtLast
		linkedList.insertAtLast(18);
		linkedList.insertAtLast(45);
		linkedList.insertAtLast(12);
		
		// insertAtStart
		linkedList.insertAtStart(25);
		
		// insertAtMiddle
		linkedList.insertAtMiddle(0, 55);
		
		// deleteAt
		linkedList.deleteAt(2);
		
		linkedList.show();
	}

}
