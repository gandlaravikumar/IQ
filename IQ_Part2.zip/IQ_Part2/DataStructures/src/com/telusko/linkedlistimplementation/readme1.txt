What is Data Structure?
Ans: Data Structure is all about how can we structured the data, so that we can store it and use it efficiently.
And there are certain algorithms we can implement on that, like concept of searching techniques, sorting techniques etc. 
we can apply all this techniques when the data is properly structured.

How we will store a data?
Ans: we have a concept called "Abstract Data Type" right. If we store in such a way, that it will be easier to work in future also.
	(Eg: List, Stack, Queue and Map called as Abstract Data Types)
	 Eg: A List or sequence is an abstract data type, that can be stored number of ordered values, where the same value may occur more than once.
	 we also have a concept of stack, which is abstract data type, that can be stored number of values, with two principal operations. push and pop.
	 push: which adds an element to the collection.
	 pop: which removes the most recently added element.
If we want to show or save everything in sequantial format, then we can go for List.
if we want to show the first app it shows you is the last which you have accessed. (which means last in first out LIFO), then we can go for Stack.

Why List, Stack, Queue and Map called as Abstract Data Types?
Ans: Because these concepts are just concepsts, and evry programing langugae having it;s different implementations.
eample in java we have linked list, array list.

List: If you want to have a collention of data with you, and with that collention you want to perfoem some operations lke update,remove,add data.
we can implemnt with the help of array list or linked list.

Stack: LIFO. example: stack of books or stack of plates.

Queue: FIFO. example: standing in queue for cinema tickets.

Map: Key and value. we can implemnt with the help of HashMap.

