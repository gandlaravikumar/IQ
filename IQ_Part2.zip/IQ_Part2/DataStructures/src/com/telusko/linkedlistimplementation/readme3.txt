once we define an size of an array, we can't expand or shrink it. but in linked list we can do it.

in linked list we can create a collection of elemnts and every elemnet will be linked with each other.

ex: i have 4 values 12,6,8,3

each value will store in each node.
each node contains value and address of the next node.

how we know this is first node and this is last node?
the first node will be refered as a head node.

we can add the value in between the nodes and link it to next node. Like this we can expand the size of linkied list.

it is slow while fetching value. But it is fast when mauplicating the date. (insertion, deletionn)

Note: please go through the /DataStructures/src/com/telusko/linkedlistimplementation/RaviMain.java to understand the linkedlist completely.