one variable can store only one data.
eg: int i= 5;
i can't store multiple data in one vatiable like below.
int i= 5,8,2,7;

as soon as i create int i= 5;
in a memory (RAM) every varible having a address like 101.
we got a variable i, with a value 5 and the address 101.
So, i can't store multiple data like int i= 5,8,2,7;

That's y arrays came into picture.

int i[] = {5,8,2,7};
insde RAM every byte having one address.
in this case every element takes 2 bytes. 
Then address for 5 is 101, 8 is 103, 2 is 105, 7 is 107.
ARray will always give you a contagious locations. i.e, 1st element is 101, then the next element is next to it (103). there is no gap in between.

Every element have an index number. Bases on index number will fetch the value.

Once we declare an arry we can't wxpand or shrink it.

Cons:
we can't expand the size of an array
we can't shrink the size of an aray

pros:
we can store multiple values.
it is fast, while fetching value. because based on index it will search


can we solve this expand size issue in arrays?
yes, there is a way, we can create 2nd array by giving the double size of 1st array, and copy the elements feom 1st array to 2nd array. this is called dynamic array.

even though you are adding one extra element, we need to double the size for safer size. then this is also one of the problem. we are wasting memory.
Then soluion for this is linked list.
in linked list we dont store all the data in one collection. means not in continous memory. in linked list we can store date anywere and just link it.
