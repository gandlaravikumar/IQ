package com.telusko.linkedlistimplementation;

public class RaviNode {

	// as we all know a Node contains, data and address of the next node
	
	// This is data
	int data;
	// This is address of the next node
	RaviNode address;
}
