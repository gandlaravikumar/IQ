package com.telusko.treedatastructureimplementation;

public class BinarySearchTreeMain {

	public static void main(String[] args) {
		RaviBinarySearchTree tree = new RaviBinarySearchTree();
		//when ever we call insert(), that means make sure we are inserting a node.
		// Debug mode lo run chesukoni nerchuko. :-)
		tree.insert(8);
		tree.insert(7);
		tree.insert(12);
		tree.insert(15);
		tree.insert(2);
		tree.insert(5);
		System.out.print("InOrder: ");
		tree.inOrder();
		System.out.println();
		
		System.out.print("preOrder: ");
		tree.preOrder();
		System.out.println();
		
		System.out.print("postOrder: ");
		tree.postOrder();
	}

}
