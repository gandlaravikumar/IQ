TreeDataStructure :
TreeDataStructure is similar to linked list.

for example : in linked list we have A, B, C nodes. A node contains the reference of B node. B node contains the reference of C node. one node contains only one reference.

But in Tree we normally create structer like a tree. in tree we have roots, branches, leafs in the same way,
for example: we have A,b,c,D,E,F,G nodes. A is the root node, and this A node instrad of one reference may have multiple references.
A node contains the reference of B,C,D. C node have the reference of E,F. D node have the reference of G.
A is root node. C,D are nodes. B,E,F,G are leafes node. (which node doesn't hav any reference that node is leaf nodes).


Binary Tree DataStructure:
Binary means 2 right.
means, each node contains 0 nodes or 1 node or 2 nodes. Max to max 2 nodes only, not more than 2.
for example: A node have the references of B,C node. B node have the reference of D,E nodes. C node have the reference of F,G nodes.

In Binary Tree also we have certian types:

Strict Binary Tree:
Strict Binary tree have every node will have two sub nodes or no children.
Example: we have A,B,C,D,E nodes. A node have the reference of B,C nodes. B node have the reference of D,E nodes. C node don't have any reference i,e no children nodes.

Full Binary TRee:
all the leaf nodes should be on the same level is called full binary tree.
for Example: we have A,B,C,D,E,F,G nodes.
A node have the reference of B,C nodes. B node have the reference of D,E nodes. C node have the reference of F,G nodes.
So, all the childrens are on the same level.

Complete binary tree.:  (Need to learn more about thisXXXXXXXXXXXXXXXXXX)
All the nodes are on level.
for Example: we have A,B,C,D,E nodes. A node have the reference of B,C nodes. B node have the reference of D,E nodes.
D,E nodes are on l level. C node are on l-1 level.
Either it should be on l level or l-1 level.


we have A,B,cdefghi,j,k nodes.
A->B,c. B->D,E. E->F,G. F->H,I. H->J,K
Here A is the Root Node. C,D,G,I,J,K are leafs nodes.
Here we need to calculate height and depth. These 2 terms are very important in coding part. (height and depth)
For E node we need to calculate height and depth.
We need count from E node to root node (A), then it is depth.
we need count from E node to leaf node then it is height.
Here depth is 2, height is 3.
Depth of the root node is always 0.
Height of the root node is 5. (from root node to  leaf node)
Height of the total tree is 5.


Binary Search Tree:
Binary search tree is a binary tree, only the differebce is the way you add the values.
in binary serach tree we should always make sure that the smaller elements is on the left hand side and bigger elements is on left hand side.
I,e. the elements on the left hand side of the root nnode will be smaller than the root node. and the elements on the right hand side of the root node will be bigger than the root node.
Example: we have number 8,7,12,15,2,5
always get the first element, make that as a root node.
first 8 is root node. next 7 is smaller than root node, so 7 goes on lefthand side of root node 8.
next 12 is bigger than root node, so 12 goes on righthand side of root node. For the root node, both the nodes are covered.
next 15 is bigger than root node 8, so it will go on right hand side, but we already have 12 there,  so 12 have an option to put 15 left or right.
Now, since 15 is greater than 12, so 15 will go on right hand side of 12.
Next elemen is 2, again we should start from root node 8. 2 is smaller than 8, then 2 will go to left hand side, we already have 7 there, 2 is smaller than 7, so 2 will go on left hand side of 7.
next we have 5, again we should start from root node 8, 5 is smaller than 8, then 5 will go to left side, but we have 7 there, 5 is lessthan 7, then 5 will got to left hand side of 7, but we already have 2 there, 5 is greater than 2, so finally 5 will come right side of the 2.
This is how, Binary search tree works, Lets see the implmentation.

