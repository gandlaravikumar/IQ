package com.telusko.treedatastructureimplementation;

class Node 
{
	int data;
	Node left;
	Node right;
	
public Node(int data) {
	this.data =data;
}

}
public class RaviBinarySearchTree {

	Node root;
	
	public void insert(int data) {
		root = insertRecursion(root, data);
	}
	
	public Node insertRecursion(Node root, int data) {
		if(root == null) {
			root = new Node(data);
			} else if(data < root.data) {
				root.left = insertRecursion(root.left, data);
			} else if(data > root.data) {
				root.right = insertRecursion(root.right, data);
			}
		return root;
	}
	// THere are 3 types of traverse are there to print the elements.
	//1. inorder
	//2. preorder
	//3. posr order
	
	// Inorder
	public void inOrder() {
		inOrderRecursion(root);

	}

	public void inOrderRecursion(Node root) {
		if (root != null) {
			// inOrder printinng order is (left,data,right) and we will get sorted values also.
			inOrderRecursion(root.left);
			System.out.print(root.data + " ");
			inOrderRecursion(root.right);
		}
	}
	
	// preorder
	public void preOrder() {
		preOrderRecursion(root);
		
	} 
	public void preOrderRecursion(Node root) {
		if(root != null) {
			// preOrder printinng order is (data,left,right). (will get 8,7,2,5,12,15)
			System.out.print(root.data +" ");
			preOrderRecursion(root.left);
			preOrderRecursion(root.right);
		}
	}
	
	// postOrder
		public void postOrder() {
			postOrderRecursion(root);
			
		} 
		public void postOrderRecursion(Node root) {
			if(root != null) {
				// in postOrder printinng order is (left,right,data). (will get 5,2,7,15,12,8)
				postOrderRecursion(root.left);
				postOrderRecursion(root.right);
				System.out.print(root.data +" ");
			}
		}
	
}
