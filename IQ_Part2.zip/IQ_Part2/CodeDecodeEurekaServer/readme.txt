When i run Eureka server, it is trying to execute and get registerd to another eureka server. Because Every Eureka server intrnaly behaves as eureka client
also. Because they might be chances that we have one eureka server which is going to give all the information about your microservice.
what if my eureka server gets down!!. Then you won't be able to identify your search any url's for any of these services.
So, that is y it is a good deal to always create always multiple copies of eureka services, and i can have one main eureka server,
having the url with the different eureka servers which is actually helping to you relocate any of the micro service.

If you have eureka server, and you want that your eureka server should not register with different eureka servers under same network.
So, as a eureka client i need to add one property in application.yml file by saying that please don't fetch any registry like below
'eureka:client:fetch-registry:false'.
and Don't registry with other Eureka servers like 'register-with-eureka: false'.

If I want to run the Eureka server, I need to enable the annotation in Main class. @EnableEurekaServer.


