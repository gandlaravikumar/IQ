package com.codedecode.microservices.eurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class CodeDecodeEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeDecodeEurekaServerApplication.class, args);
	}

}
