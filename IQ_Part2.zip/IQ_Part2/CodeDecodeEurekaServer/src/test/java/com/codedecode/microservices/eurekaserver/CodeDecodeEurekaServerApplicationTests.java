package com.codedecode.microservices.eurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeDecodeEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
