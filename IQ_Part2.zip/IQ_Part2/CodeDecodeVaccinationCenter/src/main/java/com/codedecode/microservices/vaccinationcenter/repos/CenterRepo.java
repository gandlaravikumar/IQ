package com.codedecode.microservices.vaccinationcenter.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codedecode.microservices.vaccinationcenter.entity.VaccinationCenter;

public interface CenterRepo extends JpaRepository<VaccinationCenter, Integer>{

}
