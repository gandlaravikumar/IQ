package com.codedecode.microservices.vaccinationcenter.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.codedecode.microservices.vaccinationcenter.entity.VaccinationCenter;
import com.codedecode.microservices.vaccinationcenter.model.Citizen;
import com.codedecode.microservices.vaccinationcenter.model.CombinedResponse;
import com.codedecode.microservices.vaccinationcenter.repos.CenterRepo;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;


@RestController
@RequestMapping("/vaccinationcenter")
public class VaccinationCenterController {

	@Autowired
	private CenterRepo centerRepo;
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@PostMapping("/add")
	public ResponseEntity<VaccinationCenter> addCitizen(@RequestBody VaccinationCenter vaccinationCenter) {
		VaccinationCenter vaccinationCenterAdded = centerRepo.save(vaccinationCenter);
		return new ResponseEntity<>(vaccinationCenterAdded, HttpStatus.OK);
	}

	// Add the @CircuitBreaker in method level. (In which method might give an error due to some issue, on top of that method we need to add @CircuitBreaker)
	// @CircuitBreaker(name = "allDataBasedonCenterId", fallbackMethod = "fallbackRandomActivity")
	// Here to identified the circuitBreaker we need to give some name. If any exception comes it will call the fallbackMethod method.
	
	@RequestMapping(path = "/id/{id}")
	@CircuitBreaker(name = "allDataBasedonCenterId", fallbackMethod = "fallbackRandomActivity")
	public ResponseEntity<CombinedResponse> getAllDataBasedonCenterId(@PathVariable Integer id) {
		CombinedResponse combinedResponse = new CombinedResponse();
		//1st get vaccination center detail
		VaccinationCenter center = centerRepo.findById(id).get();
		combinedResponse.setCenter(center);
		
		//then get all the citizens who are registered to vaccination center
		//List<Citizen> listOfCitizen =  restTemplate.getForObject("http://localhost:8085/citizen/id/"+id, List.class);
		// if i write the above line later i need to change the port number everytime if port number changes. so, i need to write the Eureka registered service application name. CODEDECODECITIZENSERVICE.
		// So that it will navigate to that registerd application.
		// for this i need to add the @LoadBalanced to the restTemplate in main application file.
		List<Citizen> listOfCitizen =  restTemplate.getForObject("http://CODEDECODECITIZENSERVICE/citizen/id/"+id, List.class);
		combinedResponse.setCitizens(listOfCitizen);
		
		return new ResponseEntity<CombinedResponse>(combinedResponse, HttpStatus.OK);
	}
	
	// This method calls from the @CircuitBreaker fallbackMethod
	public ResponseEntity<CombinedResponse> fallbackRandomActivity(@PathVariable Integer id, Throwable throwable) {
		CombinedResponse combinedResponse = new CombinedResponse();
		VaccinationCenter center = centerRepo.findById(id).get();
		combinedResponse.setCenter(center);
		return new ResponseEntity<CombinedResponse>(combinedResponse, HttpStatus.OK);
	}
}
