we can create multiple instances for one microservice right.
Means we can run one microservice application on 8080,8081,8082 etc.

example: question service is running on multiple instances.
now i will hit that question service from quiz service.
But which instance is going to be hit? 8080 or 8081 0r 8082 ?
That's y load balancing came into picture.

When a request goes from the client side to the quiz service.
When the quiz service wants to access the question service. But we have 3 instances.
based on the load on each instance we can decide where to send the data.
Means, based on which instance is free and available, that request will goes to that instance.
So, we can balance the load between the instances.

As we all know, we are using Feign service to connect the 2 micro services.
Feign service will take care about load balancing also, we no need to do anything.
But how to verify, the request is going to which instance?
For that we need to write one sytem.out.println and print the local.server.port by using Environment Interface.
It will print the port number.
Please check in com.telusko.question.controller.QuestionController.
Hit this url through postman continously and check in console logs. http://localhost:8090/quiz/get/1
some times it will use 8080, sometimes it will use 8082. Depends upon instance load.
