To send a request from one microservice to another microservice we need to use RestTemplate.
RestTemplate is a part of spring frame work. it has some methods which we can use to send a request.
But here we are not going to use RestTemplate, we are going to user QuizFeignInterface to make the calls.

Example: i have a 2 microservices. one is quiz and another one is question.
i want to hit the question service from quiz service.

from this url -> http://localhost:8099/quiz/get/5
to -> http://localhost:8080/question/generate

First i will call one controller and from that controller it will call the service.
From service i want to call another endpoint which is available in another microservice (another project)
So, I don't know that service is running on which machine and which port, to call.

So how do you solve this problem? That's were we have to introduce some new services.
1.'Feign client'
2.'Service discovery'

one is 'Feign client'. it is same as http web request.
But the different is it provides you something a declarative way of requesting the other service.
You don't have to hardcode the values. It will help you to declare what you want. and what are the api's you want to hit.
Means from one service to another service it will help you to connect.
We need to just tell to the feign, which service you want to connect to, SO that feign will connect it for you.
The way you can do that we need to create one Feign interface. This is the file helps you to connect form quiz service to question service.
In that interface we need to add the annotation @FeignClient with the question-service name which is available in question-service application.properties file.
like @FeignClient("telusko-question-service") 

next one is 'Service discovery'.
the quiz service is trying to search for question service. That means the question service needs to be discoverable.
But how to discover it? :-)
To do that we have to use some sever using which you can discover a particular API or particular microservice.
For that one of the famous one is Eureka Server. It is from netflex.

We need a Eureka server and all the microservies they have to register them selfs to Eureka server.
And then one microservice can search another microservice from the eureka server using eureka client.
So, Every microservice which want to search will also be having eureka client.

By doing this, we are solving the problem of IP address and port number also no need to mention that.
And with the help of Feign we can request directly to the service with the service name.

Note:Check the 'telusko-service-registry' project to registry the services. (question and quiz services)

To run the 2 microservices and check the connection between them.
step1:Run the 'telusko-service-registry'.
step2:run the question service
step3:run the quiz service.
step4:from post man hit the quiz service through this url http://localhost:8090/quiz/create and pass the QuizDto params in json. It will work.