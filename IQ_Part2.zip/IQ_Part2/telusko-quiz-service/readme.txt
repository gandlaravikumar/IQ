create a new schema in database (quiz_db).
Run this application then table will create automatically in your db.