package com.telusko.quiz.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.telusko.quiz.dao.QuizDao;
import com.telusko.quiz.feign.QuizFeignInterface;
import com.telusko.quiz.model.Answer;
import com.telusko.quiz.model.QuestionWrapper;
import com.telusko.quiz.model.Quiz;

@Service
public class QuizService {

	@Autowired
	QuizDao quizDao;
	
	@Autowired
	QuizFeignInterface feignInterface;

	public ResponseEntity<String> createQuiz(String category, int numQ, String title) {
		// Here from QuizService class (from one microservice) we are calling to QuestionService class (to another microservice) method using feignInterface
		List<Integer> questions = feignInterface.getQuestionsForQuiz(category, numQ).getBody();
		  
		  Quiz quiz = new Quiz();
		  quiz.setTitle(title); 
		  quiz.setQuestionsIds(questions); 
		  quizDao.save(quiz);
		 
		return new ResponseEntity<>("success",HttpStatus.CREATED);
	}

	public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(Integer id) {
		Quiz quiz = quizDao.findById(id).get();
		List<Integer> questionIds = quiz.getQuestionsIds();
		ResponseEntity<List<QuestionWrapper>> questions = feignInterface.getQuestionsFromId(questionIds);
		return questions;
	}

	public ResponseEntity<Integer> calculateResult(Integer id, List<Answer> answers) {
		ResponseEntity<Integer> score = feignInterface.getScore(answers);
		return score;
	}
}
