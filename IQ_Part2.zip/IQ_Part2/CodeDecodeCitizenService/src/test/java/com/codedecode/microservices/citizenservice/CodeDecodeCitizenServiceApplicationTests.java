package com.codedecode.microservices.citizenservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeDecodeCitizenServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
