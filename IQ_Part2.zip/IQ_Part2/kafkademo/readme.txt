Before run this kafkademo application we need to configure the kafka server.

Implementation of Kafka?
Ans: Steps to configure Kafka server:
Step 1: You need to install zookeeper and kafka in local. To do that install just kafka from below link. It will have zookeeper already installed.
https://kafka.apache.org/downloads.html
Step 2: You need a Spring boot project.
		Kafka in dependency with web.
		Controler to fetch msgs from client.
		Producer who push these msgs/events to topic.
		Consumer to listen to it.
		Application.properties to configure producer properties.
		After startup run in CMD at location example: C:\Software\Kafka_2.12-3.2.0:
		 - .\bin\windows\zookeeper-server-start-bat.\config\zookeeper.properties
		 - .\bin\windows\kafka-server-start.bat.\config\server.properties
		http://localhost:8080/rest/api/producerMsg?message="HelloCodeersss"


Before run this kafkademo application, we need to run 2 cmds.

Downloaded the kafka_2.12-3.2.0 in C:\Classic_Projects\kafka_2.12-3.2.0

go to this location and run the 2 cmds.
one is to run zoo keeper. 
C:\Classic_Projects\kafka_2.12-3.2.0>.\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties

second one is to run kafka.
open another cmd promt and run the below cmd to run the kafka.
C:\Classic_Projects\kafka_2.12-3.2.0>.\bin\windows\kafka-server-start.bat .\config\server.properties

now successfully we started the zookeeper and kafka server.
now lets try and hit the controller.
http://localhost:8080/rest/api/producerMsg?message="helloravi"


Understanding the project:
* It is a must to set up ZooKeeper for kafka. 
	ZooKeeper performs many tasks for Kafka but in short, we can say that ZooKeeper manages the Kafka cluster state.
* By default, the Kafka server is started on 9092.
	Kafka uses ZooKeeper, and hence a ZooKeeper server is also started on port 2181.
* What is group Id: Consumer groups give Kafka the flexibility to have the advantages of both message queuing and publish-subscribe models.
* Kafka consumers belonging to the same consumer group share a group id. 
	The consumers in a group then divides the topic partitions as fairly amongst themselves as possible by establishing that each partition is only consumed by a single consumer from the group.
* If all consumers are from the same group, the Kafka model functions as a traditional message queue would.
	All the records and processing is then load balanced Each message would be consumed by one consumer of the group only.
	Each partition is connected to at most one consumer from a group.
* KafkaTemplate helps us to send messages to their respective topic.
* All we need to do is to call the sendMessage() method with the message and the topic name as parameters.
* When multiple consumer groups exist, the flow of the data consumption model aligns with the traditional publish-subscribe model.
	The message are broadcast to all consumer groups.
* In order to prepare the message for transmission from the producer to the broker, we use serializers.
	The key, serializer and value. serializer instruct how to turn the key and value objects the user provides with their producerRecord into bytes.
	You can use the included ByteArraySerializer or StringSerializer for simple string or byte types.
	
How to change Zookeepers default port of 2181?
* You can change this port by changing clientport. Location is
	C:\Classic_Projects\kafka_2.12-3.2.0\config\zookeeper.properties
* For Kafka to connect to New Zookepper Port, change the port in file:
	C:\Classic_Projects\kafka_2.12-3.2.0\config\server.properties
	
Terminologies and Architecture of Kafka:
High level Terminologies in Kafka:
* Topic:  A bucket of messages (or events in case of kafka) where services may place or read messages from.
	Messages are organized and durably stored in topics. A topic is similar to a folder, and these messages are the files in that folder.
	Topics are multi-producer and multi-subscriber, meaning that we can have zero, one or many of them both.
	Messages can be read as many times as needed, unlike traditional messaging systems, msgs/events in kafka are not deleted after consumption.
	Instead, you can define for how long kafka should retain those events/msgs.
* Kafka Cluster: A kafka cluster is a system that comprises of different brokers, topics, and their respective partitions.
* Producers: A producer sends or writes data/messages to the topic within the cluster.
	In order to store a huge amount of data, different producers within an application send data to the kafka cluster.
* Consumers: A  consumer is the one that reads or consumes messages from the Kafka cluster.
	There can be several consumers consuming different types of data from the cluster.
	The beauty of kafka is that each consumer knows from where it needs to consume the data.
* Brokers: A kafka server is known as a broker. A broker is a bridge between producers and consumers.
	If a producer wishes to write data to the cluster, it is sent to the kafka server.
	All brokers lie within a kafka cluster itself. Also, there can be multiple brokers.
Partitions: The data or message is divided into small subparts, known as partitions. Each partition carries data within it having an offset value.
	The data is always written in a sequential manner. We can have an infinite number of partitions with infinite offset values.
	However, it is not guaranteed that to which partition the message will be written.
ZooKeeper:
	* A ZooKeeper is used to store information about the Kafka cluster and details of the consumer clients. It manages brokers by maintaining a list of them.
	* Also, a ZooKeeper is responsible for choosing a leader for the partitions. If any changes like a broker die, new topics, etc., occurs, the ZooKeeper sends notifications to Apache Kafka.
	* A ZooKeeper is designed to operate with an odd number of Kafka Servers.
	* ZooKeeper has a leader server that handles all the writes, and rest of the servers are the followers who handle all the reads.
	* However, a user does not directly interact with the ZooKeeper, but via brokers.
	* No Kafka server can run without a zookeeper server. It is mandatory to run the zookeeper server.

Architecture of Kafka:
	* Kafka has a sized component called a cluster.
	* inside a cluster, we've got several servers, also known as brokers (usually at least three brokers to provide enough redundancy).
	* When a message gets sent to a broker, it gets sent to a particular topic. Topics allow us to categorize data. The data can eventually get broken into several partitions.
	* By splitting the topic into multiple partitions, we're facilitating scalability, as each partition can be read by a separate consumer.
	* Each broker is responsible for receiving messages from producers and committing those messages to disk. The broker is also responsible for answering consumer's fetch requests and serving them.
	* Broker -> Basically, to maintain load balance Kafka cluster typically consists of multiple brokers.
		However, these are stateless, hence for maintaining the cluster state they use ZooKeeper.
		Although, one kafka broker instance can handle hundreds of thousands of reads and write per second.
	* Whereas, without performance impact, each broker can handle TB of messages. In addition, make sure ZooKeeper performs Kafka broker leader election.
	* Kafka ZooKeeper -> For the purpose of managing and coordinating, Kafka broker uses Zookeeper. Also, uses it to notify producer and consumer about the presence of any new broker in the Kafka system or failure of the broker in the Kafka system.
		As soon as ZooKeeper send the notification regarding presence or failure of the broker then producer and consumer, take the decision and starts coordinating their task with some other broker.
	* Kafka Producers -> Further, producers in kafka push data to brokers. Also, all the producers search it and automatically sends a message to that new broker, exactly when the new broker starts.
		However, keep in mind that the Kafka producer sends messages as fast as the broker can handle, it doesn't wait for acknowledgments from the broker.
	* Kafka Consumers -> Basically, by using partition offset the kafka consumer maintains that how many messages have been consumed because Kafka brokers are stateless.
		Moreover, you can assure that the consumer has consumed all prior messages once the consumer acknowledges a particular message offset.
		Also, in order to have a buffer of bytes ready to consume, the consumer issues an asynchronous pull request to the broker.
		Then simply by supplying an offset value, consumers can rewind or skip to any point in a partition. In addition, zookeeper notifies Consumer offset value.
	* Kafka Topics -> The topic is a logical channel to which producers publish message and from which the sonsumers receive messages.
		A topic defines the stream of a particular type/classification of data, in kafka.
		Moreover, here messages are structured or organized. A particular type of messages is published on a particular topic.
		Basically, as first, a producer writes its messages to the topics. Then consumers read those messages from topics.
		In a Kafka cluster, a topic is identified by its name and must be unique.
		There can be any number of topics, there is no limitation.
		We can not change or update data, as soon as it gets published.

	