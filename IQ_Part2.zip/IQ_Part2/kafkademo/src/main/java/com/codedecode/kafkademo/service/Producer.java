package com.codedecode.kafkademo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Producer {

	@Autowired
	KafkaTemplate<String, String> kafkaTemplete;
	
	public void sendMsgToTopic(String message) {
		kafkaTemplete.send("codeDecode_Topic", message);
	}
	// Note: when ever we send a message from producer through a kafkaTemplete to a topic it has to be Serialized.
	//That means the string message has to converted into type of byte.
	//Now how to serilize the string message (key and value) to send to the particular topic is through serilization and deserilization.
	//so we need to denoting both key and value serilization should be stringserilizer in application.yml file.
	//Because i want to convert string to type of bytes. so that it can be sent from topic to consumer at the end.
	//These are nothing but type of serilizations we are using for  convert the message to bytes.
}
