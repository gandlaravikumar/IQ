SAGA Design pattern Microservices Interview Questions:

Why SAGA?
* We know that Design pattern gives solutions to common problems faced by us "THE DEVELOPERS".
	So what problem is solved by this SAGA design pattern?
* The problem started as soon as we moved from Monolithic application to Microservice Architecture.
* We will take example of Swiggy, Zomato.
* you   # Choose your dishes,
		# Add them to Cart and checkout
		# Make payment
		# Order gets Delivered
		# Our order is marked as completed after delivery is successful.
* In monolithic it's not a problem as we have I database, multiple Tables like Orders, Payments, Delivery Etc.
	Now in 1 single Atomic transaction we can do all these steps and if payment fails, everything gets rolled back.
* Now we moved to microservices architecture and Segregated the whole zomato or swiggy application to.
		# Order service
		# Payment service
		# Delivery service
* Now your order service accepts your order, Payment service validates the payment done and Delivery service is responsible for delivery of your order to your home.
	When delivered successfully the orders is marked completed in the application. This is happy case.
* Ever thought about the worst case Delivery is failed as no delivery partner was available.
	Your payment was done, money got deducted and now No food. At least we need to get the money back and Order must be marked as cancelled.
* For this to happen we need a Transaction rollback. Transaction did get rolled back but only the scope of transaction was in Delivery service.
	The boundary for this transaction ended in Delivery service.
* Now what about the order service and payment service?? Neither your money is returned with this rollback nor your order status changed from waiting to failed/cancelled. Such a bad user experience right?
* This is the classic example where your application completely failed to manage distributed transaction (A transaction what spans across multiple Microservices).
	Now this is a problem and to handle such distributed transactions issues SAGA Design pattern came into picture.

What is SAGA?
* A saga is that sequence of local transactions.
* Each saga has 2 jobs to do.
	1. Update the current Microservice and make required changes.
	2. publish events to trigger the next transaction for the next microservices.

How SAGA DP handles failure of any individual SAGA?
* The saga pattern provides transaction management with using a sequence of local transactions of microservices.
	Every microservices has its own database and it can able to manage local transaction in atomic way with strict consistency.
* So saga pattern grouping these local transactions and sequentially invoking one by one.
	Each local transaction updates the database and publishes an event to trigger the next local transaction.
* If one of the step is failed, then saga patterns trigger to rollback transactions that are a set of compensating transactions that rollback the changes on previous microservices and restore data consistency.

Ways to Implement SAGA?
There are two type of saga implementation ways.
	# Choreography
	# Orchestration

What is Choreography saga pattern?
* Choreography is a way to coordinate sagas where participants exchange events without a centralized point of control.
* With Choreography, each microservices run its own local transaction and publishes events to message broker system and that trigger local transactions in other microservices.
Example: client will create an order -> message broker will create an event, create order event.
Once order is successfully created, the event code sent back to message broker like order created successfully, now make the payment.
Now message broker sent an event code to payment service to do the payment. Once payment is success, then event code is sent back to message broker like payment is success.
Now message broker sent an event code to delivery service to do the delivery. If once delivery is success, then event code sent back to message broker like delivery is success.
Now message broker sent an event code to Client successfully delivered.

Advantages of Choreography saga pattern?
* Good for simple workflows that require few participants and don't need a coordination logic.
* Doesn't require additional service implementation and maintenance.
* Doesn't introduce a single point of failure, since the responsibilities are distributed across the sega participants.

Disadvantages of Choreography saga pattern?
* workflow can become confusing when adding new steps, as it's difficult to track which saga participants listen to which commands.
* There's a risk of cyclic dependency between saga participants because they have to consume each other's commands.
* Integration testing is difficult because all services must be running to simulate a transaction.

What is Orchestration saga pattern?
* Orchestration is a way to coordinate sagas where a centralized controller tells the saga participants what local transactions to execute.
* The saga Orchestrator handles all the transactions and tells the participants which operation to perform based on events.
* The Orchestrator
	# executes saga requests,
	# stores and interprets the states of each task,
	# Handles failure recovery with compensating transactions.
That mesans, Orchestration is going to give the command to different services, but Orchestration is not listen to any message present in the message broker.

Advantages of Orchestration saga pattern?
* Good for complex workflows involving many participants or new participants added over time.
* Suitable when there is control over every participant in the process, and control over the flow of activities.
* Doesn't introduce cyclic dependencies, because the Orchestrator unilaterally depends on the saga participants.
* Saga participants don't need to know about commands for other participants. Clear separation of concerns simplifies business logic.

Disadvantages of Orchestration saga pattern?
* Additional design complexity requires an implementation of a coordination logic.
* There's an additional point of failure, because the Orchestrator manages the complete workflow.