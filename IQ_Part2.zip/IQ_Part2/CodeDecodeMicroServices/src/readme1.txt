What are Monolith Application?
Ans: In Monolith Architecture the application is build as a single unit.
	 Such applications contains UI, server-side, and database. Means large code base.
	 
Monolith Application Architecture:
Ans: Clients -> Presentation Layer -> Controller Layer -> Business Layer -> Repository Layer -> DB.

Disadvantages of Monolith application?
Ans: The code base get larger in size and hence it's very difficult to manage.
It's very difficult to introduce new technology as it affects the whole application.
A single bug in any module can bring down the whole application.
It is very difficult to scale a module wise. we need to scale the whole application.
Continuous deployment is extremely difficult why because in order to update one component, we have to redeploy the entire application.

What are Microservices?
Ans: Microservices is an one of the Architecture.
	While Monolith application works a single component, a microservice Architecture breaks it down to independent standalone small applications.
	That each application acts a one particular requirement.
	Eg: one application acts a authentication. one application acts as load the products. like that.

In one word we can say as,
In microservice architecture, the entire application is split into independent deployable module which communicate with each other through API's (RESTful web services).

Microservices Application Architecture?
Ans: UI -> Multiple services (like services1, services2 etc..) -> Different DB's (like mysql DB, Mongo DB, Oracle DB etc ..)

Advantages of Microservices?
Ans: All the services are independent of each other. Therefore testing and deployment is easy as compare to Monolith application.
If there is a bug in one microservice it has an impact only on a particular service and does not affect the entire application.
With microservice architecture, it's easy to build complex applications.
It will give flexibility to choose technologies and framework for each microservices independently.

How to start with microservices?
Ans:  1. If you have a monolith application, Identify all possible standalone functionalities.
	  2. Once you have identify them, you need to create standalone projects, we are taking spring boot to create these microservices.
	  3. you need them to interact with each other through some ways, it can be Rest Api or Messaging. we are going to use RESTful API's architecture to interact with each service.
	  4. Next i need load balancer, eureka for service discovery (useful during load balancing and cloud deployments), API gateways and many more stuff.

Example:
i can create first Vaccination service center, this is basically a microservice which is used to handle all the your calls for vaccination center. adding, updating,removing vaccination centers.
one more micro service i can create is user service center, where handle all the your calls for user operations.
there is one more service called Eureka discovey service. now i need to register the vaciination center and user service center to Eureka service, to produce dynamic urls'.
I need to do load balancing because, one single server not capable enough to handle all the requests. So i can going to create the replica of each service on different servers.
so that even one server is down another servef is capable to handle your request.
To see what all users are today going to come at vaccination center, i need to hit a API to fetch the particular vaccination center and list of users.
in that case i need http:localhost//8081/vaccinationService.
Suppose 8081 port is not workining. my request will fail. i need to load balance to different port like 8082 or 8083.
I n that case eaither it is load balanced or when it is deployed in cloud you have different ip addresses when your instances restarted.
i can't configure each of those url's into a vachinnation service center. In that particular case Eureaka comes in to picture.
what Eureka do is?
you just give me the name of service that you want to hit, and eureka will give the url which is load balanced.
in one word we can say Eureka handles the load balancing situations and it handles dynamic urls.
when i deploy the service in cloud, it will give dynamci urls'.
in that case, there is no localhost and port numbers in url. it's just like https://vaccinationService.

What eureka service will do?
Ans: Eureka service is used to provide the dynamic url's.
Means, multiple modules will run on multiple servers with different port numbers.
I can't configure all the port numbers to trigger the service request.
So, it's enough to just trigger the service name to Eureka service. This will construct the URL and trigger to that particular service.

Note: When i create a "new spring starter project" it is taking java version 17. So install JDK17 in your machine.
Because https://start.spring.io does not offer Spring 2.7.x versions of Spring anymore. Since Spring Boot 3.x requires JDK 17 as a minimum,
Note: As per CodeDecode videos i installed DBeaver plugin in eclipse for mysql connection purpose:
Note: First go for CodeDecodeEurekaServer, CodeDecodeCitizenService, CodeDecodeVaccinationCenter
	  