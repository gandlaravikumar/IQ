Why API Gateway?
1) we had eureka server, @CircuitBreaker implemented in previous videos, Is that not enough? why do we need API Gateway?
2) The reasons are many:
	a) When we comeup with our microservices, clients needs to know exactly which microservices they need. Client/FE develop
	Don't need such information that backend developer is developing which microservice for which functionality.
	To over come this we have API Gateway to create an abstraction layer between FE and Backend developers. Thus FE developers
	need not depend on Backend people anymore. This is as good as implementing Abstraction principle in java OOPS.
	b) It become harder to change microservice without affecting the client. In reality, the client doesn't need
	to know microservice and its implementation behind.
In one word, if user details in 8082 port, vaccination details in 8081 port. But user/client doen't know about ports, whihc port having which informatoin.
In between client and services API gate way is available in 8083 port. So client always hit API gate way 8083 port.
From API gateway it will hit the required service and get back the response. Client don't required what is happing in backend , how response is coming back and all.
just he will hit the API Gateway. That's it. API Gateway it's just like a abstraction layer between front end developer and back end developer.
If i change the backend service also, no need to change the API gateway, Hence it is loose coupling.
Every request should be pass through API gateway. Hence API gateway should be capable enough to Authentication,Authorization, Logging, Monitoring for all requests
and then navigate to particular micro service so, this is code redundancy also.
3) API Gateway also handles multiple versions of same microservice having compacibility with different clients.
Means, example there is 2 types of clients. one is web application clients and another one is mobile application clients.
If i done some changes in one service which is not compatable with mobile application. Instead of removing mobile clients support, i will create different versions like v1 and v2.
SO, web clients will use updated version V2. mobile clients will keepon using the old version v1.
4) To address these issues, the architecture now contains another layer between the client and the microservices.
This is API Gateway. API Gateway acts like a proxy that routes the request to the appropriate microservices and returns a response to the client.
Microservices can also interact with each other through this Gateway.

How API Gateway works?
* It works on routing principle.
Means, The API gateway takes all the API calls, from the clients and routes them to appropriate microservices with request routing.

Different Implementations of API Gateways Available?
* There are a number of API gateways available and one can use any of these based on the needs.
	a) Netflix API Gateway (Zuul)
	b) Amazon API Gateway
	c) Mulesoft
	d) Kong API Gateway
	e) Azure API Gateway
In real world you will see most of the projects using Netflix API Gateway (Zuul), But we will be implementing API Gateway using spring cloud Gateway. Why??

Why Netflix Era came to an end and we all have to move on to Spring Cloud technologies?
* Whenever if speak about microservice, the first thing came to our mind was Netflix OSS support tools like Eureka, Zuul, Hystrix etc. But recently we see that many
of these are now in maintenance mode. This means that there won't be any new features added to these modules, and the spring cloud team will perform only some bug fixes and fix security
issues. The maintenance mode does not include the Eureka module, which is still supported.
* Hystrix has been alreadysuperseded by the new solution for telemetry called Atlas.
* The successor of spring cloud Netflix Zuul is spring cloud gateway.

Why Not Zuul? Why Spring Cloud Gateway?
* Zuul is a blocking API. A blocking gateway api makes use of as many use of as many threads as the number of incoming requests.
So this approach is more resource intensive. If no threads are avilable to process incoming request then the request has to wait in queue.
Means, in API Gateway there are 4 threads. t1,t2,t3,t4. if 5 requests r1,r2,r3,r4,r5 came to API Gateway. r5 will wait in queue until any thred gets free. So this is blocking API.
* Spring cloud Gateway is a non blocking API. When using non blocking API, a thread is always available to process the incoming request. These request are then processed asynchronously in the background and once completed the response is returned. So, no incoming request never gets blocked when using spring cloud gateway.

How it works - Spring Cloud Gateway?
* Clients make requests to spring cloud gateway. If the gateway handler mapping determines that a request matches a route it is sent to the gateway web handler.
This handlerruns the request through a filter chain that is specific to the request. The reason the filters are divided by the dotted line is that filter can run logic both before and after the proxy request is sent. All "pre" filter logic is executed. Then the proxy request is made. After the proxy request is made, the "post" filter logic is run.
* URL's defined in routes without a port get default port values of 80 and 443 for the http and https urls respectively.

Note: Now go through CodeDecodeAPI_Gateway.