Top Microservices Scenario based Interview Questions for 5+ year Experienced.

How to design and implement a Microservices?
Ans: 	* Start with a Monolith.
		* Organize your teams the right way.
		* Split the Monolith to build a microservices architecture.
		* Build your microservices architecture for failure.
		* Emphasize monitoring to ease microservices testing.
		* Use CI/CD to make deployment process easy.

Can you please provide examples of situations where using microservices over monolithic systems and vice versa is a better choice?
Ans: Scenarious where monolithic architecture is preferred over microservice Architecture.
		* Limited Complexity
		* Development Speed
		* Resource Constraints
		* Performance
		* Team Size
		* Learning Curve
		
	Scenarious where monolithic architecture is preferred over monolithic Architecture.
		* Scalability
		* Flexibility
		* Development Velocity
		* Team Structure
		* Complexity
		* Maintenance
		
How do you make sure a Microservices-based application can handle more users as it becomes more popular?
Ans:	* load Balancing
		* Horizontal Scaling
		* Auto Scaling
		* Caching
		* Database Scaling
		* Asynchronous Processing

How to handle data consistency in a microservices architecture?
Ans:	* Synchronous Communication.
		* Asynchronous Communication.
		* CQRS (Command Query Responsibility Segregation)
		* Event Sourcing
		* Distributed Transaction
		* Saga Pattern
		* Monitoring and Logging
		* Conflict Resolution

What is the difference between 2 Phase Commit and SAGA Pattern? Which one will you prefer and why?
Ans: 
2 Phase Commit:
		* Strong Consistency
		* Synchronous
		* Blocking
		* Complexity
		* Performance Overhead
		* Strong Data Consistency	
SAGA Pattern:
		* Eventual Consistency
		* Asynchronous
		* Non Blocking
		* Simplicity
		* Better Performance
		* Temporarily Inconsistency