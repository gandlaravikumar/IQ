Fault Tolerance in MicroServices Hystrix (Circuit Breaker):

What is fault Tolerance?
Ans: Fault tolerance is the property that enables a system to continue operating properly in the event of the failure of some of its components.

Example: we have vaccination service and citizen service.
If i hit the vaccinationcenter url with id, i need to get the vaccination ceneter details along with the citizens who are registered in that vacination service center.
example: hit this url and check. It will give vaccinationcenter details along with registered citizens-> http://localhost:8086/vaccinationcenter/id/1
If i hit this URL it will go to VaccinationCenterController.java in getAllDataBasedonCenterId method.

In this example due to some issue, citizen service is in Down. Now only Eureka service and Vaccination service is UP.
If i hit this url -> http://localhost:8086/vaccinationcenter/id/1
It should give Vaccination center details along with the citizens who are registered in that vacination service center.
But now Citizen service is down. SO, it will give Internal server error. This is fault.
This internal server error user doesn't know any thing, what is happening.
Even if you don't have citizen service data, atleast you should give vaccination service center data.
So, we need to tolerate this fault using Hystrix components.

below are the steps to achive the fault tolerate:
1. first we need to add hystrix dependency in pom.xml
		<dependency>
			<groupId>org.springframework.cloud</groupId>
			<artifactId>spring-cloud-starter-netflix-hystrix</artifactId>
			<version>2.2.8.RELEASE</version>
		</dependency>
2. Add the @CircuitBreaker in method level. (In which method might give an error due to some issue, on top of that method we need to add @CircuitBreaker)
@CircuitBreaker(name = "allDataBasedonCenterId", fallbackMethod = "fallbackRandomActivity")
Here to identified the circuitBreaker we need to give some name. If any exception comes it will call the fallbackMethod method.

Question: How Circuit Breaker Design Pattern works?
Ans: Idea behind circuit breaker is:
a) Wrap your rest api call in circuit breaker object which monitors for failure.
b) Once the failures reach a certain threshold, the circuit breaker trips, and all further calls to the circuit breaker return with an error.
c) Here comes our taks: If it fails and circuit is open, configure a fallback method which will be executed as soon as circuit breaks or open.
d) In ths way, your vaccination center service Test controller is wrapped with a proxy class and monitor its call.
   Everything is done internally handles everything for you.	

Question: @HystrixCommand Elements. (Note: this @HystrixCommand annotation i didn't used, Search google for need more info)
Ans: 1) fallbackMethod : specifies a method to process fallback logic.
2) threadpoolkey: the thread-pool key is used to represent a HystrixThreadPool for monitoring, metrics publishing, caching and other such uses.
3) threadpoolproperties: specifies thread pool properties.
4) groupkey: the command group key is used for grouping together commands such as for reporting, alerting, dashboards or team/library ownership.
5) commandProperties: specifies command properties like.
	a) circuitBreaker.requestVolumeThreshold: number of request reties before which circuit breaks.
	b) circuitBreaker.errorThresholdPrecentage eg 60%: If60% request fails out of total requests made then open the circuit.
	c) timeout s: its like wait for milliseconds and if no response, break circuit.

