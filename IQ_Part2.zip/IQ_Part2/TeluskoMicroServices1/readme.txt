This application (TeluskoMicroServices1) is a simple Monolithic quiz application.
In /TeluskoMicroServices1/src/main/resources folder there is a questions.csv.
Create a schema and give that schema in application.properties file.
next create a Table and columns in DB with table name "question".
for column names please check the questions.csv file.

or If you run the application it will create a table and columns in our schema DB.
In that question table run the scripts by following questions.csv file. or just import that csv file.
It will insert the csv file data into your question table.

Then run this application and use it.


After this Application, we can convert this Monolithic application to microservice application.
So that, we can create each service separately like below.

telusko-question-service
telusko-quiz-service .

Note: In the next projects we are going to convert this Monolithic application to MicroServices.
Means we are going to create question service and quiz service seperatly.
Next Project name is 'telusko-question-service'.
In that application, we are creating the question service only. Means there is no quiz service. 
Again will create a new project sepeartly with name 'telusko-quiz-service' for quiz service.
Then will connect to each other. telusko-question-service and telusko-quiz-service.


Note: If you want to know the difference between @PathVariable, @RequestParam, @RequestBody
see this file com.telusko.teluskomicroservices.controller.QuizController


After this project
go for telusko-question-service
go for telusko-service-registry
go for telusko-quiz-service
go for telusko-api-service