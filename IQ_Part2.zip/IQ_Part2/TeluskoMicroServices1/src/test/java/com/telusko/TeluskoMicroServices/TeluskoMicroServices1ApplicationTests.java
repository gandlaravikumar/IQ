package com.telusko.TeluskoMicroServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeluskoMicroServices1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
