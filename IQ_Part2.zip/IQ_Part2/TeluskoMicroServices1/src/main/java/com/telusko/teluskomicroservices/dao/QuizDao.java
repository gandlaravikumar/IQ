package com.telusko.teluskomicroservices.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telusko.teluskomicroservices.model.Quiz;

public interface QuizDao extends JpaRepository<Quiz, Integer>{

}
