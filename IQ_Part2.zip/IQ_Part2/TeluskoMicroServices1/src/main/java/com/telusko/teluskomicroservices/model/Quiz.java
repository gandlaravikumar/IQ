package com.telusko.teluskomicroservices.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Quiz {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String title;
	// One quiz can have multiple questions right. That's y List<Question>
	//We can't have everything in one table. So we can have that quiz questions in different table. so we need to use some mapping here between question table and quiz table
	//one quiz will only have one question then one to one
	//one quiz will have multiple questions then one to many, Which is true in our condition. But you cannot have the same question in different quiz.
	// But in our case we have that. Means 2 different quiz can have the same question. So we need to go for many to many.
	@ManyToMany
	private List<Question> questions;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

}
