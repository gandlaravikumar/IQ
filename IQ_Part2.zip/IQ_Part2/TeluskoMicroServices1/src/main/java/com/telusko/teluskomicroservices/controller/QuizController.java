package com.telusko.teluskomicroservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telusko.teluskomicroservices.model.Answer;
import com.telusko.teluskomicroservices.model.QuestionWrapper;
import com.telusko.teluskomicroservices.service.QuizService;

@RestController
@RequestMapping("/quiz")
public class QuizController {
	
	@Autowired
	QuizService quizservice;

	@PostMapping("/create")
	// You can hit this endpoint through postman http://localhost:8099/quiz/create?category=java&numQ=5&title=JQuizz
	// So that quiz table and quiz_questions table will create in DB.
	public ResponseEntity<String> createQuiz(@RequestParam String category, @RequestParam int numQ, @RequestParam String title) {
		return quizservice.createQuiz(category, numQ, title);
	}
	
	// Here i will create one more model class QuestionWrapper. Because in Question.java model class rightAnswer, category, difficultylevel params are there. i don't want to show that params to quiz participants.
	// you can hit this endpoint through postman http://localhost:8099/quiz/get/5
	// one quiz having multiple questions right.
	// So, Here we are passing quiz id=5. So you need to get the quiz id=5 mapped questions.
	@GetMapping("/get/{id}")
	public ResponseEntity<List<QuestionWrapper>> getQuiz(@PathVariable Integer id) {
		return quizservice.getQuizQuestions(id);
	}
	
	// hit this endpoint through postman http://localhost:8099/quiz/submit/5
	// one quiz having multiple questions right. So here we are passing quiz id=5. along with the List<Answer> in json format through postman.
	// so we need to compare this quiz id =5 mapped questions right answers with this List<Answer>
	@PostMapping("/submit/{id}")
	public ResponseEntity<Integer> submitQuiz(@PathVariable Integer id, @RequestBody List<Answer> answers) {
		//This method will return the no. of question correct.
		return quizservice.calculateResult(id, answers);
	}
}
