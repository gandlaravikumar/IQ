package com.telusko.teluskomicroservices.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.telusko.teluskomicroservices.dao.QuestionDao;
import com.telusko.teluskomicroservices.model.Question;

@Service
public class QuestionService {
	
	@Autowired
	QuestionDao questionDao;
	
	public ResponseEntity<List<Question>> getAllQuestions() {
		// Here am returning ResponseEntity<> object by passing 2 params. one is data fetching from Dao and another one is error status code.
		try {
		return new ResponseEntity<>(questionDao.findAll(), HttpStatus.OK);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ArrayList<>(), HttpStatus.BAD_REQUEST);
	}

	public List<Question> getQuestionsByCategory(String category) {
		return questionDao.findByCategory(category);
	}

	public ResponseEntity<String> addQuestion(Question question) {
		questionDao.save(question);
		// Try to hit this endpoint by sending some json data from postman tool and see the response.
		// It will say "201 created". Because we are sending that status code from here.. Or else it will say just status 200 OK.
		return new ResponseEntity<>("success", HttpStatus.CREATED);
		
	}

}
