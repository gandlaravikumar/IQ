package com.codedecode.microservices.API_Gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeDecodeApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeDecodeApiGatewayApplication.class, args);
	}

}
