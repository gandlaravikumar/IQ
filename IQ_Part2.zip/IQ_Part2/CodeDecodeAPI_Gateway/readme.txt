Getting Started with spring cloud gateway.
To include spring cloud gateway in your project, use the starter with a group ID of
org.springframework.cloud and an artifat ID of spring-cloud-starter-gateway.

Also you need to make it eureka client.
If you include the starter, but you do not want the gateway to be enabled, set spring.cloud.gateway.enabled=false.

To get the citizen details we need to hit http://localhost:8085/citizen/id/1
to get the vacination detials we need to hit http://localhost:8086/vaccinationcenter/id/1
But now no need to remember the ports, we can hit always the APIGateway port 8083 like below
http://localhost:8083/citizen/id/1
http://localhost:8083/vaccinationcenter/id/1

Terms and terminologies spring cloud gateway.
1) Route: The basic building block of the gateway. It is defined by an ID, a destination URI, a collection of predicates, and
a collection of filters. A route is matched if the aggregate predicate is true.
2) Predicate: This is a java 8 function predicate. The input type is a spring framework serverWebExchange.
This lets you match on anything from the HTTP request, such as headers or parameters.
3) Filter: These are instances of spring framework GatewayFilter that have been constructed with a specific factory.
Here, you can modify requests and response before or after sending the downstream request.