API Gateway:
In micro servies there are multiple services and each service will connect to other service.
All the microservices combine as one application right.
But for a user doesn't know about this things and all. they consider all the services combine as a one application.
The way to interact with the application should be only one url.

But here, there are multiple url's are there, due to multiple services and multiple instances and multiple port number etc.
one more problem is authentication.
if i login with my ceditiacls to one service, it will navigate to another service. there it will ask again username and password.
That's y API gateway came into picture.
It will became entry point or interface for the user.

Now, all the requests should come through API gateway.
for example if API gateway is running on port 8765.
the request should be http:localhost/<API port>/<serviceName>/serviceendpoints
you can see the service name in Spring Eureka registered page once the service is registered or in application.properties files.
Example: http://localhost:8765/TELUSKO-QUIZ-SERVICE/quiz/get/1


we should allow the API gateway to search the user requests. So for that we need to enable the locator in application.properties file.

Note: I am not sure why this telusko-api-service application not working. XXXX.


